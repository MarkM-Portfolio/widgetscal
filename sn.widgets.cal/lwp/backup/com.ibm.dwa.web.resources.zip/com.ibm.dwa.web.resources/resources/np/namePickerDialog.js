/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.np.namePickerDialog");

dojo.require("dwa.common.dialog");
dojo.require("dwa.np.namePicker");
dojo.require("dwa.np.namePickerOptions");
dojo.require("dijit._Templated");

dojo.declare(
    "dwa.np.namePickerDialog",
	[dwa.common.dialog, dijit._Templated,dwa.np.namePickerOptions],
{
    store: null,
    structure: null,
    dirStore: null,
    viewList: null,
    supportScreenReader: true,
    fieldLabels: [],
    fieldIds: [],

    disableAlert: false,
    disableSelectPane: false,
    disableButtonPane: false,
    disableViewList: false,
    disableSearchText: false,
    disableHeader: false,
    showNameInput: false,
    leftRatio: 50,

    iconNum: undefined,
    showColumnHeader: false,
    disableExpandNameColumn: false,
    defaultColumnWidths: [],
    defaultColumnTitles: [],
    listHeaderText: '',
    selectHeaderText: '',


    postMixInProperties: function() {
        this.initOptions();

        this.namePicker = new dwa.np.namePicker({
            _npOptions: this,
            id:  this.id, // required for non-XSP env.
            dialog: this,
            store: this.store,
            structure: this.structure,
            dirStore: this.dirStore,
            viewList: this.viewList,
            supportScreenReader: this.supportScreenReader
        });

        /// nls
        var templateParams = {
            formStyle: '',
            leftListWidth: this.getLeftPaneRatio() + '%',
            rightListWidth: this.getRightPaneRatio() + '%',
        	generatedButtonHTML: this.namePicker.generateButtonHTML(),
            paneRawStyle:((dojo.isIE &&  dojo.doc.compatMode == "CSS1Compat") ? '' : 'style="height:100%;"'),
        	blkButtonPaneStyle:((dojo.isIE &&  dojo.doc.compatMode == "CSS1Compat") ? '' : 'style="height:100%;"'),
        	alignDefault: "align=" + (dojo.isRTL ? "left" : "right" ),
            alignLeft: 'class="s-textalign-default" align=' + (dojo.isRTL ? '"right"' : '"left"' ),
            alignRight: 'class="s-textalign-reverse" align=' + (dojo.isRTL ? '"left"' : '"right"' )
        };
        dojo.mixin( templateParams, this._msgs );
        var templateContent = dojo._getText(dojo.moduleUrl("dwa.np")+"templates/namePickerDWA.html");
        this.templateString = "<div id='unusedDummy'>" + dojo.string.substitute( templateContent, templateParams ) + "</div>";

        this.inherited(arguments);
    },

    postCreate: function(){
        this.namePicker.init( this.id );

        this.bodyBackgroundColor = "#f8f8e0"; // need to be sync'ed with css.
        this.inherited(arguments);
    },

	show: function() {
    	this.startup();

		this.inherited(arguments);
	},

	render: function(){
        this.inherited(arguments);
        this._checkDojoAttachPointAfterDOMUpdate();

        dojo.connect(this.DirectoryList, "onchange", dwa.np.namePicker.prototype.updateViewList );
        dojo.connect(this.ViewList, "onchange", dwa.np.namePicker.prototype.updateView );
        dojo.connect(this.pkSearch, "onclick", dwa.np.namePicker.prototype.doAction );
        dojo.connect(this.pkRemove, "onclick", dwa.np.namePicker.prototype.doAction );
        dojo.connect(this.pkRemoveAll, "onclick", dwa.np.namePicker.prototype.doAction );

        dojo.connect(this.pkOk,"onclick", this, function(){ this.namePicker._doActionReal("OK"); } );
        var that = this;
        dojo.connect(this.pkCancel,"onclick", function(){ that.destroy(); } );
     	this.connect(dojo.byId(this.sId + "-close-icon"), "onclick", function(){ that.destroy(); });

        this.namePicker.applyVisibility()
        this.namePicker.initOnLoad();
    },

    _checkDojoAttachPointAfterDOMUpdate: function(){
         // this is required, because dwa.common.dialog.render() replace the DOM tree.
        var nodes = this.domNode.getElementsByTagName('*');
        var len = nodes.length;
        for( var i = 0; i < len; i++ ){
            var val = nodes[i].getAttribute("dojoAttachPoint");
            if( val ){ this[val] = nodes[i]; }
        }
    }
});
