/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.np.utils");


dwa.np.utils.createXmlElement = function(sTag){
	if(dojo.isFF)
	{
		if(!window.gDocFragment)
			// Safari doesn't make a document if no namespace is specified. Making XHTML document works for both Gecko and Safari.
			window.gDocFragment = dojo.doc.implementation.createDocument("http://www.w3.org/1999/xhtml", "html", null);
		return gDocFragment.createElement(sTag);
	}
	else
	{
		if(!window.gDocFragment)
			window.gDocFragment = h_ClientBrowser.isIE6() ? dojo.doc.createDocumentFragment() : dojo.doc;
		return gDocFragment.createElement(sTag);
	}
};

dwa.np.utils.findAttr = function(sName, oElem, bReturnElem, nMaxDepth){
	    var sValue,nDepth=0;
	    if(!nMaxDepth) nMaxDepth=500;
	    while( oElem && !(sValue=oElem.getAttribute(sName)) && nDepth<nMaxDepth ){
	        oElem = oElem.parentNode;
	        if("#document"==oElem.nodeName || "HTML"==oElem.nodeName) return;
	        nDepth++;
	    }
	    if( nDepth>=nMaxDepth ) return null;
	    return bReturnElem ? oElem : sValue;
};

dwa.np.utils.eventCancel = function(ev){
	    if(!ev) return;
	    (dojo.isIE ? (ev.returnValue = false) : (dojo.isFF ? (ev.preventDefault()) : (ev.preventDefault()) ) );
	    (dojo.isIE ? (ev.cancelBubble = true) : (dojo.isFF ? (ev.stopPropagation()) : (ev.stopPropagation()) ) );
};

dwa.np.utils.eventPreventDefault = function(ev){
	    if(!ev) return;
	    (dojo.isIE ? (ev.returnValue = false) : (dojo.isFF ? (ev.preventDefault()) : (ev.preventDefault()) ) );
};

dwa.np.utils.eventStopPropagation = function(ev){
	    if(!ev) return;
	    (dojo.isIE ? (ev.cancelBubble = true) : (dojo.isFF ? (ev.stopPropagation()) : (ev.stopPropagation()) ) );
};

dwa.np.utils.eventGetTarget = function(ev){
	 if( dojo.isFF ){
	    if(ev.target)
	    {
	        var t1 = ev.target;
	        try {
	            while(t1 && t1.nodeName=='#text')
	                t1 = t1.parentNode;
	            return t1;
	        } catch(e) {
	        }
	    }
	    return null;
	 }else{ // G
	    return ev.srcElement;
	 } // end - IS
};

dwa.np.utils.eventGetFromTarget = function(ev){
	 if( dojo.isFF ){
	    if(ev.relatedTarget)
	    {
	        var t1 = ev.relatedTarget;
	        try {
	            while(t1 && t1.nodeName=='#text')
	                t1 = t1.parentNode;
	            return t1;
	        } catch(e) {
	        }
	    }
	    return null;
	 }else{ // G
	    return ev.fromElement;
	 } // end - IS
};

dwa.np.utils.eventGetToTarget = function(ev){
	 if( dojo.isFF ){
	    if(ev.relatedTarget)
	    {
	        var t1 = ev.relatedTarget;
	        try {
	            while(t1 && t1.nodeName=='#text')
	                t1 = t1.parentNode;
	            return t1;
	        } catch(e) {
	        }
	    }
	    return null;
	 }else{ // G
	    return ev.toElement;
	 } // end - IS
};

dwa.np.utils.eventIsShortcutKeyPressed = function(ev){
		return (navigator.userAgent.match(/Mac|iPhone/i)) ? (ev.metaKey || ev.altKey) : ev.ctrlKey;
};

dwa.np.utils.elGetAttr = function(el, sAttribute, bElement){
	    while( el ){
	        var u=(el.getAttribute? el.getAttribute(sAttribute):null);
	        if( u ) return (bElement? el:u);
	        el = el.parentNode;
	    }
	    return null;
};

dwa.np.utils.elFromPoint = function( oBox, x, y, doc ){
	    // ----------------------------------------------------------------
	    // return the element if the x,y coordinates are inside the specified box
	    // ----------------------------------------------------------------
	    if( !doc ) doc=dojo.doc;
	    if( 'string'==typeof(oBox) ) oBox=doc.getElementById(oBox);
	    if( !oBox ) oBox = doc.body;
	 if( dojo.isIE || dojo.isWebKit ){
	    // IE
	    var el=doc.elementFromPoint(x,y);
	    if( oBox.contains(el) ) return el;
	    return null;
	 }else{ // IS
	    // Mozilla
	    //  Use a recursive scheme to look inside the specified box.
	    //  This could be VERY slow.  To speed up, pass a small area as oBox.
	    var posLP = dwa.np.utils.getAbsPos(oBox, true);
	    var maxX  = posLP.x + oBox.offsetWidth;
	    var maxY  = posLP.y + oBox.offsetHeight;
	    if( x < posLP.x ) return null;
	    if( y < posLP.y ) return null;
	    if( x > maxX ) return null;
	    if( y > maxY ) return null;
	    for( var i=0, imax=oBox.childNodes.length; i<imax; i++ ){
	        var el = dwa.np.utils.elFromPoint( oBox.childNodes[i], x, y, doc );
	        if( el ) return el;
	    }
	    return oBox;
	 } // end - G
};

dwa.np.utils.elGetCurrentStyle = function(el, sProp, bByInteger, bPreferOffset){
	    var oValue = null;
	 if( dojo.isFF || dojo.isWebKit ){
	    var oStyle = dwa.np.utils.elGetOwnerDoc(el).defaultView.getComputedStyle(el,null);
	    // SPR DYHG76K4XM : in Safari oStyle evaluates to null on second opening of namepicker
	    // since it is in an iFrame in sparkle. Need to reference its parent window's document instead.
	    if (oStyle == null)
	        oStyle = this.window.parent.document.defaultView.getComputedStyle(el,null);
	    oValue = oStyle.getPropertyValue(sProp.replace(/[A-Z]/g, function(str){return '-'+str.toLowerCase()}));
	 }else{ // GS
	    oValue = el.currentStyle[sProp];
	 } // end - I
	    switch(sProp)
	    {
	        case 'width':
	 if( dojo.isFF || dojo.isWebKit ){
	            if(oValue == 'auto' || oValue.indexOf('%') != -1)
	                return el.offsetWidth;
	 }else{ // GS
	            if(oValue == 'auto' || oValue.indexOf('%') != -1 || bPreferOffset)
	                return el.offsetWidth;
	 } // end - I
	        case 'height':
	 if( dojo.isFF || dojo.isWebKit ){
	            if(oValue == 'auto' || oValue.indexOf('%') != -1)
	                return el.offsetHeight;
	 }else{ // GS
	            if(oValue == 'auto' || oValue.indexOf('%') != -1 || bPreferOffset)
	                return el.offsetHeight;
	 } // end - I
	    }
	    if(bByInteger)
	    {
	        oValue = parseInt(oValue);
	        if(isNaN(oValue))
	            oValue = 0;
	    }
	    return oValue;
};

dwa.np.utils.elGetOwnerDoc = function(el){
	    return el.ownerDocument ? el.ownerDocument : el.document;
};



dwa.np.utils.escapeHtmlKeywords = function(sHtmlText, nFlag){
		if(!sHtmlText)
			return sHtmlText;
	
		if(!nFlag)
			nFlag = (1 | 2 | 4 | 8 | 16);
	
		return sHtmlText
				.replace(/&/g, (nFlag & 1 ? '&amp;'  : '&'))
				.replace(/&amp;#/g, '&#')
				.replace(/\"/g,(nFlag & 2 ? '&quot;' : '\"'))
				.replace(/</g, (nFlag & 4   ? '&lt;'   : '<'))
				.replace(/>/g, (nFlag & 8   ? '&gt;'   : '>'))
				.replace(/ /g, (nFlag & 16 ? '&nbsp;' : ' '));
};

dwa.np.utils.getAbsPos = function( el, bAbs, bNoBody ){
	    // if bAbs==true, then really get the absolute position
	    //  otherwise, we normally want the offset from
	    //  this element's relatively positioned container
	
	    if( !el )
	        return;
	
	    var pos = new dwa.common.utils.pos(el.offsetLeft, el.offsetTop);
	    var elParent = typeof el.offsetParent == "object" ? el.offsetParent : null;
	    var s;
	
	    // Sometimes el.offsetWidth returns wrong value when style.width = 100% for bidi
	    // This is workaround code for that.
	    if (!dojo._isBodyLtr()) {
	       if (el.offsetLeft < 3 && elParent != null && elParent.childNodes.length == 1 && (elParent.offsetWidth - el.offsetWidth) > 0)
	          pos.x += elParent.offsetWidth - el.offsetWidth - 2 ; // -2 is the edge width
	    }
	
	    while( elParent != null && elParent.nodeName != "#document")
	    {
	        if (!bAbs)
	        {
	            s = dwa.np.utils.elGetCurrentStyle(elParent, "position");
	            if ("relative" == s || "absolute" == s) break;
	        }
	        pos.x += elParent.offsetLeft - elParent.scrollLeft;
	        pos.y += elParent.offsetTop  - elParent.scrollTop;
	        elParent = elParent.offsetParent;
	    }
	    // add body scroll offset
	    if( !bNoBody ){
	        var b$=dwa.np.utils.elGetOwnerDoc(el).body;
	        pos.x += b$.scrollLeft;
	        pos.y += b$.scrollTop;
	    }
	    return pos;
};

dwa.np.utils.buildDataUrl = function(sForm, oArgs){
		if(!oArgs) oArgs={};
		return (oArgs.bAbsolute ? (dwa.lv.globals.get().sNsfPath + '/' + "iNotes" + '/' + "Proxy" + '/') : ("../../" + "iNotes" + '/' + "Proxy" +'/')) + "?OpenDocument&Form=" + sForm + 
			(oArgs.bCache&&oArgs.bLangDep ? "&l="+dojo.locale : "") +
			(oArgs.bCache ? ((dwa.lv.globals.get().oSettings.aCompressible && dwa.lv.globals.get().oSettings.aCompressible[4-1]=='1') ? "&gz" : "") + (oArgs.bNoCR ? '' : "&CR") + (oArgs.bNoMX ? '' : "&MX") + (oArgs.sTimeStamp?("&TS="+oArgs.sTimeStamp):(dwa.lv.globals.get().oSession.sFormsTLM ? "&TS="+dwa.lv.globals.get().oSession.sFormsTLM : "")) : "") + 
			(oArgs.bCache&&oArgs.bUserDep&&dwa.lv.globals.get().oSession.s_UNH ? "&UNH="+dwa.lv.globals.get().oSession.s_UNH : "");
};

dwa.np.utils.elSetInnerText = function(el, sText)
{
    if( dojo.isFF ){
        while (el.childNodes.length > 0) {
            el.removeChild(el.firstChild);
        }
        sText = sText.replace(/\r\n/g, '\n');
        sText = sText.replace(/\r/g, '\n');

        var aText = sText.split('\n');
        for(var i=0;i<aText.length;i++) {
            if(i>0)
                el.appendChild(this.elGetOwnerDoc(el).createElement('BR'));
            el.appendChild(this.elGetOwnerDoc(el).createTextNode(aText[i]));
        }
    }else{
		if(typeof el.innerText != 'undefined')
			el.innerText = sText;
		else
			el.text = sText;
    }
}

dwa.np.utils.elGetOwnerDoc = function(el)
{
    // ----------------------------------------------------------------
    // return the document object that this element is contained by
    // ----------------------------------------------------------------
    return (el.ownerDocument || el.document); 
}


dwa.np.utils.selectAddOption = function(oSel, oOpt, index) {
    if( dojo.isIE ){
    	oSel.options.add(oOpt, index);
    }else{
    	if(	typeof( index ) == "undefined") oSel.add(oOpt, null);
    	else oSel.add(oOpt, oSel.options[index]);
    }
}

dwa.np.utils.selectRemoveOption = function(oSel, index) {
    if( dojo.isIE ){
    	oSel.options.remove(index);
    }else{
    	oSel.remove(index);
    }
}

dwa.np.utils.selectRemoveOptions = function(oSel) {
	var nCount = oSel.options.length;
	for(var i=0;i<nCount;i++)
		dwa.np.utils.selectRemoveOption(oSel, 0)
}

//// from s_utils.h
dwa.np.utils.splitEx = function (sStr, sSep, sDQuote)
{
	//D_EnterFunction('String.prototype.splitEx')
	var index;
	var bDone = false;
//	var sDQuote = '"';

	var iPos = 0;
	var aIndex = [];

	if (!sDQuote)
		var sDQuote = '"';

	var sKey = ['SplitEx', sSep, sDQuote, sStr].join('|');
	if (!dwa.np.utils.aCacheSplitEx)
		dwa.np.utils.aCacheSplitEx = {};
	if (dwa.np.utils.aCacheSplitEx[sKey]) {
		return /*D_ExitFunction*/ (dwa.np.utils.aCacheSplitEx[sKey])
	}

	while ( !bDone)
	{
		index = sStr.indexOf(sSep,iPos);
		if ( index != -1)
		{
			var sDQuoteIndex = -1;
			var sDQuoteIndex2 = -1;
			var chkDQuoteDone = false;
			var skipReplace = false;
			var chkStartPos = iPos;

			while (!chkDQuoteDone )
			{
				sDQuoteIndex = sStr.indexOf(sDQuote,chkStartPos);
				if ( sDQuoteIndex != -1 && sDQuoteIndex < index)
				{
					// check if the oldStr is inside a pair of double quote
					sDQuoteIndex2 = sStr.indexOf(sDQuote, sDQuoteIndex +1 );
					if (sDQuoteIndex2 > index )
					{
						// the oldStr is inside double quote, skip the replacement
						chkDQuoteDone = true;
						skipReplace = true;
					} 
					else if (sDQuoteIndex2 != -1 && sDQuoteIndex2 < index )
					{
						//need to check again.
						chkStartPos = sDQuoteIndex2+1;
					}
					else
						chkDQuoteDone = true;
				}
				else
					chkDQuoteDone = true;
			}

			if ( skipReplace )
			{
				if ( sDQuoteIndex2 < sStr.length -1 )
					iPos = sDQuoteIndex2+1;
				else
					bDone = true;
			}
			else
			{
				aIndex[aIndex.length] = index;

				if ( index < (sStr.length - sSep.length))
					iPos = index+sSep.length;
				else
					bDone = true;
			}
		}
		else
		{
			bDone = true;
		}
	}	

	var aRet = [];
	var start = 0;

	for(var i=0;i<aIndex.length;i++)
	{
		var end = aIndex[i];

		aRet[i] = sStr.substring(start,end);
		start = end + sSep.length;
	}
	if(sStr.length)
		aRet[aRet.length] = sStr.substring(start,sStr.length);

	dwa.np.utils.aCacheSplitEx[sKey] = aRet;

	return /*D_ExitFunction*/(aRet)
};

dwa.np.utils.hasInternetDomain = function(sOrig)
{
	if(!sOrig)
		return false;
	
	var aDomains = this.splitEx( sOrig, '@');
	// common name should be skipped.
	for(var i=1;i<aDomains.length;i++)
	{
		if(aDomains[i].indexOf('.') != -1)
			return true;
	}
	return false;
}

dwa.np.utils.parse822Address = function(sOrig)
{
	var sAddress = "";
	var sPhrase = "";
	var sTmpPhrase = "";

	var bInQuote = false;
	var bInComment = false;
	var bInAddress = false;

	var nAddressPart = 0;

  if ("undefined" != typeof(sOrig))
  {
	for(var i=0;i<sOrig.length;i++)
	{
		var ch = sOrig.charAt(i);

		if(bInQuote)
		{
			sTmpPhrase += ch;

			if(ch == '"')
			{
				bInQuote = false;
				continue;
			}
		}
		else
		if(bInComment)
		{
			if(ch == ')')
			{
				bInComment = false;
				continue;
			}
		}
		else
		if(bInAddress)
		{
			if(ch == '(')
			{
				bInComment = true;
				continue;
			}
			sTmpPhrase += ch;
			if(ch == '>')
			{
				bInAddress = false;
				nAddressPart++;
				continue;
			}
			sAddress += ch;
		}
		else
		{
			if(ch == '(')
			{
				bInComment = true;
				continue;
			}
			if(ch == '<')
			{
				bInAddress = true;
				sPhrase = sTmpPhrase;
				sTmpPhrase += ch;
				sAddress = "";
				continue;
			}
			sTmpPhrase += ch;
			if(ch == '"')
			{
				bInQuote = true;
				continue;
			}
		}
	}
  }

	var bValid = true;

	// Don't mark as valid if address is 821 format. This func accepts 822 addresses only. So renamed to parse822Address.
	if(bInQuote || bInComment || bInAddress || nAddressPart==0)
		bValid = false;

	var oRet = {
		bIsValid : bValid,
		sPhrase : sPhrase,
		sAddress : sAddress
	};

	return oRet;
}

dwa.np.utils.Is822Address = function(sOrig)
{
	var oRet = this.parse822Address(sOrig);
///	VAL_DBG('Is822Address('+sOrig+'),returning '+oRet.bIsValid);
	return oRet.bIsValid;
}

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Return an abbreviated name
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
dwa.np.utils.TrimChar = function(sName){
    if( !sName ) return "";

    return sName.replace(/^\s*(.*?)\s*$/, '$1');
};

dwa.np.utils.DNAbbreviate = function(sName)
{
    var DN_EQ = "=";
    var DN_CN = "CN";
    var DN_O = "O";
    var DN_SEP = "/";
    var DN_DOM_SEP = "@";

	sName = this.TrimChar(sName);
	if(!sName || sName.length==0)
		return "";

	if(this.hasInternetDomain(sName) || this.Is822Address(sName))
		return sName;

	// if this is an LDAP identity, then return unabbreviated, as the Notes client does (DTE reported problem)
	// I suspect that what we should be doing here is testing for CN=
	// If CN= is not found, then return sName.
	// LDAP entities typically use lowercase attribute names, like this:
	//      uid=e38993/ou=Westford/o=IBM
	//      cn=Daniel Gurney/ou=Westford/o=IBM
	// and also:
	//      cn=Daniel Gurney,ou=Westford,o=IBM
	if( -1==sName.indexOf(DN_EQ) || -1==sName.toUpperCase().indexOf(DN_CN+DN_EQ) ){
		return sName;
	}
	// Do a more extensive check, just to be sure
	//  Since canonical names are tagged, the position of the tags is not regulated.
	//  For instance, both of these names should be identical:
	//      CN=Daniel Gurney/OU=Westford/O=IBM
	//      OU=Westford/CN=Daniel Gurney/O=IBM
	//  For simplicity, we check for:
	//      /CN=    (anywhere in the string)
	//       CN=    (only at the beginning of the string)
	if( !((sName.toUpperCase().indexOf(DN_SEP+DN_CN+DN_EQ) > 0) || (sName.toUpperCase().indexOf(DN_CN+DN_EQ) == 0)) ){
		return sName;
	}

	// support for UserName with DomainName - Tatsuya@03162001
	var aName = sName.split(DN_DOM_SEP);
	var part = aName[0].split(DN_SEP);
	var last = part.length-1;
	var ab_part = [];

	for(var i=0;i<part.length;i++)
	{
		var pos = part[i].indexOf(DN_EQ);

		// Check if last part has exactly two chars...if so...keep key if this is ORG
		// reason for i>0 : alternate name may contain org at second part : CPAN68CBLA
		if( i==last && pos!=-1 && i>0 && part[i].length>pos+1 ) {
			if( part[i].substring(pos+1).match(/^[A-z]{2}$/) ){
				if( -1 != part[i].substring(0,pos+1).toUpperCase().indexOf(DN_O+DN_EQ) )
					pos = -1;
			}
		}

		if(pos != -1)
			ab_part[ab_part.length] = this.TrimChar(part[i].substring(pos+1));
		else
			ab_part[ab_part.length] = this.TrimChar(part[i]);
	}

	var sEntireName = ab_part.join(DN_SEP);
	for (var i=1; i<aName.length; i++)
		sEntireName += DN_DOM_SEP + this.TrimChar(aName[i]);

	return sEntireName;
};

dwa.np.utils.toValidURIString = function(s)
{
	// the value may contains "+" which need to convert to "%2b"
	// otherwise, the server will see it as Space char. - waiho
	// encodeURIComponent does do this (whereas escape did not)

	//  LCHG73G4U3: replace %
	s = s.replace("/%/g", "%25");
	// also replace %2c (comma) to %252c so that the NotesDictionary works
	return encodeURIComponent(s).replace(/%2c/gi, "%252c");
};

// from s_addressDetails.h

// show address details
//     sDirIndex  : Index of the target directory. If the directory is Contacts, set "0".
//     sDirType   : "0": Contacts
//                  "1": Domino Directory (including Extended Directory Catalog)
//                  "2": LNAB (Condensed Directory Catalog)
//                  "3": LDAP
//     sName      : Target user name. This value is optional if the directory is not LDAP.
//     sEmail     : Target E-mail address. This value is optional if the directory is not LDAP.
//     sDocId     : UNID or NOTEID of the target user's person/group document.
//                  if the directory is LNAB, use NoteID. if not, use UNID.
//     sEntryType : The type of the target. "Person", "Group", "Server", or "Database"
//
// NOTE: DO NOT execute URIencode for those parameters before call openAddressDetails.
//       URIencode is executed in this function.
dwa.np.utils.openAddressDetails = function(store, sDirIndex, sDirType, sName, sEmail, sDocId, sEntryType)
{
	if (!sDirIndex || !sDirType || !sEntryType)
		return;

    var SHIMMER_ADDRESSDETAILS_WND_STYLE = "width=450,height=350,menubar=no,directories=no,status=no,toolbar=no,location=no,scrollbars=no,resizable=no";

	var sUrl = store.url + "/iNotes/Proxy/" + '?EditDocument&Form=s_AddressDetails&PresetFields=sDirIndex;' + sDirIndex + ',sDirType;' + sDirType + ',sName;' + this.toValidURIString(sName) + ',sEmail;' + this.toValidURIString(sEmail) + ',sDocId;' + sDocId + ',sEntryType;' + this.toValidURIString(sEntryType);

	window.open(sUrl, "", SHIMMER_ADDRESSDETAILS_WND_STYLE);
};
