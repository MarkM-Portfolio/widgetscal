/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.np.namePicker");

dojo.require("dwa.np.virtualListNP");
dojo.require("dwa.np.selectedTreeRoot");
dojo.require("dwa.np.utils");
dojo.require("dwa.common.name");
dojo.require("dwa.common.nameEntity");
dojo.require("dwa.common.utils");
dojo.require("dwa.lv.jsonReadViewEntries");
dojo.require("dwa.data.DominoDataStore");
dojo.require("dwa.lv.globals");


dojo.declare(
	"dwa.np.namePicker",
	null,
{
    customDesignMode: false,
	structure: null,
    store: null,
    dirStore: null,
    viewList: null,
    dialog: null,
    supportScreenReader: false,

    _npOptions: null,
    _oDataStoreSel: new dwa.lv.jsonReadViewEntries({store: new dwa.data.DominoDataStore({})}),

   _objMap: {},

	constructor: function(props){
        dojo.mixin( this, props );

        this._msgs = this._npOptions._msgs;
    },
	init: function(id){
        this.id = id;

        if( id ){
            dwa.np.namePicker.prototype._objMap[ this.id ] = this;
        }

        this.customDesignMode = ( this.getCustomViewInfo && this.getCustomDesignArray );
        this._npOptions.setDisableViewList(this.customDesignMode);
    },

    getObjFromEvent: function(ev){
        var elm = dwa.np.utils.eventGetTarget(ev);
        for( ; elm; elm = elm.parentNode ){
            var obj = dwa.np.namePicker.prototype._objMap[ elm.id ];
            if( obj ) return obj;
        }
        return null;
    },


	applyVisibility: function(){
        var dialog = this.dialog;
        var opts = this._npOptions;
		if(opts.get('bDisableViewList'))
		{
			dialog.blkViewList.style.display = 'none';
			dialog.blkViewList2.style.display = 'none';
		}
		if(opts.get('bDisableSearchText'))
		{
			dialog.blkSearchTable.setAttribute('rowSpan', 1);
			dialog.blkSearchText.style.display = 'none';
			dialog.blkSearchText2.style.display = 'none';
		}
		if(opts.get('bDisableButtonPane'))
		{
			dialog.blkButtonHeader.style.display = 'none';
			dialog.blkButtonPane.style.display = 'none';
		}
		if(opts.get('bDisableSelectPane'))
		{
			dialog.blkSelectHeader.style.display = 'none';
			dialog.blkSelectPane.style.display = 'none';
			dialog.blkRemoveButton.style.display = 'none';
		}
		if(opts.get('bDisableHeader'))
			dialog.blkHeader.style.display = 'none';
		if(opts.get('bShowNameInput'))
			dialog.blkNameInput.style.display = '';
		if(typeof opts.get('sListHeaderText') != 'undefined')
			dwa.np.utils.elSetInnerText(dialog.blkListHeader, opts.get('sListHeaderText'));
		if(typeof opts.get('sSelectHeaderText') != 'undefined')
			dwa.np.utils.elSetInnerText(dialog.blkSelectHeader, opts.get('sSelectHeaderText'));

	},
	initOnLoad: function(){
        var opts = this._npOptions;
		dojo.doc.title = opts.get('sDlgTitle') || this._msgs[ "L_NPW_TITLE" ];
		dojo.connect(dojo.doc.body, "contextmenu", dwa.np.utils.eventCancel);
		this.theForm = this.dialog.formForValidation;
	
		//CWinAdjuster.invoke();
		this.userListVL = new dwa.np.virtualListNP({npObj: this, _npOptions: this._npOptions});
        this.userListVL.init('UserList', 0, false, 0, opts.get('bShowColumnHeader') ? false : 'none', true);
	
	    this.userListVL.oDataStore = new dwa.lv.jsonReadViewEntries({
			store: this.store,
			query: this.query,
			queryOptions: this.queryOptions
		});

		if(!opts.get('bDisableSelectPane'))
		{
			this.selectedListVL = new dwa.np.virtualListNP( {isSelectedList: true, npObj: this, _npOptions: this._npOptions} );
            this.selectedListVL.init("SelectedList", 2, false, 0, 'none', true);

    	    this.selectedListVL.oDataStore = this._oDataStoreSel;
		}
		
		//getDragDropControl().bEnabled = false;
        this.gRoot = new dwa.np.selectedTreeRoot({_npOptions: this._npOptions, selectedListVL:this.selectedListVL, oDataStore:this._oDataStoreSel });
		this.gRoot.initSelectedListRoot();
		this.gRoot.applyFromFields();
	
		if(!opts.get('bDisableSelectPane'))
			this.selectedListVL.refresh(true, true);
	
		this.fetchDirectories();
		// move to fetchDirecotires() inside. -- this.onResized();
	},
	fetchDirectories: function(){
        var opts = this._npOptions;
		var oSel = this.dialog.DirectoryList;
		dwa.np.utils.selectRemoveOptions(oSel);
	
		var nIdx = 1;
	
		if(!opts.get('bDisablePreferred')) {
			var aPrefList = opts.get('aPreferredList');
			for(var i=0;aPrefList && i<aPrefList.length;i++) {
				if(aPrefList[i] && aPrefList[i].bEnabled) {
					var oOpt = new Option();
					oOpt.oInfo = {};
					for(var sName in aPrefList[i]) {
						var sValue = aPrefList[i][sName];
						switch(sName)
						{
							case 'Title':
								oOpt.text = sValue;
								break;
						}
						oOpt.oInfo[sName] = sValue;
					}
					oOpt.value = nIdx++;
					oOpt.oInfo.nPrefIdx = i + 1;
					oOpt.oInfo.DirIndex = "P" + oOpt.oInfo.nPrefIdx;
					
					dwa.np.utils.selectAddOption(oSel, oOpt);
				}
			}
		}
	
        var dirStore = this.dirStore;
		if(dirStore) //sJson) //(oRoot)
		{
            var that = this;
    		var fetch = {
    			onComplete: function(result, requestObject){
                    var aViewEntries = result; //sJson.directory; //xmlSelectNodes(oRoot, './directory');
        			for(var i=0;i<aViewEntries.length;i++)
        			{
        				var bIsContacts = false;
        				var oOpt = new Option();
        				oOpt.oInfo = {};
        	
        				var oViewEntry = aViewEntries[i];
        				var aEntryData = dirStore.getAttributes(oViewEntry); //oViewEntry.directorydata; //xmlSelectNodes(oViewEntry, './directorydata');
        				for(var j=0;j<aEntryData.length;j++)
        				{
        					var oEntryData = aEntryData[j];
        					var sName = oEntryData; //oEntryData['@name']; //.getAttribute('name');
                            if( sName.charAt(0) === '@' ){ continue; }
        					var sValue = dirStore.getValue( oViewEntry, sName ); //oEntryData.text || oEntryData.number; //xmlGetText(oEntryData);
        					switch(sName)
        					{
        						case 'Title':
        							if(sValue == 'Contacts')
        							{
        								bIsContacts = true;
        								sValue = that._msgs[ "L_CONTACTS" ];
        							}
        							oOpt.text = sValue;
        							break;
        						case 'Path':
        							if(sValue == 'Contacts')
        								sValue = '';
        							break;
        					}
        					oOpt.oInfo[sName] = sValue;
        				}
        				oOpt.value = nIdx++;
        				oOpt.oInfo.oXml = oViewEntry;
        	
        				if(typeof oOpt.oInfo.DirIndex == 'undefined' && (opts.get('bDisableContacts')))
        					continue;
        				if (bIsContacts)
        				{
        					var sAreas = dwa.lv.globals.get().oSettings.sAreas;
        					if (sAreas && sAreas.charAt(4) == '0')
        						continue;
        				}
        				if(oOpt.oInfo.DirIndex == '0' && that._npOptions.haiku.bIsOffline)
        					continue;
        				if(oOpt.oInfo.IsLNAB == '1' && opts.get('bDisableCatalog'))
        					continue;
        				if(oOpt.oInfo.IsLDAP == '1' && opts.get('bDisableLDAP'))
        					continue;
        				
        				dwa.np.utils.selectAddOption(oSel, oOpt);
        			}
            		
            		that.restoreLastDirectory();
            		that._updateViewListReal( dojo.hitch( that, that.onResized) );

                    //that.onResized();

    			},
    			onError: function(errText){
    				that.showAlert('DirectoryLisStore: ' + errText);
    			}
    		};
    		dirStore.fetch(fetch);
        }else{
            this.onResized();
        }
	},
    getNPViewListObj: function(){
    	return this.viewList && this.viewList.getList(this._npOptions.haiku.bShowExtraInfoOnNamePicker);
    },
	applyLDAPDesign: function(aJsonDesignArray, oVL, onComplete){
		var sDirIndex = this.getNabInfo().DirIndex;
	
		oVL.nDirIndex = sDirIndex; //typeof sDirIndex != 'undefined' ? sDirIndex : '';
		oVL.sFolderName = '';
	
        var oRequest = {
            oQuery: "",
            oJsonRoot: {
                "@columns": aJsonDesignArray.length,
                "column": aJsonDesignArray
            }
        };
        this.structure.changeType("json");
        this.applyDesign( oRequest );
       if( onComplete ){ onComplete(); }
	},
	fetchDesign: function(oXmlDesign, oVL, onComplete){
		var sDirIndex = this.getNabInfo().DirIndex;
		var sViewName = this.getViewInfo().sViewName;

		oVL.nDirIndex = sDirIndex;
		oVL.sFolderName = sViewName;
		oVL.fnDisplayName = null;

        if( this.customDesignMode ){
            this.structure.changeType("json");
            this.applyCustomDesign();
            if( onComplete ){ onComplete(); }
        }else{
            this.structure.changeType("xml");
            var np = this;
            this.structure.load(
                //dwa.np.utils.toValidURIString(sViewName),
                sViewName,
                undefined, undefined,
                "s_ReadDirDesign",
                (this.isLDAP() ? undefined : sDirIndex),
                function(oRequest){
                    np.applyDesign(oRequest);
                    if( onComplete ){ onComplete(); }
                }
            );
        }

        return true;
    },
    applyCustomDesign: function(){
        var array = this.getCustomDesignArray( this.getNabInfo() );

        var oRequest = {
            oQuery: "",
            oJsonRoot: {
                "@columns": array.length,
                "column": array
            }
        };
        this.applyDesign( oRequest );
    },
	applyDesign: function(oRequest){
        var opts = this._npOptions;
        var oVL = this.userListVL;

        oVL.designInfo = this.structure.parseDesign( oRequest, oRequest.bSoftDeleteDisabled ? 1 : 0, '', oRequest.sWho, oRequest.sAltWho, oRequest.sFolder, oRequest.bShowDefaultSort, oRequest.aShowHiddenColNames);

		if(oVL.designInfo)
			oVL.designInfo.nRowLines = 1;
	
	    var i,k,iMax,iName,oInfo;
		var sNameColumnName = this.getViewInfo().sViewInfo.split(';')[0];
	    iMax = oVL.designInfo?oVL.designInfo.length:0;
	
		var bDisableExpand = opts.get('bDisableExpandNameColumn') || this.getViewInfo().bDisableExpandNameColumn || false;
	
		// remove columns after name column
		for(i=0,k=iMax; i < k; i++){
			oInfo = oVL.designInfo[i];
			if(this.isLDAP() && this._npOptions.haiku.bShowExtraInfoOnNamePicker)
			{
				switch(oInfo.sName)
				{
					case '$28':
						oInfo.sName = 'Icon';
						break;
					case '$39':
						oInfo.sName = 'SummaryName';
						break;
					default:
						if(i-2>=0)
							oInfo.sName = this.getViewInfo().sViewInfo.split(';')[6 + (i-2)];
				}
				oInfo.bSort = oInfo.iViewSort = 0;
			}
	
			if(!bDisableExpand && oInfo.sName == sNameColumnName)
			{
				iMax = i + 1;
				for(var j=iMax;j<k;j++)
					oVL.designInfo.removeItem(iMax);
				break;
			}
		}
	
		oVL.resetColumnDesign(iMax);
		var aDefaultWidths = opts.get('aDefaultColumnWidths') || this.getViewInfo().aDefaultColumnWidths;
		var aDefaultTitles = opts.get('aDefaultColumnTitles') || this.getViewInfo().aDefaultColumnTitles;
		for (i=0; i < iMax; i++){
			oInfo = oVL.designInfo[i];
			
			var bUseDefaultWidth = aDefaultWidths && aDefaultWidths[i];
			var bUseDefaultTitles = aDefaultTitles && aDefaultTitles[i];
			oVL.setColumnWidth (i, (bUseDefaultWidth ? aDefaultWidths[i] : (!bDisableExpand && oInfo.sName == sNameColumnName ? 1000 : oInfo.nWidth)), oInfo.bFixed, ((bUseDefaultWidth || (!bDisableExpand && oInfo.sName == sNameColumnName))? false : oInfo.bChars), oInfo.bTwistie, oInfo.bResponse);
			oVL.bindColumnData (i, oInfo.nXmlCol);
			oVL.setColumnTitle (i, bUseDefaultTitles ? aDefaultTitles[i] : oInfo.sTitle, oInfo.bSort, oInfo.iViewSort);
			oVL.setColumnFormat(i, oInfo.nFormat);
		}
		oVL.setSortInfo(-1);
		oVL.updateColumnDesign();
		//if(IsDJXTemplate && this._npOptions.haiku.bEnableDJX && window.cbDisplayName)
		//	oVL.fnDisplayName = cbDisplayName;
	
		return true;
	},
	sweepLDAPNonValidEntries: function(sTargetTumbler, oRequest, nCount, bIsReversed){
		var sSummaryColName = this.getViewInfo().sViewInfo.split(';')[0];
	
		if(!sSummaryColName)
			return nCount;
	
		var nDeleted = 0;
		if(oRequest)
		{
            var ds = this.userListVL.oDataStore;

			var aViewEntryRoot = ds.getViewEntriesRoot(oRequest); //xmlSelectNodes(oRequest, './viewentry')
	        var aViewEntry = ds.getViewEntries(aViewEntryRoot);
            var cnt = aViewEntry ? ds.getLength(aViewEntry) : -1;

			for(var i=0,j=cnt-1;i<cnt;j--,i++)
			{
	            var oEntry = ds.getItem(aViewEntry, bIsReversed?j:i);

				var sSummaryNameData =  ds.getAttribute(oEntry, sSummaryColName) + '';
                //xmlSelectSingleNode(aViewEntry[i], './entrydata[@name="' + sSummaryColName + '"]');
				if(sSummaryNameData == '')
				{
                    ds.removeChild(aViewEntry,i); // TODO: need to check -- is this really work????
					//oRequest.removeChild(aViewEntry[i]);
					nDeleted ++;
				}
			}
		}
		
		return nCount - nDeleted;
	},
	getNewContainerSize: function(){
        var dialog = this.dialog;
		var oBlkUserList = dialog.blkUserPane;
		var oBlkSelectedList = dialog.blkSelectPane;
		var oTable = dialog.TableBody;
		var nBodyWidth = oTable.offsetWidth;
		var nBodyHeight = oTable.offsetHeight;
		var nWindowWidth = dojo.doc.body.clientWidth;
		var nWindowHeight = dojo.doc.body.clientHeight;
		var nListWidth = oBlkUserList.offsetWidth + oBlkSelectedList.offsetWidth;
		var nListHeight = oBlkUserList.offsetHeight;
		var nNewLWidth = Math.max((nWindowWidth - nBodyWidth + nListWidth) * (this.getLeftPaneRatio()/100), 100);
		var nNewRWidth = Math.max((nWindowWidth - nBodyWidth + nListWidth) * (this.getRightPaneRatio()/100), 100);
		var nNewHeight = Math.max(nWindowHeight - nBodyHeight + nListHeight, 100);
	
		return {Lwidth:nNewLWidth, Rwidth:nNewRWidth, height:nNewHeight};
	},
	getNabInfo: function(){
		var oSel = this.dialog.DirectoryList;
		var oOpt = oSel.options[Math.max(oSel.selectedIndex, 0)];
		return oOpt.oInfo;
	},
	getViewInfo: function(){
        if( this.customDesignMode ) return this.getCustomViewInfo( this.getNabInfo() );

		var oSel = this.dialog.ViewList;
		var oOpt = oSel.options[Math.max(oSel.selectedIndex, 0)];
		return oOpt.oInfo;
	},
	isContacts: function(){
		return this.getNabInfo().Path == '';
	},
	isLNAB: function(){
		return this.getNabInfo().IsLNAB == '1';
	},
	isLDAP: function(){
		return this.getNabInfo().IsLDAP == '1';
	},
	isPreferred: function(){
		return !!this.getPrefIndex();
	},
	getPrefIndex: function(){
		return this.getNabInfo().nPrefIdx;
	},
	getViewList: function(oNabObj){
		var aViewList = this._npOptions.get('aViewList') || this.getNPViewListObj().aViewList;
		var aRet = [];
		
		for(var i=0;i<aViewList.length;i++)
		{
			var oInfo = aViewList[i];
			if(this.isContacts() && !(oInfo.nViewType==2))
				continue;
			if(!this.isContacts() && oInfo.nViewType==2)
				continue;
			if(this.isLNAB() && !(oInfo.nViewType==3))
				continue;
			if(!this.isLNAB() && oInfo.nViewType==3)
				continue;
			if(this.isLDAP() && !(oInfo.nViewType==4))
				continue;
			if(!this.isLDAP() && oInfo.nViewType==4)
				continue;
			if(!this.isContacts() && oInfo.aDBPaths && oInfo.aDBPaths.length)
			{
				var bEnableView = false;
				
				for(var j=0;j<oInfo.aDBPaths.length;j++)
				{
					var sPath = oInfo.aDBPaths[j];
					if(sPath == '*' || sPath.toLowerCase() == oNabObj.Path.toLowerCase())
					{
						bEnableView = true;
						break;
					}
				}
				
				if(!bEnableView)
					continue;
			}
			//aRet.addItem(oInfo);
            aRet.push( oInfo );
		}
		return aRet;
	},
    updateViewList: function(ev){
        var obj = dwa.np.namePicker.prototype.getObjFromEvent(ev);
        if( !obj ) return;
        obj._updateViewListReal();
    },
	_updateViewListReal: function( onComplete ){
        if( !this.customDesignMode ){
    		var oSel = this.dialog.ViewList;
    		var aViewList = this.getViewList(this.getNabInfo());
    		var nSelected = Math.max(oSel.selectedIndex, 0);
    	
    		this.storeLastDirectory();
    	
    		var nIndex = 0;
    		dwa.np.utils.selectRemoveOptions(oSel);
    	
    		for(var i=0;i<aViewList.length;i++)
    		{
    			var oInfo = aViewList[i];
    			
    			if(!oInfo.sViewTitle)
    				continue;
    			var oOpt = new Option();
    			oOpt.text = oInfo.sViewTitle;
    			oOpt.value = i+1;
    			oOpt.oInfo = oInfo;
    			dwa.np.utils.selectAddOption(oSel, oOpt);
    		}
    		
    		this.restoreLastView();
        }
		var oSel = this.dialog.DirectoryList;
        this.store.sourceIndex = oSel.selectedIndex;
		this._updateViewReal(onComplete);
	},
    updateView: function(ev){
        var obj = dwa.np.namePicker.prototype.getObjFromEvent(ev);
        if( !obj ) return;

        obj._updateViewReal();
    },
	_updateViewReal: function(onComplete){
		this.storeLastView();
	
        var that = this;
        var mergedOnComplete = function(){
            that.refreshView();

            if( onComplete ){ onComplete(); }
        };

		if(this.isPreferred())
		{
			if(!this.applyLDAPDesign(this.getNabInfo().aDesignJsonArray, this.userListVL, mergedOnComplete))
				return;
		}
		else
		if(this.isLDAP() && !this._npOptions.haiku.bShowExtraInfoOnNamePicker)
		{
			if(!this.applyLDAPDesign(this.userListVL.getLDAPDesignJson().column, this.userListVL, mergedOnComplete))
				return;
		}
		else
		{
			if(!this.fetchDesign(this.dialog.xmlDesign, this.userListVL, mergedOnComplete))
				return;
		}
		
		//this.refreshView();
	},
	refreshView: function(){
		var sSearch = this.dialog.SearchFor.value;
		if(sSearch)
		{
			this.userListVL.sStartKey=sSearch;
			this.userListVL.sUntilKey = "";
			this.userListVL.bUseStartKeyOnly = true;
            var np = this;
			this.userListVL.fnAfterRefresh = function(){ np.cdRefreshed(); }
		}
		else
		{
			this.userListVL.sStartKey="";
			this.userListVL.sUntilKey="";
			this.userListVL.bUseStartKeyOnly = false;
			this.userListVL.fnAfterRefresh = null;
		}
		this.userListVL.sReadViewEntriesForm = (this.isPreferred() && this.getNabInfo().sReadViewEntriesForm) ? this.getNabInfo().sReadViewEntriesForm : (this.isLDAP() ? 's_ReadLDAPEntries' : 's_ReadDirEntries');
	
		var sPreset = "";
		if(this.isLDAP() && this._npOptions.haiku.bShowExtraInfoOnNamePicker)
		{
			var aExts = this.getViewInfo().sViewInfo.split(';').slice(6);
			sPreset = aExts.join('|');
		}
		else if(!this.isLDAP())
			sPreset = this.getViewInfo().sViewInfo.replace(/;/g, '|');
	
		if( sPreset ){ this.userListVL.oPresetFields.hc = sPreset; }
		this.userListVL.fnSweepEntries = this.isLDAP() ? dojo.hitch(this,this.sweepLDAPNonValidEntries) : null;
		this.userListVL.bAlwaysSendStartKey = this.isLDAP();
	
		this.userListVL.refresh(true, true);
	},
	cdRefreshed: function(){
		var sSearch = this.dialog.SearchFor.value;
		if(this.userListVL.getTotalEntriesInView() == 0)
			this.showAlert(dwa.common.utils.formatMessage(this._msgs[ "L_NPW_ALERT_SEARCH_NO_MATCH_FORMAT" ], sSearch));
	},
	storeLastDirectory: function(){
		var oSel = this.dialog.DirectoryList;
		if(this._npOptions.haiku && this._npOptions.haiku.oCookie)
		{
			var oOpt = oSel.options[oSel.selectedIndex];
			if(oOpt.oInfo)
			{
				this._npOptions.haiku.oCookie.LastNAB = oOpt.oInfo.DirIndex;
				this._npOptions.haiku.oCookie.store();
				
				var newNPDirIndex = typeof(oOpt.oInfo.DirIndex)=='undefined' ? -1 : oOpt.oInfo.DirIndex;
				if(newNPDirIndex != this.NPDirIndex) {
					this.storeProfileDirIndex( this.dialog.xmlDesign, 'iNotesViewProfile', 'NPDirPath', newNPDirIndex );
					this.NPDirIndex = newNPDirIndex;
				}
			}
		}
	},
	storeProfileDirIndex: function( oXml, sProfile, sField, sValue ){
	    var sURL = buildXmlProxyUrl("s_SetProfileDirIndex")
			+ "&PresetFields=ProfileName;" + sProfile + ",FieldName;" + sField
			+ ",DirIndex;" + sValue
			+ (this._npOptions.haiku.bUsingHttps ? ",s_UsingHttps;1" : "")
			+ (dojo.isFF ? ",noPI;1" : "");
	
		processStoreProfile(oXml, sProfile, sURL);
	},
	storeLastView: function(){
		var oSel = this.dialog.ViewList;
		if(this._npOptions.haiku && this._npOptions.haiku.oCookie && oSel.selectedIndex != -1)
		{
			this._npOptions.haiku.oCookie.LastView = oSel.selectedIndex + '';
			this._npOptions.haiku.oCookie.store();
		}
	},
	restoreLastDirectory: function(){
		var oSel = this.dialog.DirectoryList;
		if(this._npOptions.haiku && this._npOptions.haiku.oCookie)
		{
			if(this._npOptions.haiku.oCookie.LastNAB)
			{
				var nStoredNAB = Math.max(Math.min(parseInt(this._npOptions.haiku.oCookie.LastNAB), oSel.options.length-1), 0);
				for(var i=0;i<oSel.options.length;i++)
				{
					var oOpt = oSel.options[i];
					if(oOpt.oInfo && oOpt.oInfo.DirIndex == nStoredNAB)
						oSel.selectedIndex = i;
				}
			}
			else
			{
				var bSelected = false;
				for(var i=0;i<oSel.options.length;i++)
				{
					var oOpt = oSel.options[i];
					if(oOpt.oInfo && oOpt.oInfo.DirIndex == this.NPDirIndex) {
						oSel.selectedIndex = i;
						bSelected = true;
					}
				}
				if(!bSelected)
					oSel.selectedIndex = 0;
			}
		}
	},
	restoreLastView: function(){
		var oSel = this.dialog.ViewList;
		if(this._npOptions.haiku && this._npOptions.haiku.oCookie)
		{
			if(this._npOptions.haiku.oCookie.LastView)
				oSel.selectedIndex = Math.max(Math.min(parseInt(this._npOptions.haiku.oCookie.LastView), oSel.options.length-1), 0);
			else
				oSel.selectedIndex = 0;
		}
	},
	addNamesOnDblClick: function(){
		if(this._npOptions.get('bDisableSelectPane'))
			this._doActionReal('OK');
		else{
			for(var i=0;i<this._npOptions.getFieldCount();i++)
				if(this._npOptions.isDefaultTargetField(i))
					this.addNames(i);
        }
	},
	addNames: function(nIndex){
		var aNoMailEntries = [];
		var aNoAddedEntries = [];
		var bAlertSingleEntry = false;
		var bPassedToValidate = false;
		var bRet = true;
	
		var sTumbler = (nIndex+1) + '';
	
		var oParent = this.gRoot.getEntryByTumbler(sTumbler);
		if(!oParent)
			return false;
	
		if(this._npOptions.get('bShowNameInput') && this.dialog.NameInput.value != '')
		{
			this.gRoot.appendChildByName(oParent, this.gRoot.getDefaultIcon(), this.dialog.NameInput.value);
			this.dialog.NameInput.value = '';
		}
		else
		{
			var aUnids = this.userListVL.getSelectedUnids();
			if(!aUnids || !aUnids.length)
				return false;
			
			this.userListVL.deselectEntries();
			
			for(var i=0;aUnids && i<aUnids.length;i++)
			{
				var aEntries = this.userListVL.getEntriesByUnid(aUnids[i]);
				if(aEntries && aEntries.length)
				{
					var status = this.appendChildByXml(oParent, aEntries[0].getXmlNode() );
					if(status == 2)
						bAlertSingleEntry = true;
					else if(status == 1)
					{
						var aDatas = this.userListVL.getColumnDataArray(aEntries[0].getXmlNode());
						aNoMailEntries.push /*addItem*/ (aDatas[0]);
					}
					else if(status == 3)
					{
						var aDatas = this.userListVL.getColumnDataArray(aEntries[0].getXmlNode());
						aNoAddedEntries.push /*addItem*/ (aDatas[0]);
					}
					else if(status == 4)
					{
						bPassedToValidate = true;
					}
				}
			}
		}
		
		if(bPassedToValidate)
		{
			return true;
		}
		
		if(bAlertSingleEntry)
		{
			this.showAlert(this._msgs[ "L_NPW_ALERT_SINGLEENTRY" ]);
			bRet = false;
		}
	
		if(aNoMailEntries.length)
		{
			var sMsg = (1 == aNoMailEntries.length) ? this._msgs[ "L_NPW_ALERT_NOMAIL_ENTRY" ] : this._msgs[ "L_NPW_ALERT_NOMAIL_ENTRIES" ];
			this.showAlert(sMsg + '\n\n\t' + aNoMailEntries.join('\n\t') + '\n');
			bRet = false;
		}
		
		if(aNoAddedEntries.length)
		{
			var sMsg = (1 == aNoAddedEntries.length) ? this._msgs[ "L_NPW_ALERT_NOADDED_ENTRY" ] : this._msgs[ "L_NPW_ALERT_NOADDED_ENTRIES" ];
			this.showAlert(sMsg + '\n\n\t' + aNoAddedEntries.join('\n\t') + '\n');
			bRet = false;
		}
		
		this.gRoot.update();
	
		if(!this._npOptions.get('bDisableSelectPane'))
			this.selectedListVL.refresh(true, false);
	
		return bRet;
	},
	appendChildByXml: function(oParent, oXmlEntry){
		var oInfo = this._npOptions.getInfoByTumbler(oParent.getTumbler());
		if(!oInfo)
			return 9;
	
		var aDataItems = this.userListVL.getColumnDataArray(oXmlEntry);
		var sName = this.getPickedName(aDataItems, oInfo.nFlags, true);
		if(!sName)
			return 1;
	
		if(!this._npOptions.get('DisallowContactFullName') && this._npOptions.haiku.bPreferNameForContacts) {
			var status = this.checkAppendable(oParent, sName);
			if(status != 0)
				return status;
	
			sName = this.getPickedName(aDataItems, oInfo.nFlags);
			if(!sName)
				return 1;
		}
	
		var oObj = this.getPickedObj(aDataItems, oXmlEntry);
		return this.gRoot.appendChildByName(oParent, this.userListVL.getIconText(oXmlEntry), sName, oObj);
	},
	getPickedName: function(aDataItems, nFlags, bPreferAddress){
		if(this.isLDAP())
		{
			if(aDataItems[6] != '1')
				return aDataItems[1];
	
			var sName = aDataItems[2] ? aDataItems[2] : aDataItems[1];
			if(this._npOptions.haiku.bNamePreference && aDataItems[5] && !(nFlags & 2) &&
				getDisplayNameFromValues(aDataItems[2], aDataItems[4], aDataItems[5]))
				sName = getDisplayNameFromValues(aDataItems[2], aDataItems[4], aDataItems[5]);
	
			return dwa.np.utils.DNAbbreviate(sName.replace(/,/g, '/'));
		}
		
		// prioritize mail address over prim/alt name in contacts
		if(this.isContacts() && aDataItems[1] && bPreferAddress)
			return dwa.np.utils.DNAbbreviate(aDataItems[1]);
		
		if(this._npOptions.haiku.bNamePreference && aDataItems[4] && !(nFlags & 2))
			return dwa.np.utils.DNAbbreviate(aDataItems[4]);
		
		var bIsGroup = this.getTypeString(aDataItems[3])=='Group';
		if(!bIsGroup && aDataItems[2])
			return dwa.np.utils.DNAbbreviate(aDataItems[2]);
		
		if(aDataItems[1])
			return dwa.np.utils.DNAbbreviate(aDataItems[1]);
		
		// need return blank to show noaddress alert for acl group, servers only group and deny list only group
		if(bIsGroup) return '';
	
		return aDataItems[0];
	},

	remove: function(){
		this.gRoot.removeSelection();
	},
	removeAll: function(){
		this.gRoot.removeAll();
	},
	getTypeString: function(sType){
        if( typeof(sType) === 'undefined' ){ sType = ''; }

		var sType = sType.toLowerCase();
		if(this.isLDAP())
		{
			return
				(sType.indexOf('database') != -1 ? 'Database' :
				(sType.indexOf('person') != -1 ? 'Person' :
				(sType.indexOf('group') != -1 ? 'Group' :
				(sType.indexOf('server') != -1 ? 'Server' : 'Person'))));
		}
		else {
			switch(sType) {
				case 'database': case 'databa': return 'Database'; break;
				case 'person': case 'pers': return 'Person'; break;
				case 'group': case 'gro': case '(groupcalendar)': return 'Group'; break;
				case 'server': case 'serv': return 'Server'; break;
				default: return 'Person'; break;
			}
		}
	},
	getPickedObj: function(aDataItems, oXmlEntry){
		var fLdap = this.isLDAP();
	
		var oNameEntity = new dwa.common.nameEntity;
		oNameEntity.oContents = {
			fullName: !fLdap ? aDataItems[2] : aDataItems[1],
			altFullName: !fLdap ? aDataItems[4] : '',
			address: aDataItems[1],
			mailAddress: aDataItems[1],
			noteid: !fLdap ? this.userListVL.oDataStore.getAttribute( oXmlEntry, 'noteid') + '' : '',
			unid: !fLdap ? this.userListVL.oDataStore.getAttribute( oXmlEntry, 'unid') + '' : '',
			type: this.getTypeString(aDataItems[3]),
			directoryType: fLdap ? 'LDAP' : this.isContacts() ? 'CONTACTS' : ''
		};
	
		oNameEntity.sNoteId = oNameEntity.oContents['noteid'];
		oNameEntity.sUnid = oNameEntity.oContents['unid'];
		oNameEntity.sType = oNameEntity.oContents['type'];
		var fIsNGroup = (oNameEntity.sType == 'Group' && !oNameEntity.oContents['directoryType']);
		var sAltName = oNameEntity.oContents['altFullName'] ? oNameEntity.oContents['altFullName'] : oNameEntity.oContents['fullName'];

        oNameEntity.oPrimName = new dwa.common.name(oNameEntity.oContents['fullName'], fIsNGroup);
		oNameEntity.oAltName = new dwa.common.name(sAltName, fIsNGroup);
	// start - defined(LATER)
		oNameEntity.sLang = oNameEntity.oContents['altNameLanguage'];
		oNameEntity.sDomain = oNameEntity.oContents['mailDomain'];
	// end - defined(LATER)
		// if it is a personal group, set a flag so that we know we need to fetch the members
		// when we do the name validation.
		if (oNameEntity.sType == 'Group' && oNameEntity.oContents['directoryType'] == 'CONTACTS')
			oNameEntity.fNotYetFetched = true;
		
		if (oNameEntity.oContents['directoryType'] == 'CONTACTS' && oNameEntity.oContents['mailAddress']) {
			oNameEntity.oPrimName.sDispName = oNameEntity.oPrimName.sOriginal;
			oNameEntity.oAltName.sDispName = oNameEntity.oAltName.sOriginal;
			oNameEntity.oPrimName.sAddress = oNameEntity.oAltName.sAddress = oNameEntity.oContents['mailAddress'];
		}
		return oNameEntity;
	},
	generateButtonHTML: function(){
        var s = "";

		for(var i=0;i<this._npOptions.getFieldCount();i++)
		{
			var sLabel = this._npOptions.getTargetFieldLabel(i);
			s += (
				'<tr>' +
				'<td width=100%>' +
					'<input type=button value="' + (sLabel ? sLabel : this._msgs[ "L_ADD" ]) + '>>' + '" ' + 'class="s-form-button" style="width:100%;overflow:visible;"' + ' onclick="dwa.np.namePicker.prototype.doAction(event, \'' + 'Add' + i + '\');">' +
				'</td>' +
				'</tr>'
			);
		}

        return s;
	},
	showWaitBox: function(bShow){
		if(!window.gWaitBox)
			window.gWaitBox = new CommonWaitBox(dojo.doc.body, dojo.doc);
		
		window.gWaitBox.Show(bShow, this._msgs[ "L_NPW_WAITBOX" ]);
	},
	onResized: function(){
		var oRet = this.getNewContainerSize();
		var gUserListDiv = this.dialog.UserList;
		var gSelectedListDiv = this.dialog.SelectedList;
	
		if(gUserListDiv.offsetWidth > oRet.Lwidth)
			gUserListDiv.style.width = oRet.Lwidth + 'px';
		else 
			gUserListDiv.style.width = '100%';
	
		if(gSelectedListDiv.offsetWidth > oRet.Rwidth)
			gSelectedListDiv.style.width = oRet.Rwidth + 'px';
		else 
			gSelectedListDiv.style.width = '100%';
	},
	getLeftPaneRatio: function(){
		var nLeftRatio = this._npOptions.get('nLeftRatio');
		return !nLeftRatio ? (this._npOptions.get('bDisableSelectPane') ? 100 : 50) : nLeftRatio;
	},
	getRightPaneRatio: function(){
		return (100 - this.getLeftPaneRatio());
	},
	showAlert: function(sMsg){
		if(!this._npOptions.get('bDisableAlert'))
			alert(sMsg);
	},
    doAction: function( ev, oArg ){
        var obj = dwa.np.namePicker.prototype.getObjFromEvent(ev);
        if( !obj ) return;

        var sValue = oArg;
        if( !sValue && ev ){
            var oInput = dwa.np.utils.eventGetTarget(ev);
            sValue = oInput ? oInput.name : null;
        }

        return obj._doActionReal(sValue);
    },
	_doActionReal: function(sValue){ //oArg){;
		//var ev = oArg; // dwa.np.utils.eventGetTarget(oArg) ? eventGet(oArg) : null;
		//var oInput = oArg && oArg.name ? oArg : (ev ? dwa.np.utils.eventGetTarget(ev) : null);
		//var sValue = oInput ? oInput.name : oArg;
		var obj = this;

		switch(sValue)
		{
			case 'Search':
				obj.refreshView();
				break;
			case 'Remove':
				obj.remove();
				break;
			case 'RemoveAll':
				obj.removeAll();
				break;
			case 'OK':
				if(obj._npOptions.get('bDisableSelectPane'))
				{
					obj.removeAll();
					if(!obj.addNames(0))
						break;
				}
				obj.gRoot.applyToFields();
			case 'Cancel':
				obj.closeNamePicker_Lite();
				break;
			default:
				for(var i=0;i<obj._npOptions.getFieldCount();i++)
					if(('Add' + i) == sValue)
						obj.addNames(i);
				break;
		}
	},
	keyPressed: function(ev){
		switch (ev.keyCode) {
		case 13:
			this.refreshView();
			return;
		}
	
	},


    //////////////////
	closeNamePicker_Lite: function(){
        if( this.dialog ){
            this.dialog.hide();
            this.dialog.destroy();
            this.dialog = null;
        }
	}
});
