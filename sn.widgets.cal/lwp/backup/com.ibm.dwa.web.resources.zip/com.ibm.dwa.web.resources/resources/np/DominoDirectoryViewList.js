/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.np.DominoDirectoryViewList");

dojo.require("dojo.i18n");
dojo.requireLocalization("dwa.np", "namePicker");

dojo.declare(
	"dwa.np.DominoDirectoryViewList",
	null,
{
    D_DIRECTORY_TYPE_DEFAULT:	1,
    D_DIRECTORY_TYPE_CONTACTS:	2,
    D_DIRECTORY_TYPE_CATALOG:	3,
    D_DIRECTORY_TYPE_LDAP:  	4,

//#define D_NP_COLUMN_SUMMARY	0
//#define D_NP_COLUMN_ADDRESS	1
//#define D_NP_COLUMN_PRIMARY	2
//#define D_NP_COLUMN_TYPE	3
//#define D_NP_COLUMN_ALTNAME	4
//#define D_NP_COLUMN_HIER	5
//#define D_NP_COLUMN_OPT		6
//#define D_NP_COLUMN_LDAP_ALTLANG	5
//#define D_NP_COLUMN_LDAP_PRFMLFMT	6
//#define D_NP_COLUMN_LAST	7	//always last

	constructor: function(props){
        dojo.mixin( this, props );

        this._msgs = dojo.i18n.getLocalization("dwa.np", "namePicker", this.lang);

        this.NamePick = {
            nWidth: this._msgs[ "D_NAMEPICK_WINDOW_WIDTH" ],
            nHeight: this._msgs[ "D_NAMEPICK_WINDOW_HEIGHT" ],
            nViewListWidth: 300,
            aViewList: [
            	// for Contacts
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_FLATVIEW" ],
            		sViewName : '($PeopleGroupsFlat)',
            		sViewInfo : '$39;MAMailAddress;NPName;Form;AltFullName',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_CONTACTS,
            		aDBPaths : []
            	},
            	// for Catalog
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_FLATVIEW" ],
            		sViewName : '($PeopleGroupsFlat)',
            		sViewInfo : '$39;MAMailAddress;NPName;$40;AltFullName',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_CATALOG,
            		aDBPaths : ['*']
            	},
            	// for LDAP
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_FLATVIEW" ],
            		sViewName : '',
            		sViewInfo : 'SummaryName;MailAddress;FullName;Type;AltFullName;AltFullNameLanguage;PreferredMailFormat',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_LDAP
            	},
            	// for normal directory
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_FLATVIEW" ],
            		sViewName : '($PeopleGroupsFlat)',
            		sViewInfo : '$39;MAMailAddress;NPName;Type;AltFullName',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_DEFAULT,
            		aDBPaths : ['*']
            	},
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_HIERVIEW" ],
            		sViewName : '($PeopleGroupsHier)',
            		sViewInfo : '$11;MAMailAddress;$24;Type;AltFullName;$8',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_DEFAULT,
            		aDBPaths : ['*']
            	},
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_CORPHIERVIEW" ],
            		sViewName : '($PeopleGroupsCorpHier)',
            		sViewInfo : '$60;MAMailAddress;NPName;Type;AltFullName;$55',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_DEFAULT,
            		aDefaultColumnWidths : [10],
            		aDBPaths : ['*']
            	},
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_LANGVIEW" ],
            		sViewName : '($PeopleGroupsByLang)',
            		sViewInfo : '$11;MAMailAddress;NPName;Type;AltFullName;$8',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_DEFAULT,
            		aDefaultColumnWidths : [10],
            		aDBPaths : ['*']
            	}
            ]
        };

        this.NamePickExt = {
            nWidth: 950,
            nHeight: 400,

            aViewList: [
            	// for Contacts
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_FLATVIEW" ],
            		sViewName : '($PeopleGroupsFlatExt)',
            		sViewInfo : '$39;MAMailAddress;NPName;Form;AltFullName;0;JobTitle;OfficePhone;OtherPhone',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_CONTACTS,
            		aDefaultColumnWidths : [20, 200, 100, 100, 100],
            		aDefaultColumnTitles : ['', 'Name', 'Position', 'Phone', 'Dedicated Line'],
            		bDisableExpandNameColumn : true,
            		aDBPaths : []
            	},
            	// for Catalog
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_FLATVIEW" ],
            		sViewName : '($PeopleGroupsFlat)',
            		sViewInfo : '$39;MAMailAddress;NPName;$40;AltFullName',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_CATALOG,
            		aDefaultColumnTitles : ['', 'Name'],
            		aDBPaths : ['*']
            	},
            	// for LDAP
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_FLATVIEW" ],
            		sViewName : '($PeopleGroupsFlatExt)',
            		sViewInfo : 'SummaryName;MailAddress;FullName;Type;AltFullName;0;title;telephonenumber;telexnumber',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_LDAP,
            		aDefaultColumnWidths : [20, 200, 100, 100, 100],
            		aDefaultColumnTitles : ['', 'Name', 'Position', 'Phone', 'Dedicated Line'],
            		bDisableExpandNameColumn : true
            	},
            	// for normal directory
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_FLATVIEW" ],
            		sViewName : '($PeopleGroupsFlat)',
            		sViewInfo : '$39;MAMailAddress;NPName;Type;AltFullName',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_DEFAULT,
            		aDefaultColumnTitles : ['', 'Name'],
            		bDisableExpandNameColumn : true,
            		aDBPaths : ['*']
            	},
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_HIERVIEW" ],
            		sViewName : '($PeopleGroupsHier)',
            		sViewInfo : '$11;MAMailAddress;$24;Type;AltFullName;$8',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_DEFAULT,
            		aDefaultColumnWidths : [20],
            		aDefaultColumnTitles : ['', '', 'Name'],
            		bDisableExpandNameColumn : true,
            		aDBPaths : ['*']
            	},
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_CORPHIERVIEW" ],
            		sViewName : '($PeopleGroupsCorpHier)',
            		sViewInfo : '$60;MAMailAddress;NPName;Type;AltFullName;$55',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_DEFAULT,
            		aDefaultColumnWidths : [20],
            		aDefaultColumnTitles : ['', '', 'Name'],
            		bDisableExpandNameColumn : true,
            		aDBPaths : ['*']
            	},
            	{
            		sViewTitle : this._msgs[ "L_NPW_TITLE_LANGVIEW" ],
            		sViewName : '($PeopleGroupsByLang)',
            		sViewInfo : '$11;MAMailAddress;NPName;Type;AltFullName;$8',
            		nViewType : dwa.np.DominoDirectoryViewList.prototype.D_DIRECTORY_TYPE_DEFAULT,
            		aDefaultColumnWidths : [20],
            		aDefaultColumnTitles : ['', '', 'Name'],
            		bDisableExpandNameColumn : true,
            		aDBPaths : ['*']
            	}
            ]
        };
    },
    getList: function( showExtraInfoOnNamePicker ){
    	return showExtraInfoOnNamePicker ? this.NamePickExt : this.NamePick;
    }
});
