/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.np.virtualListNP");

dojo.require("dwa.lv.virtualList");
dojo.require("dwa.lv.jsonReadDesign");
dojo.require("dwa.lv.DominoReadDesign");

dojo.declare(
	"dwa.np.virtualListNP",
    dwa.lv.virtualList,
{
    isSelectedList: false,
    npObj: null,

    _npOptions: null,

	constructor: function(/*Object*/args){
		if(args){
			dojo.mixin(this, args);
		}
	},

	init: function(sContainerId    ,nCols          ,bAltRowClr     ,nColHdrOffset  ,sColHdrID          ,bContainerHasAbsHeight    ,sTargetTumbler,bShowUnread    ){
        this.inherited(arguments);

        if( this.isSelectedList ){
			this.fnFormatRow = this.formatRowNPSelect;
            // the following two lines are executed in selectedTreeRoot.initSelectedListRoot()
			//this.fnDelete = this.npObj.gRoot.removeSelection;
			//this.fnReadDoc = this.npObj.gRoot.removeSelection;
			this.bUseXPATH = false;

			this.applyListDesign(this._getSelectedListDesignJson());
        }else{
    		this.fnFormatRow = this.formatRowNP;
    		this.fnReadDoc = dojo.hitch(this.npObj, this.npObj.addNamesOnDblClick);
    		this.bAllowStoreColumnCookie = false;
    		this.bAllowMultipleSelection = this._npOptions.checkIfAllowMultiple();
    		this.bShowDefaultSort = false;
    		this.bShowTooltipForText = true;
    		this.sUpdatingViewMessage = this.npObj._msgs[ "L_UPDATINGVIEW_MESSAGE_SHORT" ];
    		this.bNeedEntryDataForMultiSelection = true;
        }
    	this.bSupportScreenReader = this.npObj.supportScreenReader;
    },

    getLDAPDesignJson: function(){
	    /*var s = '<viewdesign direction="0" spacing="0" columns="2" totalscolor="#000000" headerbgcolor="#A0A0C5" extendlastcolumn="false">'+
	        '<column columnnumber="0" width="16" name="Icon" title="Icon" resize="true" format="2" icon="true" listseparator="none" twistie="true">'+
    	    '<cfont style="r" size="9" color="#000000" face="Helvetica" />'+
	        '<hfont style="r" size="9" color="#000000" face="Helvetica" />'+
	        '<numberformat digits="0" format="general" /><datetimeformat show="datetime" date="yearmonthday" time="hourminutesecond" zone="never" /></column>'+
    	    '<column columnnumber="1" width="1000" name="SummaryName" title="SummaryName" resize="true" format="2" listseparator="none">'+
	        '<cfont style="r" size="9" color="#000000" face="Helvetica" />'+
	        '<hfont style="r" size="9" color="#000000" face="Helvetica" />'+
	        '<numberformat digits="0" format="general" /><datetimeformat show="datetime" date="yearmonthday" time="hourminutesecond" zone="never" /></column>'+
	        '</viewdesign>'; */

        var s = {
            "@direction":"0",
            "@spacing":"0",
            "@columns":"2",
            "@totalscolor":"#000000",
            "@headerbgcolor":"#A0A0C5",
            "@extendlastcolumn":"false",
            column: [
                {
                    "@columnnumber":"0",
                    "@width":"16",
                    "@name":"Icon",
                    "@title":"Icon",
                    "@resize":"true",
                    "@format":"2",
                    "@icon":"true",
                    "@listseparator":"none",
                    "@twistie":"true",
            	    cfont: {
                        "@style":"r",
                        "@size":"9",
                        "@color":"#000000",
                        "@face":"Helvetica"
                    },
        	        hfont: {
                        "@style":"r",
                        "@size":"9",
                        "@color":"#000000",
                        "@face":"Helvetica"
                    },
        	        numberformat: {
                        "@digits":"0",
                        "@format":"general"
                    },
                    datetimeformat: {
                        "@show":"datetime",
                        "@date":"yearmonthday",
                        "@time":"hourminutesecond",
                        "@zone":"never"
                    }
                },
                {
                    "@columnnumber":"1",
                    "@width":"1000",
                    "@name":"SummaryName",
                    "@title":"SummaryName",
                    "@resize":"true",
                    "@format":"2",
                    "@listseparator":"none",
                    cfont:{
                        "@style":"r",
                        "@size":"9",
                        "@color":"#000000",
                        "@face":"Helvetica"
                    },
    	            hfont:{
                        "@style":"r",
                        "@size":"9",
                        "@color":"#000000",
                        "@face":"Helvetica"
                    },
    	            numberformat:{
                        "@digits":"0",
                        "@format":"general"
                    },
                    datetimeformat:{
                        "@show":"datetime",
                        "@date":"yearmonthday",
                        "@time":"hourminutesecond",
                        "@zone":"never"
                    }
                }
            ]
        };

        return s;
    },

    _getSelectedListDesignJson: function(){
        /*var s = '<xml id="xmlSelectedListDesign">'
	        + '<viewdesign direction="0" spacing="0" columns="2" totalscolor="#000000" headerbgcolor="#A0A0C5" extendlastcolumn="false">'
	        + '<column columnnumber="0" width="16" name="Icon" title="Icon" resize="true" format="2" icon="true" listseparator="none" twistie="true">'
	        +   '<cfont style="r" size="9" color="#000000" face="Helvetica" />'
	        +   '<hfont style="r" size="9" color="#000000" face="Helvetica" />'
	        +   '<numberformat digits="0" format="general" />'
            +   '<datetimeformat show="datetime" date="yearmonthday" time="hourminutesecond" zone="never" />'
            + '</column>'
	        + '<column columnnumber="1" width="1000" name="Name" title="Name" resize="true" format="2" listseparator="none">'
	        +   '<cfont style="r" size="9" color="#000000" face="Helvetica" />'
	        +   '<hfont style="r" size="9" color="#000000" face="Helvetica" />'
	        +   '<numberformat digits="0" format="general" />'
            +   '<datetimeformat show="datetime" date="yearmonthday" time="hourminutesecond" zone="never" />'
            + '</column>'
	        + '</viewdesign>'
            + '</xml>';*/

        var s = 
        //{"design":
        {
            "@direction": "0",
            "@spacing": "0",
            "@columns": "2",
            "@totalscolor": "#000000",
            "@headerbgcolor": "#A0A0C5",
            "@extendlastcolumn": "false",
            "column": [
              {
                "@columnnumber": "0",
                "@width": "16",
                "@name": "Icon",
                "@title": "Icon",
                "@resize": "true",
                "@format": "2",
                "@icon": "true",
                "@listseparator": "none",
                "@twistie": "true",
                "cfont": {
                    "@style": "r",
                    "@size": "9",
                    "@color": "#000000",
                    "@face": "Helvetica"
                },
                "hfont": {
                    "@style": "r",
                    "@size": "9",
                    "@color": "#000000",
                    "@face": "Helvetica"
                },
                "numberformat": {
                    "@digits": "0",
                    "@format": "general"
                },
                "datetimeformat": {
                    "@show": "datetime",
                    "@date": "yearmonthday",
                    "@time": "hourminutesecond",
                    "@zone": "never"
                }
              },
              {
                "@columnnumber": "1",
                "@width": "1000",
                "@name": "Name",
                "@title": "Name",
                "@resize": "true",
                "@format": "2",
                "@listseparator": "none",
                "cfont": {
                    "@style": "r",
                    "@size": "9",
                    "@color": "#000000",
                    "@face": "Helvetica"
                },
                "hfont": {
                    "@style": "r",
                    "@size": "9",
                    "@color": "#000000",
                    "@face": "Helvetica"
                },
                "numberformat": {
                    "@digits": "0",
                    "@format": "general"
                },
                "datetimeformat": {
                    "@show": "datetime",
                    "@date": "yearmonthday",
                    "@time": "hourminutesecond",
                    "@zone": "never"
                }
              }
            ]
        //}
        };

        return s;
    },
	applyListDesign: function(sJson){
        var dominoReadDesign = new dwa.lv.DominoReadDesign( { oDataStore: new dwa.lv.jsonReadDesign } );

        var oRequest = {
            oJsonRoot: sJson,
            oQuery: ""
        };
		this.designInfo = dominoReadDesign.parseDesign(oRequest);
	
	    var i,iMax,oInfo;
	    iMax = this.designInfo?this.designInfo.length:0;
		for (i=0; i < iMax; i++){
			oInfo = this.designInfo[i];
			this.setColumnWidth (i, oInfo.nWidth, oInfo.bFixed, oInfo.bChars, oInfo.bTwistie, oInfo.bResponse);
			this.bindColumnData (i, oInfo.nXmlCol);
			this.setColumnTitle (i, oInfo.sTitle, oInfo.bSort, oInfo.iViewSort);
			this.setColumnFormat(i, oInfo.nFormat);
		}
	},

	formatRowNP: function(sUnid,oTreeViewEntry,oViewEntry,tdClass,colClass,cellTag,idVL,a1,n,aTitle){
		return this.formatRow(sUnid,oTreeViewEntry,oViewEntry,tdClass,colClass,cellTag,idVL,this.designInfo,0,a1,n,aTitle);
	},
	formatRowNPSelect: function(sUnid,oTreeViewEntry,oViewEntry,tdClass,colClass,cellTag,idVL,a1,n,aTitle){

		return this.formatRow(sUnid,oTreeViewEntry,oViewEntry,tdClass,colClass,cellTag,idVL,this.designInfo,0,a1,n,aTitle);
	},

	getSelectedUnids: function(bSingle){
		var aUnids = this.getSelectedData("UNID");
		if(!aUnids || !aUnids.length)
		{
			this.npObj.showAlert(this.npObj._msgs[ "L_NPW_ALERT_NOENTRYSELECTED" ]);
			return 0;
		}
		else if(aUnids.length>1 && bSingle)
		{
			this.npObj.showAlert(this.npObj._msgs[ "L_NPW_ALERT_SELECTAENTRY" ]);
			return 0;
		}
		return aUnids;
	},
	getColumnDataArray: function(oXmlEntry){
		var aRet = [];
		var oViewInfo = this.npObj.getViewInfo();
		var aColumnNames = oViewInfo.sViewInfo ? oViewInfo.sViewInfo.split(';') : [];
	
		for(var i=0;i<7;i++)
		{
            var oEntryData =this.oDataStore.getEntryDataByName( oXmlEntry, aColumnNames[i] );
            aRet[i] = oEntryData ? this.oDataStore.getValue( oEntryData ) : '';
		}
		return aRet;
	},
	getIconText: function(oXmlEntry){
        var iconNum = this._npOptions.get('sIconNum');
		if(iconNum)
			return iconNum;

		for(var i=0;i<this.designInfo.length;i++)
		{
			if(this.designInfo[i].bIsIcon)
			{
                var oData = this.oDataStore.getEntryDataByName( oXmlEntry, this.designInfo[i].sName );

				//var oData = xmlSelectSingleNode(oXmlEntry, 'entrydata[@name="' + this.userListVL.designInfo[i].sName + '"]');
				if(oData)
					return oData + ''; //xmlGetText(oData);
			}
		}
		return '';
	}
});
