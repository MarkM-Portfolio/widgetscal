/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.np.selectedTreeRoot");

dojo.require("dwa.lv.treeViewEntry");
dojo.require("dwa.common.notesValue");
dojo.require("dwa.common.name");
dojo.require("dwa.common.fieldNameEntities");
//dojo.require("dwa.common.nameValidator");

dojo.declare(
	"dwa.np.selectedTreeRoot",
	null,
{
    gRoot: null,
    _npOptions: null,
    oDataStore:null,
    selectedListVL: null,
    gUniqId: 1,


	constructor: function(/*Object*/args){
		if(args){
			dojo.mixin(this, args);
		}
	},

	initSelectedListRoot: function(){
		var gRoot = this.gRoot = new dwa.lv.treeViewEntry;
		gRoot.setListMode();

        var aFields = this._npOptions.getTargetFields();

        this.oDataStore._items = [];
        gRoot.oDataStore = this.oDataStore;

		for(var i=0;i<aFields.length;i++)
		{
			var sLabel = aFields[i].sCategoryLabel || aFields[i].sLabel;
			this._appendCategory( sLabel || this._smsgs[ "L_ADD" ]);
		}
		gRoot.update();
	
		if(this.selectedListVL){
			this.selectedListVL.setListMode( gRoot);

            this.selectedListVL.fnReadDoc =
			 this.selectedListVL.fnDelete = dojo.hitch(this, this.removeSelection);
        }
	},

    getEntryByTumbler: function(sTumbler){
        return this.gRoot.getEntryByTumbler(sTumbler);
    },
    update: function(){
        this.gRoot.update();
    },

	applyFromFields: function(){
//		var oVal = dwa.common.nameValidator.get();
	
		for(var i=0;i<this._npOptions.getFieldCount();i++)
		{
			var oInfo = this._npOptions.getInfoByIndex(i);
			var oInput = oInfo.oInput;
			if(!oInput && oInfo.sId)
				oInput = dojo.byId(oInfo.sId);
			if(!oInput)
				continue;
			
			var sTumbler = (i+1) + '';
			var oParent = this.gRoot.getEntryByTumbler(sTumbler);
	
			var oFieldNameEntities = dwa.common.fieldNameEntities.get(oInput);
			oFieldNameEntities.synchronize();
	
			for (var j = 0; j < oFieldNameEntities.getLength(); j++)
			{
				var oEntity = oFieldNameEntities.aoEntities[j];
				this.appendChildByName(oParent, this.getIconNum(oEntity), oFieldNameEntities.getName(j), oEntity, true);
			}
		}
		this.selectedListVL && this.selectedListVL.oRoot.update();
	},

	applyToFields: function(){
//		var oVal = dwa.common.nameValidator.get();
	
		for(var i=0;i<this._npOptions.getFieldCount();i++)
		{
			var oInfo = this._npOptions.getInfoByIndex(i);
			var oInput = oInfo.oInput;
			if(!oInput && oInfo.sId)
				oInput = dojo.byId(oInfo.sId);
			if(!oInput)
				continue;
			
			var oFieldNameEntities = dwa.common.fieldNameEntities.get(oInput);
			oFieldNameEntities.aoEntities = new Array();
	
			var sTumbler = (i+1) + '';
			var oParent = this.gRoot.getEntryByTumbler(sTumbler);
			var aValues = [];
			for(var j=oParent.getStartIndex();j<=oParent.getEndIndex();j++)
			{
				if(!oParent.oCollection.find(j))
					continue;
				var oEntry = this.gRoot.getEntryByTumbler(sTumbler + '.' + (j));
				if(!oEntry)
					continue;
				//var oData = null;
				//var oXmlNode = ;
                var ds = this.oDataStore;

                var oData = ds.getEntryDataByName( oEntry.getXmlNode(), "Name" );

				/*for(k=0;k<oXmlNode.childNodes.length;k++)
				{
					oData = oXmlNode.childNodes[k];
					if(oData.tagName == 'entrydata' && oData.getAttribute('name') == 'Name')
						break;
					oData = null;
				}*/
				if(oData)
				{
					var sName = ds.getValue(oData); //xmlGetText(oData);
					var oObj = oEntry.oObj;
					// Development task #ASUH-7J37SS: In case of room/resource oObj is not very useful
					// since oObj.oPrimName etc. are empty
					// Same for names initially picked
					if (oObj && oObj.oContents && oObj.oContents.fullName)
					{
						oFieldNameEntities.aoEntities.push(oObj);
					}
					else
					{
						var oName = new dwa.common.name;
						oName.extract(sName);
						oFieldNameEntities.aoEntities.push(oName);
					}
				}
			}

			oInput.value = oFieldNameEntities.getNames().join(', ');
			oFieldNameEntities.synchronize();
		}
	},

	_appendCategory: function(sTitle){
        var oParent = this.gRoot;

		var sTumbler = oParent.getTumbler() + (oParent.getChildLoaded() ? oParent.getEndIndex() + 1 : 1);
        var oJson = {
            '@position': sTumbler,
            '@noteid': this.gUniqId++,
            entrydata: [{
                '@columnnumbler': 0,
                '@name': 'Icon',
                '@category': 'true',
                '@text': sTitle,
                text: [ sTitle ]
            }]
        };

		var oEntry = new dwa.lv.treeViewEntry(oParent, oJson, oParent.oDataStore, sTumbler);
		oEntry.expand(true);
        oParent.oDataStore._items.push( oJson );
        notesValue = new dwa.common.notesValue;
        var col = oJson.entrydata[0];
        notesValue.setJsonNode( col );
        col['@type'] = notesValue.sType;
        col['@value'] = notesValue.vValue;
        oJson[ col["@name"] ] = col;
	
		return 0;
	},
	appendChildByName: function(oParent, sIcon, sName, oObj, bSkipValidate){
		var status = this.checkAppendable(oParent, sName);
		if(status != 0)
			return status;
	
		var oEntry = this.appendChildObj(oParent, sIcon, sName);
		oEntry.oObj = oObj;
	
		return 0;
	},
	appendChildObj: function(oParent, sIcon, sName){
		var sTumbler = (oParent.getTumbler() ? oParent.getTumbler() + '.' : '') + (oParent.getChildLoaded() ? oParent.getEndIndex() + 1 : 1);

        var oJson = {
            '@position':    sTumbler,
            '@noteid':      this.gUniqId++,
            '@unid':        this.gUniqId++,
            entrydata:  [
            {
                '@columnnumber':    0,
                '@name':            'Icon',
                '@category':        true,
                '@text':            sIcon,
                number:             [sIcon]
            },
            {
                '@columnnumber':    1,
                '@name':            'Name',
                '@text':            sName,
                text:               [sName]
            }
            ]
        };

        this._appendToDataStore( oParent.getTumbler(), oJson );

		return new dwa.lv.treeViewEntry(this.gRoot, oJson, this.oDataStore, sTumbler);
	},
    _appendToDataStore: function(sParentPos, oJson){
        var items = this.oDataStore._items;

        var i;
        var n = items.length;
        for( i = 0; i < n; i++ ){
            var item = items[i];
            if( item[ '@position' ] === sParentPos ) break;
        }
        if( !item ) return;
        for( ; i < n - 1; i++ ){
            var item = items[i+1];
            if( item[ '@position' ].indexOf( sParentPos ) != 0 ) break;
        }

        var notesValue = new dwa.common.notesValue;
        var entrydata = oJson.entrydata;
        n = entrydata.length;
        for( i = 0; i < n; i++ ){
            var col = oJson.entrydata[i];
            notesValue.setJsonNode( col );
            col['@type'] = notesValue.sType;
            col['@value'] = notesValue.vValue;
            oJson[ col["@name"] ] = col;
        }
    },

	checkAppendable: function(oParent, sName){
		var oInfo = this._npOptions.getInfoByTumbler(oParent.getTumbler());
		if(!oInfo)
			return 9;
		
        var ds = this.oDataStore;

		var nCount = 0;
		for(var j=oParent.getStartIndex();j<=oParent.getEndIndex();j++)
		{
			if(!oParent.oCollection.find(j))
				continue;
			var oEntry = this.gRoot.getEntryByTumbler(oParent.getTumbler() + '.' + (j));
			if(!oEntry)
				continue;
			var oXmlNode = oEntry.getXmlNode();

            var nodeVal = ds.getEntryDataByName( oXmlNode, 'Name' );
            if( nodeVal ){ nodeVal = ds.getValue( nodeVal ); }
            if( sName == nodeVal ){ return 3; }

			nCount ++;
		}
		if((oInfo.nFlags & 1) && nCount)
			return 2;
	
		return 0;
	},
	getDefaultIcon: function(){
		var sIcon = this._npOptions.get('sIconNum') || '3';
	
		return sIcon;
	},
	getIconNum: function(oObj){
		if(!oObj || !oObj.type)
			return this.getDefaultIcon();
	
		if(this._npOptions.get('sIconNum'))
			return parseInt(this._npOptions.get('sIconNum'));
		
		var sType = oObj.type.toLowerCase();
		if(oObj.directoryType == 'LDAP')
		{
			return
				(sType.indexOf('database') != -1 ? 2 :
				(sType.indexOf('person') != -1 ? 3 :
				(sType.indexOf('group') != -1 ? 4 :
				(sType.indexOf('server') != -1 ? 54 : 0))));
		}
		else {
			switch(sType) {
				case 'database': case 'databa': return 2; break;
				case 'person': case 'pers': return 3; break;
				case 'group': case 'gro': case '(groupcalendar)': return 4; break;
				case 'server': case 'serv': return 54; break;
				default: return 0; break;
			}
		}
	},
    _removeEntryFromDataStore: function( pos ){
        if( !pos ) return;
        var ds = this.oDataStore;
        var items = ds._items;
        var n = items.length;
        for( var i = 0; i < n; i++ ){
            if( pos === items[i]['@position'] ){
                items.splice( i, 1 );
                return;
            }
        }
    },
    removeSelection: function(){
        if( !this.selectedListVL ) return;

		var aUnids = this.selectedListVL.getSelectedUnids();
		if(!aUnids)
			return;

		for(var i=0;i<aUnids.length;i++)
		{
			var aEntries = this.selectedListVL.getEntriesByUnid(aUnids[i]);
			for(j=0;aEntries && j<aEntries.length;j++){
                var entry = aEntries[j];
                this._removeEntryFromDataStore( entry.getTumbler() );
				this.gRoot.removeEntry(entry);
            }
		}
		this.gRoot.update();
		this.selectedListVL.refresh(true);
    },
    removeAll: function(){
		this.initSelectedListRoot();

		if( this.selectedListVL ) this.selectedListVL.refresh(true, true);
    }
});
