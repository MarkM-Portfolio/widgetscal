/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.np.namePickerOptions");

dojo.require("dojo.i18n");
dojo.requireLocalization("dwa.np", "namePicker");


dojo.declare(
	"dwa.np.namePickerOptions",
	null,
{
    fieldLabels: [],
    fieldIds: [],
    _msgs: {},

    haiku: {
    },

    _gNPInfo: {
        oOptions: {
        },
        aFields: [
        ]
    },

    _checkProps: function(){
        this.haiku = {};
        this._gNPInfo.oOptions = {};

        if( this.preferNameForContacts ) this.haiku.bPreferNameForContacts = true;
        if( this.isOffline ) this.haiku.bIsOffline = true;
        if( this.showExtraInfoOnNamePicker ) this.haiku.bShowExtraInfoOnNamePicker = true;
        if( this.namePreference ) this.haiku.bNamePreference = true;
        if( this.hasPreferredRooms ) this.haiku.bHasPreferredRooms = true;
        if( this.hasPreferredResources ) this.haiku.bHasPreferredResources = true;
        if( this.usingHttps ) this.haiku.bUsingHttps = true;

        // 1: dialog for room, 2: dialog for resource, 3: dialog for onlinemeetringplace
        if( this.modeSpecial ){
            var v = this.modeSpecial;
            if( typeof(v) == 'string'  ) v = parseInt(v);
            this._gNPInfo.oOptions.nModeSpecial = this.modeSpecial;
        }
        if( this.disableSelectPane ) this._gNPInfo.oOptions.bDisableSelectPane = true;
        if( this.disableButtonPane ) this._gNPInfo.oOptions.bDisableButtonPane = true;

        if( this.disableAlert ) this._gNPInfo.oOptions.bDisableAlert = true;
        if( this.disallowContactFullName ) this._gNPInfo.oOptions.DisallowContactFullName = true;
        if( this.iconNum ) this._gNPInfo.oOptions.sIconNum = this.iconNum + '';

        if( this.showColumnHeader ) this._gNPInfo.oOptions.bShowColumnHeader = true;
        if( this.disableExpandNameColumn ) this._gNPInfo.oOptions.bDisableExpandNameColumn = true;
        if( typeof(this.defaultColumnWidths) == 'array' && this.defaultColumnWidths.length > 0 ){
            this._gNPInfo.oOptions.aDefaultColumnWidths = this.defaultColumnWidths;
        }
        if( typeof(this.defaultColumnTitles) == 'array' && this.defaultColumnTitles.length > 0 ){
            this._gNPInfo.oOptions.aDefaultColumnTitles = this.defaultColumnTitles;
        }
        if( this.dlgTitle ) this._gNPInfo.oOptions.sDlgTitle = this.dlgTitle;
        if( this.disableViewList ) this._gNPInfo.oOptions.bDisableViewList = true;
        if( this.disableSearchText ) this._gNPInfo.oOptions.bDisableSearchText = true;
        if( this.showNameInput ) this._gNPInfo.oOptions.bShowNameInput = true;
        if( this.disableHeader ) this._gNPInfo.oOptions.bDisableHeader = true;
        if( this.listHeaderText ) this._gNPInfo.oOptions.sListHeaderText = this.listHeaderText;
        if( this.selectHeaderText ) this._gNPInfo.oOptions.sSelectHeaderText = this.selectHeaderText;
        if( this.leftRatio ) this._gNPInfo.oOptions.nLeftRatio = this.leftRatio;

        if( this.disablePreferred ) this._gNPInfo.oOptions.bDisablePreferred = true;
        if( this.preferredList ) this._gNPInfo.oOptions.aPreferredList = this.preferredList;
        if( this.viewListOpt ) this._gNPInfo.oOptions.aViewList = this.viewListOpt;
        if( this.disableContacts ) this._gNPInfo.oOptions.bDisableContacts = true;
        if( this.disableCatalog ) this._gNPInfo.oOptions.bDisableCatalog = true;
        if( this.bDisableLDAP ) this._gNPInfo.oOptions.bDisableLDAP = true;
    },

    initOptions: function(){
        this._checkProps();

        var aFields = this._gNPInfo.aFields = [];
        var labels = this.fieldLabels;
        var ids = this.fieldIds;

        if( labels && ids ){
            var n = Math.min( labels.length, ids.length );

            for( var i = 0; i < n; i++ ){
                aFields.push( { sLabel: labels[i], sId: ids[i], bDefault: (i == 0) } );
            }
        }

        this._msgs = dojo.i18n.getLocalization("dwa.np", "namePicker", this.lang);
    },

    setDisableViewList: function(isDisabled){
        this._gNPInfo.oOptions.bDisableViewList = isDisabled;
    },

	_getNPOption: function(sProperty){
		if(!this._gNPInfo.oOptions)
			this._gNPInfo.oOptions={};
		
		if(typeof this._gNPInfo.oOptions[sProperty] != 'undefined')
			return this._gNPInfo.oOptions[sProperty];
		
		var oOptions = {};
		switch(this._gNPInfo.oOptions.nModeSpecial)
		{
			case 1: // ROOM
				oOptions = {
					bShowColumnHeader:true
					,bDisableViewList:true
					,bDisableCopyButton:true
					,bDisableSearchText:true
					,bDisableContacts:true
					,bDisableCatalog:true
					,bDisableLDAP:true
					,bDisableExpandNameColumn:true
					,aDefaultColumnWidths:[60]
					,sListHeaderText:''
					,sSelectHeaderText:this._msgs[ "L_NPW_ADDED" ]
					,bShowNameInput:true
					,sEntryType:'Room'
					,sIconNum:'69'
					,aViewList:[
						{
							sViewTitle : '($Rooms)',
							sViewName : '($Rooms)',
							sViewInfo : '$39;$4;NPName;Type;AltFullName',
							nViewType : 1,
							aDBPaths : ['*']
						}
					]
					,sDlgTitle:this._msgs[ "L_RP_TITLE_ROOMS" ]
					,sHelpUrl:"H_SELECT_A_ROOM_OR_RESOURCE_FOR_A_MEETING_STEPS.html"
					,nLeftRatio:70
					,aPreferredList:[
						{
							Title : this._msgs[ "L_PREF_ROOMS_PREFER_COMMENT" ],
							sReadViewEntriesForm : "s_ReadPreferredRooms",
							sDesignXmlId : "xmlPreferredRooms",
                            aDesignJsonArray: [
                                {}, {},
                                {
                                    "@columnnumber":"2",
                                    "@width":"160",
                                    "@name":"$4",
                                    "@title":this._msgs["L_ROOM_NAME"],
                                    "@format":"2",
                                    "@listseparator":"comma",
                                    cfont: {
                                        "@style": "r",
                                        "@size": "9",
                                        "@color": "#000000",
                                        "@face": "Helvetica"
                                    },
                                    hfont: {
                                        "@style": "r",
                                        "@size": "9",
                                        "@color": "#000000",
                                        "@face": "Helvetica"
                                    },
                                    numberformat: {
                                        "@digits": "0",
                                        "@format": "general"
                                    },
                                    datetimeformat: {
                                        "@show": "datetime",
                                        "@date": "yearmonthday",
                                        "@time": "hourminutesecond",
                                        "@zone": "never"
                                    }
                                }
                            ],
							bEnabled : this.haiku.bHasPreferredRooms
						}
					]
				};
				break;
			case 2: // RESOURCE
				oOptions = {
					bShowColumnHeader:true
					,bDisableViewList:true
					,bDisableCopyButton:true
					,bDisableSearchText:true
					,bDisableContacts:true
					,bDisableCatalog:true
					,bDisableLDAP:true
					,bDisableExpandNameColumn:true
					,aDefaultColumnWidths:[60]
					,sListHeaderText:''
					,sSelectHeaderText:this._msgs[ "L_NPW_ADDED" ]
					,bShowNameInput:true
					,sEntryType:'Resource'
					,sIconNum:'68'
					,aViewList:[
						{
							sViewTitle : '($Resources)',
							sViewName : '($Resources)',
							sViewInfo : '$39;$4;NPName;Type;AltFullName',
							nViewType : 1,
							aDBPaths : ['*']
						}
					]
					,sDlgTitle:this._msgs[ "L_RP_TITLE_RESOURCES" ]
					,sHelpUrl:"H_SELECT_A_ROOM_OR_RESOURCE_FOR_A_MEETING_STEPS.html"
					,nLeftRatio:70
					,aPreferredList:[
						{
							Title : this._msgs[ "L_PREF_RESOURCES_PREFER_COMMENT" ],
							sReadViewEntriesForm : "s_ReadPreferredResources",
							sDesignXmlId : "xmlPreferredRooms",
                            aDesignJsonArray: [
                                {}, {},
                                {
                                    "@columnnumber":"2",
                                    "@width":"160",
                                    "@name":"$4",
                                    "@title":this._msgs["L_RESOURCE_NAME"],
                                    "@format":"2",
                                    "@listseparator":"comma",
                                    cfont: {
                                        "@style": "r",
                                        "@size": "9",
                                        "@color": "#000000",
                                        "@face": "Helvetica"
                                    },
                                    hfont: {
                                        "@style": "r",
                                        "@size": "9",
                                        "@color": "#000000",
                                        "@face": "Helvetica"
                                    },
                                    numberformat: {
                                        "@digits": "0",
                                        "@format": "general"
                                    },
                                    datetimeformat: {
                                        "@show": "datetime",
                                        "@date": "yearmonthday",
                                        "@time": "hourminutesecond",
                                        "@zone": "never"
                                    }
                                }
                            ],
							bEnabled : this.haiku.bHasPreferredResources
						}
					]
				};
				break;
			case 3: // ONLINEMEETINGPLACE
				oOptions = {
					bShowColumnHeader:true
					,bShowExtendDetailButton:true
					,bDisableButtonPane:true
					,bDisableSelectPane:true
					,bDisableAlert:true
					,bDisableViewList:true
					,bDisableSearchText:true
					,bDisableContacts:true
					,bDisableCatalog:true
					,bDisableLDAP:true
					,bDisableHeader:true
					,bDisableExpandNameColumn:true
					,aDefaultColumnWidths:[60]
					,sEntryType:'OnlineMeetingPlace'
					,aViewList:[
						{
							sViewTitle : '($OnlineMeetingPlaces)',
							sViewName : '($OnlineMeetingPlaces)',
							sViewInfo : '$39;$4;NPName;Type;AltFullName',
							nViewType : 1,
							aDBPaths : ['*']
						}
					]
					,sDlgTitle:this._msgs[ "L_RP_TITLE_ONLINEMEETINGPLACES" ]
					,sHelpUrl:"H_SELECT_A_ROOM_OR_RESOURCE_FOR_A_MEETING_STEPS.html"
				};
				break;
			default:
				if(this.haiku.bShowExtraInfoOnNamePicker)
					oOptions = {
						bShowColumnHeader:true
						,nLeftRatio:70
					};
				break;
		}
	
		return oOptions[sProperty];
	},
    get: function(name){
        return this._getNPOption(name);
    },
    getLeftPaneRatio: function(){
    	var nLeftRatio = this.get('nLeftRatio');
	    return !nLeftRatio ? (this.get('bDisableSelectPane') ? 90 : 45) : Math.round(nLeftRatio*0.9);
    },
    getRightPaneRatio: function(){
	    return (90 - this.getLeftPaneRatio());
    },

    getTargetFields: function(){
        return this._gNPInfo.aFields;
    },
    getFieldCount: function(){
        return this._gNPInfo.aFields.length;
    },
	getInfoByIndex: function(nIndex){
		if(nIndex<0 || nIndex>=this._gNPInfo.aFields.length)
			return null;
		return this._gNPInfo.aFields[nIndex];
	},
	getInfoByTumbler: function(sTumbler){
		var nIndex = parseInt(sTumbler) - 1;
		return this.getInfoByIndex(nIndex);
	},
    isDefaultTargetField: function(nIndex){
        var info = this.getInfoByIndex(nIndex);
        return (info && info.bDefault);
    },
    getTargetFieldLabel: function(nIndex){
        var info = this.getInfoByIndex(nIndex);
        return info ? info.sLabel : null;
    },

//#define D_NP_FLAG_SINGLEENTRY		1
//#define D_NP_FLAG_PRIMARYNAME		2
//#define D_NP_FLAG_WITHOUTDOMAIN		4
	checkIfAllowMultiple: function(){
		for(var i=0;i<this._gNPInfo.aFields.length;i++)
			if(!(this._gNPInfo.aFields[i].nFlags & 1))
				return true;
		return false;
	}
});
