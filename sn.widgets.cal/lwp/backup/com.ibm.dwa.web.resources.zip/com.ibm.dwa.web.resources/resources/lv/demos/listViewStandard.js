/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.lv.demos.listViewStandard");

dojo.require("dwa.lv.listView");
dojo.require("dwa.lv.demos.DominoDataActions");

dojo.declare(
	"dwa.lv.demos.listViewStandard",
	dwa.lv.listView,
{
	contextMenu: null,
	contextMenuInfo: null,
	
	postMixInProperties: function() {
		this.inherited(arguments);
		if (this._actionsObjs.length == 0) {
			for (var i = 0; i < this._stores.length; i++) {
				if (this._stores[i] instanceof dwa.data.DominoDataStore) {
					this._actionsObjs.push(new dwa.lv.demos.DominoDataActions({
						storeRef: this._stores[i],
						widget: this
					}));
				}
			}
		}
	},
	
	destroy: function() {
		if (this.contextMenu) {
			this.contextMenu.destroy();
		}
		this.inherited(arguments);
	},
	
	handleContextMenu: function(ev, items) {
		dojo["require"]("dwa.common.contextMenu");
		if (!this._isInitContextMenuInfo) {
			this._initContextMenuInfo();
			this._isInitContextMenuInfo = true;
		}
		this._setContextMenuInfo(ev, items);
		
		var _focus = dojo.hitch(this, function(){this.oVL.focus()});
		var _this = this;
		var _ev = dojo.isIE ? dojo.mixin({}, ev) : ev;
		dojo.addOnLoad(function() {
			if (!_this.contextMenu) {
				_this.contextMenu = new dwa.common.contextMenu({
					menuInfo: _this.contextMenuInfo,
					defaultImageModule: "dwa.common",
					defaultConsolidatedImage: "images/basicicons.gif",
					focusMethod: _focus,
					id: _this.sId + "-contextmenu"
				});
			}
			_this.contextMenu.show(_ev);
		});
	},
	
	_initContextMenuInfo: function() {
		this.contextMenuInfo = [{
			label: "Open",
			scope: this,
			action: "openEntryAction"
		}, {
			label: "Refresh",
			iconInfo: [16, 16, 0, 0],
			scope: this,
			action: "refreshEntryAction"
		}, {
			label: "New",
			iconInfo: [16, 16, 180, 40],
			scope: this,
			action: "newEntryAction"
		}, {
			label: "Delete",
			iconInfo: [14, 17, 120, 0],
			scope: this,
			action: "deleteEntryAction"
		}];
	},
	
	_setContextMenuInfo: function(ev, items) {
		if (items && items.length != 0) {
			this.contextMenuInfo[0].args = this.contextMenuInfo[3].args = [items];
			this.contextMenuInfo[0].isDisabled = this.contextMenuInfo[3].isDisabled = false;
		} else {
			this.contextMenuInfo[0].isDisabled = this.contextMenuInfo[3].isDisabled = true;
		}
	},
	
	refreshEntryAction: function() {
		this.refresh(true, false);
	}
});
