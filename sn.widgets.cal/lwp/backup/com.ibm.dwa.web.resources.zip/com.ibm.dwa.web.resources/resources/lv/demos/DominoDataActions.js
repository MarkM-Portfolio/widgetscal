/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.lv.demos.DominoDataActions");

dojo.declare(
	"dwa.lv.demos.DominoDataActions",
	null,
{
	widget: null,
	storeRef: null,
	
	constructor: function(args) {
		if (args) {
			dojo.mixin(this, args);
		}
	},
	
	openEntryAction: function(items) {
		alert("DominoDataActions#openEntryAction: " + this._getPositions(items).join(','));
	},
	
	newEntryAction: function() {
		alert("DominoDataActions#newEntryAction");
	},
	
	selectEntryAction: function(items, selectionMode) {
		console.log("DominoDataActions#selectEntryAction: " + this._getPositions(items).join(','));
	},
	
	deleteEntryAction: function(items) {
		alert("DominoDataActions#deleteEntryAction: " + this._getPositions(items).join(','));
	},
	
	_getPositions: function(items) {
		var positions = [];
		for(var i = 0; i < items.length; i++) {
			positions.push(items[i]["@position"]);
		}
		return positions;
	}
});
