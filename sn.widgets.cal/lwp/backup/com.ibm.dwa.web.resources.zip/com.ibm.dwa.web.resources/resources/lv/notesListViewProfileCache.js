/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.lv.notesListViewProfileCache");

dojo.require("dwa.lv.widgetListener");
dojo.require("dwa.lv.globals");

dojo.declare(
	"dwa.lv.notesListViewProfileCache",
	null,
{
	constructor: function(){
	    this.oProfileCache = {};
	},
	get: function(sItemName){
	    return this.oProfileCache[sItemName] ? this.oProfileCache[sItemName] : '';
	},
	set: function(sItemName, sValue, bUpdateProfile, sId){
	    if(typeof(this.oProfileCache[sItemName]) != 'undefined' && this.oProfileCache[sItemName] != sValue && bUpdateProfile && sId) {
	        dwa.lv.widgetListener.prototype.oClasses["com_ibm_dwa_io_actionStoreProfileField"] = ['Common'];
	        dwa.lv.globals.invokeActionDummy(null, sId, 'com_ibm_dwa_io_actionStoreProfileField', {sProfile:"iNotesViewProfile", sField:sItemName, sValue:sValue, oListener:null, bTextList:false});
	    }
	    this.oProfileCache[sItemName] = sValue;
	}
});
