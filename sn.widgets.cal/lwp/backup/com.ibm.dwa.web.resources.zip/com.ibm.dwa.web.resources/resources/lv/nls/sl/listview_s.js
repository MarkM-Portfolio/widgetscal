({
L_CANCEL: "Prekli\u010di",
L_DOCUMENTS_SELECTED: "%1 documents selected",
L_ENTRY_NOT_FOUND: "Vnosa ni mogo\u010de najti",
L_ERR_INVALIDDATE: "Navedli ste neveljaven datum.",
L_FETCHING: "Pridobivanje zapisov  . . .",
L_FETCHINGNEXT: "Pridobivanje prej\u0161nje strani zapisov. . .",
L_FETCHINGPREV: "Pridobivanje prej\u0161nje strani zapisov. . .",
L_NARROW_DEFAULT: "Privzeto razvrsti",
L_NARROW_NOTITLE: "Brez naslova",
L_NARROW_SORTBY: "Razvrsti po %1",
L_SEARCH: "Iskanje",
L_STARTSWITH_COLUMN: "Izberite stolpec, ki ga \u017eelite razvrstiti po:",
L_STARTSWITH_INVALID_NUMBER: "Dolo\u010dena je neveljavna \u0161tevilka",
L_STARTSWITH_SEARCH: "Iskanje vnosov, ki se za\u010dnejo z:",
L_STARTSWITH_TITLE: "Se za\u010dne z ...",
L_UPDATINGVIEW_MESSAGE: "Pogled se verjetno ravnokar posodablja v stre\u017eniku.\nPrikazal se bo takoj, ko bo posodobitev kon\u010dana.\nNadaljujete lahko z delom na drugih karticah, ali pa posku\u0161ate dostopati do drugih pogledov/map.",
L_VIEWMAIL: "Po\u0161ta"
})
