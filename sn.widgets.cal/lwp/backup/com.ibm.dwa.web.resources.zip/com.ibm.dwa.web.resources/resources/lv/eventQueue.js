/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.lv.eventQueue");

dojo.require("dwa.lv.widgetListener");

dojo.declare(
	"dwa.lv.eventQueue",
	null,
{
	soQueue: 0,

	constructor: function(){
		this.oQueue = {};
	},
	attach: function(oWidget, sType, fStopPropagation){
		var oElem = dojo.doc.getElementById(oWidget.sId);
		var sTarget = oElem.getAttribute('com_ibm_dwa_ui_widget_eventQueueTarget');
		var asTarget = sTarget ? sTarget.split(' ') : [oWidget.sId];
		var sClass = oElem.getAttribute('com_ibm_dwa_ui_widget_class');
		var asClass = sClass ? sClass.split(' ') : [];
		var sName = oWidget.sId + ':' + sClass;
		var oQueue = this.oQueue;
	
		function dojo_ui_eventQueue_handleEvent(ev){
		 if( dojo.isIE ){
			var oEvent = document.createEventObject(ev);
			oQueue[sName] = [oEvent].concat(oQueue[sName] ? oQueue[sName] : []);
		 }else{ // I
			var oEvent = document.createEvent('MouseEvents');
			oEvent.initMouseEvent(ev.type, ev.bubbles, ev.cancelable, window, ev.detail, ev.screenX, ev.screenY,
			 ev.clientX, ev.clientY, ev.ctrlKey, ev.altKey, ev.shiftKey, ev.metaKey, ev.button, null);
			oQueue[sName] = [oEvent, ev.target].concat(oQueue[sName] ? oQueue[sName] : []);
		 } // end - GS
			for(var i=0;i<asClass.length;i++)
				new dwa.lv.widgetListener(oWidget.sId, asClass[i] + ':handleEvent');
			if (fStopPropagation) {
				(dojo.isIE ? (ev.cancelBubble = true) : (dojo.isFF ? (ev.stopPropagation()) : (ev.stopPropagation()) ) );
		// #XMXL7Z65M6: Firefox 3.6 also needs this to avoid default context menu.
		 if(dojo.isFF || dojo.isWebKit){
				(dojo.isIE ? (ev.returnValue = false) : (dojo.isFF ? (ev.preventDefault()) : (ev.preventDefault()) ) );
		 } // end - S
				return false;
			}
		}
	
		for (var i = 0; i < asTarget.length; i++)
			(dojo.isIE ? (dojo.doc.getElementById(asTarget[i]).attachEvent("on" + sType, dojo_ui_eventQueue_handleEvent)) : (dojo.isFF ? (dojo.doc.getElementById(asTarget[i]).addEventListener(sType, dojo_ui_eventQueue_handleEvent, false)) : (dojo.doc.getElementById(asTarget[i]).addEventListener(sType, dojo_ui_eventQueue_handleEvent, false)) ) );
	}
});

dwa.lv.eventQueue.get = function(){
	if( dwa.lv.eventQueue.prototype.soQueue === 0 ){
		dwa.lv.eventQueue.prototype.soQueue = new dwa.lv.eventQueue;
	}
	return dwa.lv.eventQueue.prototype.soQueue
};
