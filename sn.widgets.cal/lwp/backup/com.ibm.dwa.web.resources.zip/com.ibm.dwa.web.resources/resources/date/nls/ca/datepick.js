({
L_CHARDAY_FRI: "dv",
L_CHARDAY_MON: "dl",
L_CHARDAY_SAT: "ds",
L_CHARDAY_SUN: "dg",
L_CHARDAY_THU: "dj",
L_CHARDAY_TUE: "dt",
L_CHARDAY_WED: "dc"
})
