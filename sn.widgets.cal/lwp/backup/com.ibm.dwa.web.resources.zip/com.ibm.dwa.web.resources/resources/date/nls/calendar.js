/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                          */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// NLS_CHARSET=UTF-8
({
D_ADAR_ALEF_NUMBER: "I",
D_ADAR_BET_NUMBER: "II",
D_CAL_DEFAULTFIRSTDAYFIVEDAY: "1",
D_CAL_DEFAULTFIRSTDAYMONTH: "0",
D_CAL_DEFAULTFIRSTDAYWEEK: "1",
D_DTFMT_DATE0: "MM-dd-yyyy",
D_DTFMT_DATESEP0: "/",
D_DTFMT_DAYDATE: "dddd %1",
D_DTFMT_DAYMONTHDATE: "dddd - MMMM %1",
D_DTFMT_FULLDATE0: "dddd, MMMM dd, yyyy",
D_DTFMT_FULLMONTH4YR: "MMMM %1, yyyy",
D_DTFMT_MEDIUMDATE: "ddd %1",
D_DTFMT_MONTH4YR: "MMMM yyyy",
D_DTFMT_SHORTMONTH4YR: "MMM %1, yyyy",
D_DTFMT_TIME0: "hh:mmt",
D_DTFMT_TIMESEP0: ":",
D_DTFMT_WEEKDATE: "ddd d",
L_ALTCAL_JEWISH_MONTH_LIST: "Adar|Nisan|Iyyar|Sivan|Tammuz|Av|Elul",
L_ALTCAL_JEWISH_MONTH_LIST2: "Tishrei|Heshvan|Kislev|Tevet|Shvat",
L_ALTCAL_SIXDAY_LIST: "Sensho|Tomobiki|Senbu|Butsumetsu|Taian|Shakko",
L_AM_SUFFIX: "AM",
L_FULLDAY_FRI: "Friday",
L_FULLDAY_MON: "Monday",
L_FULLDAY_SAT: "Saturday",
L_FULLDAY_SUN: "Sunday",
L_FULLDAY_THU: "Thursday",
L_FULLDAY_TUE: "Tuesday",
L_FULLDAY_WED: "Wednesday",
L_FULLMONTH_APR: "April",
L_FULLMONTH_AUG: "August",
L_FULLMONTH_DEC: "December",
L_FULLMONTH_FEB: "February",
L_FULLMONTH_JAN: "January",
L_FULLMONTH_JUL: "July",
L_FULLMONTH_JUN: "June",
L_FULLMONTH_MAR: "March",
L_FULLMONTH_MAY: "May",
L_FULLMONTH_NOV: "November",
L_FULLMONTH_OCT: "October",
L_FULLMONTH_SEP: "September",
L_PM_SUFFIX: "PM",
L_SHORTDAY_FRI: "Fri",
L_SHORTDAY_MON: "Mon",
L_SHORTDAY_SAT: "Sat",
L_SHORTDAY_SUN: "Sun",
L_SHORTDAY_THU: "Thu",
L_SHORTDAY_TUE: "Tue",
L_SHORTDAY_WED: "Wed",
L_SHORTMONTH_APR: "Apr",
L_SHORTMONTH_AUG: "Aug",
L_SHORTMONTH_DEC: "Dec",
L_SHORTMONTH_FEB: "Feb",
L_SHORTMONTH_JAN: "Jan",
L_SHORTMONTH_JUL: "Jul",
L_SHORTMONTH_JUN: "Jun",
L_SHORTMONTH_MAR: "Mar",
L_SHORTMONTH_MAY: "May",
L_SHORTMONTH_NOV: "Nov",
L_SHORTMONTH_OCT: "Oct",
L_SHORTMONTH_SEP: "Sep"
})
