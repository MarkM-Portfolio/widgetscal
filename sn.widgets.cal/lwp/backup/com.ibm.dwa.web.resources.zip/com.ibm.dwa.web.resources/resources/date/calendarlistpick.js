/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.date.calendarlistpick");

dojo.require("dwa.common.commonProperty");
dojo.require("dwa.date.calendar");
dojo.require("dwa.common.menu");

dojo.declare(
	"dwa.date.calendarlistpick",
	null,
{
	// ---------------------------------------------------------
	// calendar list picker base
	// extender need to set properties:
	//  nEntries: # of the entries
	// extender need to implement:
	//  getFormatter: specify formatter
	//  adjustCalendar: to get 'n'th index from given calendar.
	//  needUpdate: determine if caption should be updated.
	// --------------------------------------------------------
	constructor: function(sId){
		if(!sId)
			return;
		var oElem = dojo.doc.getElementById(this.sId = sId);
		var sStartOffset = oElem.getAttribute(this.sClass + '_startOffset');
		this.nStartOffset = sStartOffset ? sStartOffset * 1 : 0;
		var oProperty = dwa.common.commonProperty.get(this.com_ibm_dwa_misc_observes_calendar = oElem.getAttribute('com_ibm_dwa_misc_observes_calendar'));
		oProperty.attach(this);
		this.observe(oProperty);
		if(this.nStartOffset)
			this.nActiveIndex = 0 - this.nStartOffset;
		
		this.menuInfo = [];
		var captions = this.getCaptions();
		var actions = this.getActions();
		for(var i = 0; i < captions.length; i++){
			this.menuInfo[i] = {
				label: captions[i],
				action: actions[i],
				context: this,
				scope: this
			};
		}
		this.menu = new dwa.common.menu({
			menuInfo: this.menuInfo,
			activeIndex: this.nActiveIndex
		}, oElem);
		this.menu.startup();
	},
	observe: function(oProperty){
		if(oProperty.isLatest && !oProperty.isLatest())
			return;
		this.oCalendar = oProperty.vValue ? (new dwa.date.calendar).setISO8601String(oProperty.vValue)
		 : (new dwa.date.calendar).setDate(new Date);
		if('function' == typeof(this.onCalendarUpdated))
			this.onCalendarUpdated();
	},
	destroy: function() {
		this.menu.destroy();
		dwa.common.commonProperty.get(this.com_ibm_dwa_misc_observes_calendar).detach(this);
	},
	getCaptions: function(){
		if(this.needUpdate()){
			this.asCaptions = [];
			var oCalendar = this.oCalendar.clone();
			var oFormatter = this.getFormatter();
			if(this.nStartOffset)
				oCalendar = this.adjustCalendar(oCalendar, this.nStartOffset);
			for(var i = 0; i < this.nEntries; i++){
				this.asCaptions.push(oFormatter.format(oCalendar));
				oCalendar = this.adjustCalendar(oCalendar, 1);
			}
			this.oPrevCalendar = this.oCalendar.clone();
		}
		return this.asCaptions;
	},
	getActions: function(){
		if(this.asActions.length == 0){
			for(var i = 0; i < this.nEntries; i++) {
				this.asActions[i] = (function(i){
					return function(){
						return this.entrySelected(i);
					}
				})(i);
			}
		}
		return this.asActions;
	},
	refresh: function(){
		if(!this.needUpdate())
			return;
		var oElem = dojo.doc.getElementById(this.sId);
		var captions = this.getCaptions();
		for(var i = 0; i < this.nEntries; i++){
			this.menuInfo[i].label = captions[i];
		}
		this.menu.refresh();
	},
	entrySelected: function(nIndex){
		this.oCalendar = this.adjustCalendar(this.oCalendar, nIndex + (this.nStartOffset ? this.nStartOffset : 0));
		var oProp = dwa.common.commonProperty.get(this.com_ibm_dwa_misc_observes_calendar);
	
		if(oProp.vValue){
			var oOrgCalendar = (new dwa.date.calendar).setISO8601String(oProp.vValue);
			oOrgCalendar.set(this.oCalendar);
			oProp.setValue('' + oOrgCalendar);
		}else
			oProp.setValue('' + this.oCalendar);
	}
});
