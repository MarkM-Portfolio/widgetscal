/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.cv.demos.NotesCalendarActions");

dojo.declare(
	"dwa.cv.demos.NotesCalendarActions",
	null,
{
	widget: null,
	storeRef: null,
	
	constructor: function(args) {
		if (args) {
			dojo.mixin(this, args);
		}
	},
	
	newEntryAction: function(oCalendar) {
		alert("NotesCalendarActions#newEntryAction: " + oCalendar);
	},
	
	openEntryAction: function(items) {
		alert("NotesCalendarActions#openEntryAction: " + items[0].subject);
	},
	
	selectEntryAction: function(items) {
		console.log("NotesCalendarActions#selectEntryAction: " + items[0].subject);
	},
	
	deleteEntryAction: function(items) {
		alert("NotesCalendarActions#deleteEntryAction: " + items[0].subject);
	},
	
	rescheduleEntryAction: function(item, oCalendar) {
		alert("NotesCalendarActions#rescheduleEntryAction: " + item.subject + " -> " + oCalendar);
	}
});
