/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_Names.h

dojo.provide("dwa.common.nameEntities");


dojo.declare(
	"dwa.common.nameEntities",
	null,
{
	constructor: function(aoEntities){
		this.aoEntities = aoEntities ? aoEntities : [];
		this.asLang = [];
	},

	difference: function(oElem1, oElem2){
		var sName1 = oElem1.getDisplayName().sAddress.toLowerCase();
		var sName2 = oElem2.getDisplayName().sAddress.toLowerCase();
		return sName1 > sName2 ? 1 : sName1 < sName2 ? -1 : 0;
	},

	setItemValues: function(oNote, sItemName, fUsePrimWithoutLang){
		var asMap = this.oMap[sItemName.toLowerCase()];
		var sPrimItemName = sItemName;
		var sAltItemName = asMap ? asMap[0] : '';
		var sInetItemName = asMap ? asMap[1] : '';
		var sLangItemName = asMap ? asMap[2] : '';
	
		var vPrimName = oNote.getItemValue(sPrimItemName);
		//for FF, if vPrimName is a string, vPrimName[0] is defined, so better to check the type first.
		var asPrimName = !vPrimName ? [] : typeof(vPrimName) == 'string' ? [vPrimName] : vPrimName[0] ? vPrimName : [];
		var vAltName = sAltItemName ? oNote.getItemValue(sAltItemName) : '';
		var asAltName = !vAltName ? [] : typeof(vAltName) == 'string' ? [vAltName] : vAltName[0] ? vAltName : [];
		var vInetName = sInetItemName ? oNote.getItemValue(sInetItemName) : '';
		var asInetName = !vInetName ? [] : typeof(vInetName) == 'string' ? [vInetName] : vInetName[0] ? vInetName : [];
	
		for (var i = 0; i < asPrimName.length; i++) {
			var oAltName = asAltName[i] ? new dwa.common.name(asAltName[i]) : void 0;
			var oInetName = asInetName[i] ? new dwa.common.name(asInetName[i]) : void 0;
			this.aoEntities[this.aoEntities.length]
			 = new dwa.common.nameEntity(new dwa.common.name(asPrimName[i]), oAltName, oInetName, void 0, void 0, fUsePrimWithoutLang);
		}
	
		var vLang = sLangItemName ? oNote.getItemValue(sLangItemName) : '';
		var asLang = vLang ? (typeof(vLang[0]) == "string" ? vLang : (typeof(vLang) == "string" ? vLang.split(',') : [])) : [];
		for (var i = 0; i < asLang.length; i++)
			asLang[i] = (asLang[i]).replace(/^\s\s*/, '').replace(/\s*\s$/, '');
	
		this.asLang = this.asLang.concat(asLang);
		this.asLang.sort();
	
		for (var i = this.asLang.length - 1; i >= 1; i--) {
			if (this.asLang[i - 1] == this.asLang[i])
				this.asLang.splice(i, 1);
		}
	
		var fnCustom_NameSetItemValues_Lite = window.Custom_NameSetItemValues_Lite || window.Base_NameSetItemValues_Lite;
		fnCustom_NameSetItemValues_Lite && fnCustom_NameSetItemValues_Lite(this, oNote, sItemName);
		return this;
	},

	unique: function(){
		this.aoEntities.sort(this.difference);
	
		for (var i = this.aoEntities.length - 1; i >= 1; i--) {
			if (this.aoEntities[i - 1].equals(this.aoEntities[i]))
				this.aoEntities.splice(i, 1);
		}
	
		return this;
	},

	subtract: function(oNameEntities){
		for (var i = this.aoEntities.length - 1; i >= 0; i--) {
			for (var j = 0; j < oNameEntities.aoEntities.length; j++) {
				if (this.aoEntities[i].equals(oNameEntities.aoEntities[j]))
					this.aoEntities.splice(i, 1);
			}
		}
	
		return this;
	},

	getNameObject: function(nIndex){
		return !this.aoEntities[nIndex] ? void 0 :
		 !(this.aoEntities[nIndex] instanceof dwa.common.nameEntity) ? this.aoEntities[nIndex] :
		 this.bPreferRFC822 ? this.aoEntities[nIndex].oInetName :
		 this.aoEntities[nIndex].getDisplayName(this.asLang);
	},

	getName: function(nIndex, sMode){
		var oName = this.getNameObject(nIndex);
		var fnCustom_GetName_Lite = window.Custom_GetName_Lite || window.Base_GetName_Lite;
		var sCustomName = this.fnCustom_GetName_Lite && this.fnCustom_GetName_Lite(this, nIndex, sMode);
		var sAddressWithDomain = oName ? (oName.sAddress + (oName.asNotesDomain ? ("@" + oName.asNotesDomain.join("@")) : '')) : '';
		// When sending a memo, we shouldn't trim Notes domain
		// SPR #SNES7TJLF3 - asudoh 7/1/2009
		return sCustomName ? sCustomName : !oName ? void 0 :
		 sMode == 'mailinfosummary' ? (oName.sPhrase ? oName.sPhrase : oName.getParsed()["CN"]) :
		 sMode == 'dispaddress' ? oName.sAddress :
		 sMode == 'address' ? sAddressWithDomain :
		 sMode == 'signseal' ? (oName.f822 && oName.sEncAddress ? oName.sEncAddress : sAddressWithDomain) :
		 sMode == 'nodomsignseal' ? (oName.f822 && oName.sEncAddress ? oName.sEncAddress : oName.sAddress) :
		 oName.sDispName ? oName.sDispName : 
		oName.getAbbrev();
	},

	getNames: function(sMode){
		var asNames = [];
		for (var i = 0; i < this.aoEntities.length; i++) {
			var sName = this.getName(i, sMode);
			if (sName)
				asNames[asNames.length] = sName;
		}
		return asNames;
	},

	getLength: function(){
		return this.aoEntities.length;
	},

	oMap: {
		owner: ['AltOwner', 'INetOwner', 'x_LangOwner'],
		principal: ['x_AltPrincipal', 'x_INetPrincipal', 'x_LangPrincipal'],
		from: ['AltFrom', 'INetFrom', 'x_LangFrom'],
		sendto: ['AltSendTo', 'INetSendTo', 'x_NameLanguageTags'],
		copyto: ['AltCopyTo', 'INetCopyTo', 'x_NameLanguageTags'],
		blindcopyto: ['AltBlindCopyTo', 'INetBlindCopyTo', 'x_NameLanguageTags'],
		replyto: ['AltReplyTo', 'x_INetReplyTo', 'x_LangReplyTo'],
		chair: ['AltChair', '', 'x_LangChair'],
		requiredattendees: ['AltRequiredNames', 'INetRequiredNames', 'x_NameLanguageTags'],
		optionalattendees: ['AltOptionalNames', 'INetOptionalNames', 'x_NameLanguageTags'],
		fyiattendees: ['AltFYINames', 'INetFYINames', 'x_NameLanguageTags'],
		assignedto: ['AltRequiredNames', 'INetRequiredNames', 'x_NameLanguageTags'],
		optionalassignedto: ['AltOptionalNames', 'INetOptionalNames', 'x_NameLanguageTags'],
		fyiassignedto: ['AltFYINames', 'INetFYINames', 'x_NameLanguageTags'],
		organizer: ['AltOrganizer', '', 'x_LangOrganizer'],
		delegator: ['AltDelegator', '', 'x_LangDelegator'],
		delegee: ['AltDelegeename', '', 'x_LangDelegee'],
		members: ['AltMembers', '', 'x_LangMembers'],
		intendedrecipient: ['AltIntendedRecipient', '', 'x_LangIntendedRecipient']
	}
});
