/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_Names.h

dojo.provide("dwa.common.nameEntity");

dojo.require("dwa.common.utils");

dojo.declare(
	"dwa.common.nameEntity",
	null,
{

	constructor: function(oPrimName, oAltName, oInetName, sLang, sDomain, fUsePrimWithoutLang){
		this.oPrimName = oPrimName;
		this.oAltName = oAltName;
		this.oInetName = oInetName;
		this.sLang = sLang;
		this.sDomain = sDomain;
		this.fUsePrimWithoutLang = !!fUsePrimWithoutLang;
	},

	equals: function(oNameEntity){
		var asAddressSrc = [this.oPrimName, this.oAltName, this.oInetName];
		var asAddressDst = [oNameEntity.oPrimName, oNameEntity.oAltName, oNameEntity.oInetName];
	
		function fnCompare(oSrc, oDst){
			return (oSrc ? oSrc.getNormalized().toLowerCase() : '') == (oDst ? oDst.getNormalized().toLowerCase() : '');
		}
	
		for (var i = 0; i < asAddressSrc.length; i++) {
			//WHCN7BM8HN: 
			//the inet value may be '.'; should not treat it as equal
			if (asAddressSrc[i] == '.')  
				continue;
			if (asAddressSrc[i] && dwa.common.utils.indexOf(asAddressDst, asAddressSrc[i], fnCompare) >= 0)
				return true;
		}
	
		return !this.oPrimName.sAddress && !oNameEntity.oPrimName.sAddress;
	},
	
	getDisplayName: function(asLang){
		asLang = asLang && asLang[0] ? asLang : this.sLang ? [this.sLang] : [];
	
		var fnCompare = function(oSrc, oDst){ return oSrc.toLowerCase() == oDst.toLowerCase(); };
		// ignored asLang.length to show alternate name if no value is present in lang item such as name picked from namepicker. same as s_AltName.h
		var fUseAltName = dwa.common.sLanguagePreference && dwa.common.bNamePreference;
	
		// If this.fUsePrimWithoutLang flag is enabled and the lang item is blank, use primary name.
		// Note: this.fUsePrimWithoutLang should be used only when the names (including alternate names) are retrieved from the parent note.
		//       e.g. the case of reply, reply to all, and copy into new.
		if (this.fUsePrimWithoutLang && (asLang.length == 0 || (asLang.length == 1 && !asLang[0])))
			fUseAltName = false;
	
		if (fUseAltName) {
			for (var asLangPref = dwa.common.sLanguagePreference.split(','), i = 0; i < asLang.length; i++) {
				if (dwa.common.utils.indexOf(asLangPref, asLang[i], fnCompare) < 0) {
					fUseAltName = false;
					break;
				}
			}
		}
	
		return !fUseAltName || !this.oAltName ? this.oPrimName : this.oAltName;
	},
	
	setJsonNode: function(oNode){
		this.oContents = {};
		for (var oEntryData = oNode['entrydata'], i = 0; i < oEntryData.length; i++) {
			var sName = oEntryData[i]['@name'];
			this.oContents[sName] = sName != 'members' ?
				(new dwa.common.notesValue).setJsonNode(oEntryData[i]).vValue : oEntryData[i].viewentries.viewentry;
		}
		this.sNoteId = oNode['@noteid'];
		this.sUnid = oNode['@unid'];
		if (!this.sUnid) {
			// SPR# LWAG82CBDZ: no unid for DI records (LLN2) causes ambiguous names dialog to select all records
			// similar to TreeViewEntry.generateUnid
			var sUnique	= '000000000000000000000000000000' + (new Date()).getTime() + this.sNoteId;
			this.sUnid  = sUnique.substr(sUnique.length - 32);
		}
	
		this.sType = this.oContents['type'];
		var fIsNGroup = (this.sType == 'Group' && this.oContents['directoryType'] == 'NOTES');
	
		this.oPrimName = new dwa.common.name(this.oContents['fullName'], fIsNGroup);
		this.oAltName
		 = new dwa.common.name(this.oContents['altFullName'] ? this.oContents['altFullName'] : this.oContents['fullName'], fIsNGroup);
		this.oInetName = this.oContents['internetAddress'] ? new dwa.common.name(this.oContents['internetAddress']) : void 0;
		this.sLang = this.oContents['altNameLanguage'];
		this.sDomain = this.oContents['mailDomain'];
		this.nFlags = this.oContents['flags'];
	
		//process members if exists
		if (this.oContents['members']) {
			var aoMembers = [];
			for (var aoMembersNode = this.oContents['members'], k = 0; aoMembersNode && k < aoMembersNode.length; k++) {
				var oNameEntity = (new dwa.common.nameEntity).setJsonNode(aoMembersNode[k]);
				aoMembers.push(this.oContents['directoryType'] != 'CONTACTS' ? oNameEntity : oNameEntity.oPrimName);
			}
			this.aoMembers = new dwa.common.nameEntities(aoMembers);
		}
	
		// save abbreviated AltName, in case it gets modified below
		var sAbbrName = this.oAltName.getAbbrev();
	
		// For contact entry, abbreviate the fullName/altFullName attribute and use it for display name.
		// Also, make sure we have the right address for routing.
		// The display name and the address for routing can totally be different for contact entry.
		// SPR #LSHR72UC2D, #PTHN795R29 - asudoh 11/29/2007
		if (this.oContents['directoryType'] == 'CONTACTS' && this.oContents['mailAddress']) {
			this.oPrimName.sDispName = this.bPreferNameForContacts ? this.oPrimName.getAbbrev() : this.oContents['mailAddress'];
			this.oAltName.sDispName = this.bPreferNameForContacts ? this.oAltName.getAbbrev() : this.oContents['mailAddress'];
			this.oPrimName.sAddress = this.oAltName.sAddress = this.oContents['mailAddress'];
			// Due to a fix for SPR# THIO72ME9S, the internetAddress field will be empty
			//	for a contact created in iNotes.  Use mailAddress, if oInetName is empty or not RFC822.
			if (this.bPreferRFC822 && (!this.oInetName || !this.oInetName.fInet))
				this.oInetName = new dwa.common.name(this.oContents['mailAddress']);
		}
	
		// fixup oInetName if not RFC-822
		if (this.bPreferRFC822 && this.oInetName && this.oInetName.fInet && !this.oInetName.sPhrase)
			this.oInetName = new dwa.common.name(sAbbrName + ' <' + this.oInetName.sAddress + '>');
	
		return this;
	}
});

dwa.common.nameEntity.prototype.toString = dwa.common.nameEntity.prototype.getDisplayName;
