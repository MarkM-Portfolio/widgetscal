/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

/*--------------- dwa menu ---------------*/
var dwaListViewMenuInfo = [{
	label: "Open",
	action: "showMessageAction",
	args: ["Open"]
}, {
	label: "Refresh",
	iconInfo: [16, 16, 0, 0],
	action: "showMessageAction",
	args: ["Refresh"]
}, {
	isSeparator: true
}, {
	label: "New",
	iconInfo: [16, 16, 180, 40],
	subMenu: [{
		label: "Message",
		action: "showMessageAction",
		args: ["Message"]
	}, {
		label: "Phone Message",
		action: "showMessageAction",
		args: ["Phone Message"]
	}, {
		isSeparator: true
	}, {
		label: "Meeting",
		action: "showMessageAction",
		args: ["Meeting"]
	}, {
		label: "Contact",
		action: "showMessageAction",
		args: ["Contact"]
	}, {
		label: "Group",
		action: "showMessageAction",
		args: ["Group"]
	}, {
		label: "Appointment",
		action: "showMessageAction",
		args: ["Appointment"]
	}, {
		label: "Reminder",
		action: "showMessageAction",
		args: ["Reminder"]
	}, {
		label: "Notebook Page",
		action: "showMessageAction",
		args: ["Notebook Page"]
	}, {
		label: "To Do",
		action: "showMessageAction",
		args: ["To Do"]
	}, {
		isSeparator: true
	}, {
		label: "Folder",
		action: "showMessageAction",
		args: ["Folder"]
	}]
}, {
	label: "Reply",
	iconInfo: [16, 16, 129, 62],
	subMenu: [{
		label: "Reply with History Only",
		action: "showMessageAction",
		args: ["Reply with History Only"]
	}, {
		label: "Reply with History & Attachments",
		action: "showMessageAction",
		args: ["Reply with History & Attachments"]
	}, {
		label: "Reply",
		action: "showMessageAction",
		args: ["Reply"]
	}, {
		isSeparator: true
	}, {
		label: "Reply with Internet-Style History",
		action: "showMessageAction",
		args: ["Reply with Internet-Style History"]
	}]
}, {
	label: "Reply To All",
	iconInfo: [17, 17, 149, 62],
	subMenu: [{
		label: "Reply To All with History Only",
		action: "showMessageAction",
		args: ["Reply To All with History Only"]
	}, {
		label: "Reply To All with History & Attachments",
		action: "showMessageAction",
		args: ["Reply To All with History & Attachments"]
	}, {
		label: "Reply To All",
		action: "showMessageAction",
		args: ["Reply To All"]
	}, {
		isSeparator: true
	}, {
		label: "Reply To All with Internet-Style History",
		action: "showMessageAction",
		args: ["Reply To All with Internet-Style History"]
	}]
}, {
	label: "Forward",
	iconInfo: [16, 16, 160, 40],
	subMenu: [{
		label: "Forward with Attachments",
		action: "showMessageAction",
		args: ["Forward with Attachments"]
	}, {
		label: "Forward",
		action: "showMessageAction",
		args: ["Forward"]
	}, {
		isSeparator: true
	}, {
		label: "Internet-Style Forward",
		action: "showMessageAction",
		args: ["Internet-Style Forward"]
	}]
}, {
	isSeparator: true
}, {
	label: "Folder",
	iconInfo: [16, 16, 119, 39],
	subMenu: [{
		label: "Move to Folder...",
		action: "showMessageAction",
		args: ["Move to Folder..."]
	}, {
		label: "Copy to Folder...",
		action: "showMessageAction",
		args: ["Copy to Folder..."]
	}, {
		label: "Remove from Folder",
		action: "showMessageAction",
		args: ["Remove from Folder"]
	}, {
		isSeparator: true
	}, {
		label: "Delete Folder...",
		action: "showMessageAction",
		args: ["Delete Folder..."]
	}, {
		isSeparator: true
	}, {
		label: "Create Folder...",
		action: "showMessageAction",
		args: ["Create Folder..."]
	}]
}, {
	label: "Follow Up",
	iconInfo: [16, 16, 140, 40],
	subMenu: [{
		label: "Quick Flag",
		action: "showMessageAction",
		args: ["Quick Flag"]
	}, {
		label: "Add or Edit Flag...",
		action: "showMessageAction",
		args: ["Add or Edit Flag..."]
	}, {
		label: "Remove Flag",
		action: "showMessageAction",
		args: ["Remove Flag"]
	}, {
		isSeparator: true
	}, {
		label: "New Follow Up Message",
		action: "showMessageAction",
		args: ["New Follow Up Message"]
	}]
}, {
	label: "Mark As",
	subMenu: [{
		label: "Mark Selected Read",
		action: "showMessageAction",
		args: ["Mark Selected Read"]
	}, {
		label: "Mark Selected Unread",
		action: "showMessageAction",
		args: ["Mark Selected Unread"]
	}, {
		isSeparator: true
	}, {
		label: "Mark All Read",
		action: "showMessageAction",
		args: ["Mark All Read"]
	}, {
		label: "Mark All Unread",
		action: "showMessageAction",
		args: ["Mark All Unread"]
	}]
}, {
	isSeparator: true
}, {
	label: "Delete",
	iconInfo: [14, 17, 120, 0],
	action: "showMessageAction",
	args: ["Delete"]
}, {
	label: "More",
	subMenu: [{
		label: "Preferences...",
		action: "showMessageAction",
		args: ["Preferences..."]
	}, {
		label: "Out of Office...",
		action: "showMessageAction",
		args: ["Out of Office..."]
	}, {
		isSeparator: true
	}, {
		label: "Copy Into New",
		subMenu:[{
			label: "Message",
			action: "showMessageAction",
			args: ["Message"]
		}, {
			label: "Calendar Entry",
			action: "showMessageAction",
			args: ["Calendar Entry"]
		}, {
			label: "To Do",
			action: "showMessageAction",
			args: ["To Do"]
		}]
	}, {
		label: "Add Sender to Contacts...",
		action: "showMessageAction",
		args: ["Add Sender to Contacts..."]
	}, {
		label: "Block Mail From Sender...",
		action: "showMessageAction",
		args: ["Block Mail From Sender..."]
	}, {
		label: "Schedule a Meeting...",
		action: "showMessageAction",
		args: ["Schedule a Meeting..."]
	}, {
		isSeparator: true
	}, {
		label: "New Message with Stationery...",
		action: "showMessageAction",
		args: ["New Message with Stationery..."]
	}, {
		label: "New Stationery",
		action: "showMessageAction",
		args: ["New Stationery"]
	}, {
		label: "View Stationery",
		action: "showMessageAction",
		args: ["View Stationery"]
	}, {
		isSeparator: true
	}, {
		label: "Create QuickRule...",
		action: "showMessageAction",
		args: ["Create QuickRule..."]
	}, {
		label: "Mail Rules",
		action: "showMessageAction",
		args: ["Mail Rules"]
	}, {
		label: "New Rule",
		action: "showMessageAction",
		args: ["New Rule"]
	}, {
		isSeparator: true
	}, {
		label: "Show MIME Header",
		action: "showMessageAction",
		args: ["Show MIME Header"]
	}, {
		label: "Show MIME Full",
		action: "showMessageAction",
		args: ["Show MIME Full"]
	}]
}, {
	label: "Print",
	iconInfo: [16, 16, 100, 0],
	action: "showMessageAction",
	args: ["Print"]
}, {
	label: "Show",
	iconInfo: [16, 13, 34, 107],
	subMenu: [{
		label: "Preview on Bottom",
		iconInfo: [16, 13, 0, 107],
		action: "showMessageAction",
		args: ["Preview on Bottom"],
		radioGroupId: "preview",
		isChecked: true
	}, {
		label: "Preview on Side",
		iconInfo: [16, 13, 17, 107],
		action: "showMessageAction",
		args: ["Preview on Side"],
		radioGroupId: "preview"
	}, {
		label: "Hide Preview",
		action: "showMessageAction",
		args: ["Hide Preview"],
		radioGroupId: "preview"
	}, {
		isSeparator: true
	}, {
		label: "Unread Only",
		action: "unreadOnlyAction",
		args: ["Unread Only"],
		isChecked: true
	}]
}];

var showMessageAction = function(msg) {
	alert(msg);
}
var unreadOnlyAction = function(msg, isChecked) {
	alert(msg + "\n" + "isChecked: " + isChecked);
}
