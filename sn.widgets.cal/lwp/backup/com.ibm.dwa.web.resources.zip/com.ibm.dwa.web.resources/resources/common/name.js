/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_Names.h

dojo.provide("dwa.common.name");


dojo.declare(
	"dwa.common.name",
	null,
{
	constructor: function(sName, fNoInet){
		this.oNameSep = {',': true, ';': true};
		this.extract(sName, fNoInet);
	},

	toString: function(){
		return this.sOriginal;
	},

	extract: function(sName, fNoInet){
		if (!sName)
			return;
	
		var oStr = {
			phrase: [],
			comment: [],
			address: [],
			regular: []
		};
	
		var oSep = !fNoInet ? {
			phrase: '""',
			comment: '()',
			address: '<>'
		} : {};
	
		var nLength = sName.length;
		var sState = '';
	
		for (var i = 0; i < nLength; i++) {
			var asStr = oStr[sState ? sState : 'regular'];
			var s = sName.charAt(i);
	
			if (sState) {
				// MYAA84Q935 : change to address state if found < in phrase part. Now we don't need " to be closed by " in phrase part.
				if (s == oSep['address'].charAt(0))
					sState = 'address';
				else if (s != oSep[sState].charAt(1))
					asStr[asStr.length] = s;
				else
					sState = '';
			} else {
				if (this.oNameSep[s]) {
					nLength = i;
					break;
				}
	
				for (var s0 in oSep) {
					if (oSep[s0].charAt(0) == s) {
						sState = s0;
						break;
					}
				}
	
				if (!sState)
					asStr[asStr.length] = s;
			}
		}
	
		var sAddress = (oStr['regular'].join('')).replace(/^\s\s*/, '').replace(/\s*\s$/, '');
		var s822Address = (oStr['address'].join('')).replace(/^\s\s*/, '').replace(/\s*\s$/, '');
		var sPhrase = (oStr['phrase'].join('')).replace(/^\s\s*/, '').replace(/\s*\s$/, '');
	
		this.sComment = (oStr['comment'].join('')).replace(/^\s\s*/, '').replace(/\s*\s$/, '');
		this.f822 = !!s822Address;
		this.fInet = false;
	
		this.fIncomplete = !!sState;
		this.sAddress = this.f822 && s822Address ? s822Address : sAddress;
		this.sPhrase = this.f822 && !sPhrase ? sAddress : sPhrase;
		this.sOriginal = (sName.substr(0, nLength)).replace(/^\s\s*/, '').replace(/\s*\s$/, '');
	
		var asNotesDomain = this.sAddress.split("@");
		for (var i = 1; i < asNotesDomain.length; i++) {
			if (asNotesDomain[i].indexOf('.') >= 0) {
				this.fInet = true;
				break;
			}
		}
	
		if (!this.fInet) {
			this.sAddress = asNotesDomain[0];
			asNotesDomain.splice(0, 1);
			this.asNotesDomain = asNotesDomain[0] ? asNotesDomain : void 0;
		}
	
		return sName.substr(nLength + 1);
	},

	getAbbrev: function(){
		if (this.fInet || !this.sOriginal)
			return this.sOriginal ? this.sOriginal : '';
	
		// If this is an LDAP identity, then return unabbreviated, as the Notes client does (DTE reported problem)
		// I suspect that what we should be doing here is testing for CN=
		// If CN= is not found, then return sName.
		// LDAP entities typically use lowercase attribute names, like this:
		//      uid=e38993/ou=Westford/o=IBM
		//      cn=Daniel Gurney/ou=Westford/o=IBM
		// And also:
		//      cn=Daniel Gurney,ou=Westford,o=IBM
		if (-1 == this.sAddress.indexOf("=") || -1 == this.sAddress.toUpperCase().indexOf("CN" + "="))
			return this.sAddress;
	
		// Do a more extensive check, just to be sure
		//  Since canonical names are tagged, the position of the tags is not regulated.
		//  For instance, both of these names should be identical:
		//      CN=Daniel Gurney/OU=Westford/O=IBM
		//      OU=Westford/CN=Daniel Gurney/O=IBM
		//  For simplicity, we check for:
		//      /CN=    (anywhere in the string)
		//       CN=    (only at the beginning of the string)
		if (this.sAddress.toUpperCase().indexOf("/" + "CN" + "=") <= 0 && this.sAddress.toUpperCase().indexOf("CN" + "=") != 0)
			return this.sAddress;
	
		var asPart = this.sAddress.split("/");
	
		for (var i = 0; i < asPart.length; i++) {
			// Check if last asPart has exactly two chars...if so...keep key if this is ORG
			// Reason for i > 0: Alternate name may contain org at second asPart : CPAN68CBLA
			var nPos = asPart[i].indexOf("=");
			var fIntact = nPos >= 0 && i > 0 && i == asPart.length - 1 && asPart[i].length > nPos + 1
			 && asPart[i].substring(nPos + 1).match(/^[A-z]{2}$/) && asPart[i].substring(0, nPos + 1).toUpperCase().indexOf("O" + "=") >= 0;
	
			asPart[i] = (nPos >= 0 && !fIntact ? asPart[i].substring(nPos + 1) : asPart[i]).replace(/^\s\s*/, '').replace(/\s*\s$/, '');
		}
	
		return asPart.join("/");
	},

	getNormalized: function(){
		// If this is an internet address and there is the sAddress property, use it. Otherwise, should work the same as getAbbrev()
		// NOTE: sAddress property should always be there for internet address case.
		//       "Not having sAddress for internet address" is just-in-case scenario
		// SPR #MLEY84ACBX - asudoh 5/11/2010
		return this.fInet && this.sAddress || this.getAbbrev();
	},

	getCanonicalized: function(){
		if (this.fInet || !this.sOriginal)
			return this.sOriginal ? this.sOriginal : '';
	
		var oParsed = this.getParsed();
	
		// Get a template for what the name should look like
		var oTemplate = (new dwa.common.name(this.canonicalName)).getParsed();
	
		// Fix up non-hierarchical name, if necessary (Only do this for flat names)
		// It is possible that your company uses CN/OU/O format, but the email is in CN/O format ... which is valid.  
		// The old code appended your organization to the email address.
		// NOTE: Creating regular expression for '/' with the literal hits an obfuscator bug... (Treating it as JavaScript comment)
		for (var s in {"O": void 0, "C": void 0})
			oParsed[s] = !(new RegExp('/')).test(this.sAddress) && oTemplate[s] && !oParsed[s] ? oTemplate[s] : oParsed[s];
	
		var asParts = [];
	
		for (var asComponents = ["CN", "OU", "O", "C"], i = 0; i < asComponents.length; i++) {
			for (var asValues = oParsed[asComponents[i]] ? oParsed[asComponents[i]].split("/") : [], j = 0; j < asValues.length; j++)
				asParts.push(asComponents[i] + "=" + asValues[j]);
		}
	
		return asParts.join("/");
	},

	getParsed: function(){
		var oComponents = {
			"CN": '',
			"OU": '',
			"O": '',
			"C": '',
			"A": '',
			"P": ''
		};
	
		if (!this.sAddress) {
			return oComponents;
		}
	
		// Can contain Notes domain or inet domain
		oComponents["Domain"] = (!this.fInet ? (this.asNotesDomain || []): this.sAddress.split("@").slice(1)).join("@");
	
		// Extract DN parts, using temporary characters for $/ and $= ('$' is a escape character for '/' or '=')
		var asParts = this.sAddress.replace(new RegExp("$/", 'g'), '\r').replace(new RegExp("$=", 'g'), '\n').split("/");
	
		// If we detect (exactly) two alphabet characters at the last token, we treat it as abbreviated country name
		// SPR #LSHR5SDPLH
		var nSlide = !!(asParts.length > 2 && /^[A-z]{2}$/.test(asParts[asParts.length - 1])) - 0;
	
		for (var nPosCountry = asParts.length - nSlide, nPosOrg = nPosCountry - 1, i = 0; i < asParts.length; i++) {
			var asValue = asParts[i].split("=");
			if (asValue.length > 1 && !(asValue[0] in oComponents))
				continue;
	
			// If the part represents abbreviated component, use it as a value and automatically guess the type of component
			if (asValue.length <= 1) {
				asValue[1] = asValue[0];
				asValue[0] = i == 0 ? "CN": i == nPosOrg ? "O" : i == nPosCountry ? "C" : "OU";
			}
	
			oComponents[asValue[0]] = ("OU" == asValue[0] && oComponents[asValue[0]] ? (oComponents[asValue[0]] + "/") : '')
			 + (asValue[1].replace(/\r/g, "/").replace(/\n/g, "=")).replace(/^\s\s*/, '').replace(/\s*\s$/, '');
		}
	
		return oComponents;
	},

	getIMName: function(){
		// Fixup the name in one of several ways based on SametimeNameFormat setting
		// First character denotes one of 4 formats:
		// 0 : Normal (Abbreviated canonical names)
		// 1 : Full canonical names
		// 2 : Full canonical (but use commas for separators)
		// 3 : Common name only
	
		// Second character denotes one of two possibilities regarding RFC821 addresses:
		// 0 : Don't send to sametime
		// 1 : Do send to sametime (default)
	
		// Third character governs name format for login
	
		// Fourth character if present introduces a debug mode (causes displayed name
		//  to be same as name passed to Sametime)

		// After implementing the below simple option 2, conversations with Scott M. Davidson revealed
		//  that the algorithm used by Notes is more complex.  See LDAP_DNConvertSeparatorFromNotesFormat routine
		//  in Notes pack (ldap\ldap\util.cpp).
	
		// Looks like some characters [\",+;=<>#] within value portions need to be escaped with backslash char
		// Also appears Notes surrounds forwardslash character within a value with doublequote char,
		//  hence such surrounding doublequote chars need to be removed
		// Should eventually make option 2 more robust by implementing this stuff

		var sFormat = (this.sSTNameFmt || '0').charAt(0);
		return this.fInet ? this.sAddress :
		 sFormat == '1' ? this.getCanonicalized() :
		 sFormat == '2' ? this.getCanonicalized().split("/").join(',') :
		 sFormat == '3' ? this.getParsed()["CN"] :
		 this.getAbbrev();
	}
});
