/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_validation.h

dojo.provide("dwa.common.fieldNameEntities");

dojo.require("dwa.common.nameEntities");

dojo.declare(
	"dwa.common.fieldNameEntities",
	dwa.common.nameEntities,
{

	constructor: function(oElem, aoEntities, anStart){
		this.oElem = oElem;
		this.aoEntities = aoEntities ? aoEntities : [];
		this.anStart = anStart ? anStart : [];
	},

	synchronize: function(){
		var sValue = this.oElem.value;
		var nStartIndex = 0, nStartPos = 0, nEndIndex = this.getLength(), nEndPos = sValue.length;
		this.anStart = [];
	
		for (; this.oSep.test(sValue.charAt(nStartPos)); nStartPos++);
		for (; nStartIndex < this.getLength(); nStartIndex++) {
			var sName = this.getName(nStartIndex);
			if (sValue.substr(nStartPos, sName.length) != sName
			 || !this.oForwardSep.test(sValue.substr(nStartPos + sName.length)))
				break;
			this.anStart[nStartIndex] = nStartPos;
			for (nStartPos += sName.length; this.oSep.test(sValue.charAt(nStartPos)); nStartPos++);
		}
	
		for (; this.oSep.test(sValue.charAt(nEndPos - 1)); nEndPos--);
		for (; nEndPos > nStartPos && nEndIndex > 0; nEndIndex--) {
			var sName = this.getName(nEndIndex - 1);
			if (sValue.substr(nEndPos - sName.length, sName.length) != sName
			 || !this.oBackwardSep.test(sValue.substr(0, nEndPos - sName.length)))
				break;
			this.anStart[nEndIndex - 1] = nEndPos;
			for (nEndPos -= sName.length; this.oSep.test(sValue.charAt(nEndPos - 1)); nEndPos--);
		}
	
		this.aoEntities.splice(nStartIndex, nEndIndex - nStartIndex);
		this.anStart.splice(nStartIndex, nEndIndex - nStartIndex);
	
		for (var sDirty = sValue.substr(nStartPos, nEndPos - nStartPos); sDirty; nStartIndex++) {
			var oName = new dwa.common.name;
			var nLength = sDirty.length;
			sDirty = oName.extract(sDirty);
			this.aoEntities.splice(nStartIndex, 0, oName);
			this.anStart.splice(nStartIndex, 0, nStartPos);
			nStartPos += nLength - sDirty.length;
		}
	
		// for namepicker -- if (com_ibm_dwa_globals.fLogNameLookup) {
		//	console.debug('Synchronized name field: ' + this.oElem.id);
		//	for (var i = 0; i < this.aoEntities.length; i++)
		//		com_ibm_dwa_globals.oStatusManager.addEntry(3, '',
		//		 i + ': Start[' + this.anStart[i] + '], Name[' + this.getName(i) + ']');
		//}
	},

	release: function(){
		dwa.common.fieldNameEntities.oEntities[this.oElem.id] = void 0;
		this.oElem = this.oSubmitElem = void 0;
	},

	updateNames: function(sMode, sSep, fSubmit){
		// SPR #WLWL82ZEUX: Remove duplicate recipients from the field.
		// This can cope with names in contacts groups after it is expanded and names are validated.
		for (var i = this.aoEntities.length - 1; i >= 0; i--) {
			var nIndex = dwa.common.utils.indexOf(this.aoEntities, this.aoEntities[i]);
			if (nIndex != -1 && nIndex != i)
				this.aoEntities.splice(i, 1);
		}
		var asValue = [];
		for (var i = 0, n=0; i < this.aoEntities.length; i++)
				asValue[n++] = this.getName(i, sMode);
		(!fSubmit ? this.oElem : this.oSubmitElem).value = asValue.join(sSep ? sSep : ';');
	},

	expandContactsGroup: function(){
		for (var i = this.aoEntities.length - 1; i >= 0; i--) {
			// replace value from members' entity if exists
			// expand only private group. public group shold remain in address fields.
			var aoMembers = this.aoEntities[i].aoMembers;
			if (this.aoEntities[i].sDir == 'local' && aoMembers) {
				for (var j = aoMembers.getLength() - 1; j >= 0; j--) {
						this.aoEntities.splice(i+1, 0, aoMembers.aoEntities[j]);
						this.aoEntities[i+1].fToBeExactMatched = true;
					}
				this.aoEntities.splice(i, 1);
			}
		}
	},

	needsToBeRevalidated: function(){
		// dg: an endless loop occurs if an RFC822 name is typed and the name is not in any address book
		//     to fix this, check if the name is RFC822 (fInet)
		for (var i = 0; i < this.aoEntities.length; i++) {
			var fNeedsToBeRevalidated = this.aoEntities[i] instanceof dwa.common.nameEntity ? this.aoEntities[i].fNotYetFetched :
			 (!this.aoEntities[i].fUseNameAnyway && !this.aoEntities[i].fInet);
			if (fNeedsToBeRevalidated)
				return true;
		}
	},

	getEntityIndex: function(nPos){
		for (var i = this.anStart.length - 1; i >= 0; i--) {
			if (this.anStart[i] < nPos && this.anStart[i] + this.getName(i).length >= nPos)
				return i;
		}
		return -1;
	},
	oSep: /[,\uff0c\s]/,
	oForwardSep: /^\s*(,|\uff0c|$)/,
	oBackwardSep: /(^|,|\uff0c)\s*$/
});

dwa.common.fieldNameEntities.get = function(oElem){
	dwa.common.fieldNameEntities.oEntities = dwa.common.fieldNameEntities.oEntities ?
	 dwa.common.fieldNameEntities.oEntities : {};
	return dwa.common.fieldNameEntities.oEntities[oElem.id] ?
	 dwa.common.fieldNameEntities.oEntities[oElem.id] :
	 (dwa.common.fieldNameEntities.oEntities[oElem.id] = new dwa.common.fieldNameEntities(oElem));
};
