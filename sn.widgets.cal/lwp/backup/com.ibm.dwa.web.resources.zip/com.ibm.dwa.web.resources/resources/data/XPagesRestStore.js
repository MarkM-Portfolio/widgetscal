/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.data.XPagesRestStore");
dojo.require("dwa.data._DominoStoreBase");
dojo.require("dwa.common.notesValue");

dojo.declare("dwa.data.XPagesRestStore",
			 dwa.data._DominoStoreBase,
{
	//	summary:
	//		A data store for XPages REST service

	type: "json",
	notesValue: new dwa.common.notesValue,

	_getCellValue: function(){
		//	summary:
		//		Get cell value from a cell object.
		//	description:
		//		Cell object is an attribute value of an item, which represents a row.
		//		It can be any type of data structure, which may include various meta data.
		//		This method will become a toString() for the cell object.
		//		'this' points to the cell object.
		var value = this["@value"];
		return ( typeof(value) == "undefined" ) ? "" : value.toString();
	},

	format: function(data){
		if(!data || !data.items){ return data; }
		var items = data.items;
		this._numRows = data["@topLevelEntries"];
		return items;
	}
});
