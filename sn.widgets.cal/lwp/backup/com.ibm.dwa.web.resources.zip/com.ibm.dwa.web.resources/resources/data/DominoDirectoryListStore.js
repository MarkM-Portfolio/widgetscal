/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

dojo.provide("dwa.data.DominoDirectoryListStore");
dojo.require("dwa.data._DominoStoreBase");
dojo.require("dwa.common.notesValue");

dojo.declare("dwa.data.DominoDirectoryListStore",
			 dwa.data._DominoStoreBase,
{
	//	summary:
	//		A data store for Domino data source

	dwa: true,
	notesValue: new dwa.common.notesValue,

	constructor: function(/*Object*/args){
		if(args){
			dojo.mixin(this, args);
		}

        this.type = (dojo.isFF ? "text" : "xml");
    },

	getUrl: function(request){
		if(this.url.indexOf("://") == -1){ return this.url }
		return this.url + "/iNotes/Proxy/?OpenDocument&Form=test_DirectoryList&PresetFields=noPI;1";

	},

	_getCellValue: function(){
		//	summary:
		//		Get cell value from a cell object.
		//	description:
		//		Cell object is an attribute value of an item, which represents a row.
		//		It can be any type of data structure, which may include various meta data.
		//		This method will become a toString() for the cell object.
		//		'this' points to the cell object.
		//return typeof(this["@value"]) == "string" ? this["@value"] : "[object]";
		var valueType = this["@type"] || "text";
		var value = this["@value"];
		
		return (valueType.indexOf("list") == -1) ? value.toString() : value.toString();
	},

	format: function(data){
        if( dojo.isFF ){
            dojo.require("dojox.xml.parser");
            data = dojox.xml.parser.parse( data );
        }

		//	summary:
		//		Format raw data to an array of items.
		//	data:
		//		Root of json object or the document object of XML dom tree.
		var entries;
		if(this.type == "json"){
			entries = data.entries ? data.entries : data;
			this._numRows = entries["@toplevelentries"] - 0;
			var items = entries.viewentry;
			for(var i = 0; i < items.length; i++){
				var item = items[i];
				item[this._storeRef] = this;
				var cols = item.entrydata;
				for(var j = 0; j < cols.length; j++){
					var col = cols[j];

					this.notesValue.setJsonNode( col );
					col['@type'] = this.notesValue.sType;
					col['@value'] = this.notesValue.vValue;
					item[col["@name"]] = col;
					col.toString = this._getCellValue;
					col[this._storeRef] = this;
					col._isColumn = true;
				}
			}
			for(var key in entries){
				if(key.charAt(0) == "@"){
					items[key] = entries[key];
				}
			}
		}else/* if(this.type == "xml")*/{
			var root = data;
			for(var i = 0; i < root.childNodes.length; i++){
				var child = root.childNodes[i];
				if(child.nodeType == 1 && child.nodeName == "directories"){
					root = child;
					break;
				}
			}

			var items = [];
			for(var i = 0; i < root.childNodes.length; i++){
				var xmlitem = root.childNodes[i];
				if(xmlitem.nodeType == 1 && xmlitem.nodeName == "directory"){
					var item = {};
					item[this._storeRef] = this;

					var cols = [];
					for(var j = 0; j < xmlitem.childNodes.length; j++){
						var child = xmlitem.childNodes[j];
						if(child.nodeType == 1 && child.nodeName == "directorydata"){
							this.notesValue.setXmlNode( child );
							var col = {};
							col['@type'] = this.notesValue.sType;
							col['@value'] = this.notesValue.vValue;
							col.toString = this._getCellValue;
							col[this._storeRef] = this;
							col._isColumn = true;

							this.setAttrs( col, child );
							var name = col[ "@name" ];
							item[ name ] = col;
						}
					}

					this.setAttrs( item, xmlitem );
					items.push( item );
				}
			}

            this._numItems = items.length;
		}

		return items;
	},

	setAttrs: function( item, node ){
		var attrs = node.attributes || [];
		for (var i = 0, len = attrs.length; i < len; i++) {
			var attr = attrs[i];
			item["@"+attr.nodeName] = attr.nodeValue;
		}
	}
});
