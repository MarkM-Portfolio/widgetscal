/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_validation.h

dojo.provide("dwa.type.listViewAmbiguousName");


dojo.declare(
	"dwa.type.listViewAmbiguousName",
	null,
{

	constructor: function(sId){
		dwa.widget.notesListView.call(this, sId);
	},

	onRowDblClick: function(oRow){
		if(this.fnOnRowDblClick)
			this.fnOnRowDblClick(oRow);
	},

	load: function(){
		if (!this.oNameEntities)
			return;
	
		// fill up the this.aoEntries for the dwa.widget.notesListView to display the data
		// the first item in this.aoEntries is a dummy item
		// the listView widget start looking at position 1
		if (!this.aoEntries.length) {
			this.aoEntries = [{oItem: [], aoValues: []}];
			for (var i=0; i< this.oNameEntities.getLength(); i++) {
				var oNameEntry = this.oNameEntities.aoEntities[i];
				var oEntry = {oItem: [], aoValues: []}, n = 0;
				//setup column values
				oEntry.oItem['@unid'] = oNameEntry.sUnid;
				var oPrimName = new dwa.common.name(oNameEntry.oContents['fullName']);
				oEntry.aoValues[n++] = new dwa.common.notesValue(oPrimName.getAbbrev());
	
				if(!this.bDisableAltName) {
					var oAltName = new dwa.common.name(oNameEntry.oContents['altFullName']);
					oEntry.aoValues[n++] = new dwa.common.notesValue(oAltName.getAbbrev());
				}
				if(!this.bDisableMailAddress) {
					var oMailAddress = new dwa.common.name(oNameEntry.oContents['mailAddress']);
					oEntry.aoValues[n++] = new dwa.common.notesValue(oMailAddress.getAbbrev());
					// dialog is too verbose with RFC-822 address in both display-name and address columns
					oEntry.aoValues[0] = new dwa.common.notesValue(oPrimName.getCommonName());
				}
				if(!this.bDisableMailDomain)
					oEntry.aoValues[n++] = new dwa.common.notesValue(oNameEntry.sDomain);
	
				var sDirType = oNameEntry.oContents['directoryType'].toUpperCase();
				var sDirTypeVal = sDirType == 'CONTACTS' ? dwa.type._msgs["L_AMBIGOUS_DIRTYPE_CONTACTS"] : (sDirType == 'LDAP' ? L_AMBIGOUS_DIRTYPE_LDAP : L_AMBIGOUS_DIRTYPE_DOMINO);
				oEntry.aoValues[n++] = new dwa.common.notesValue(sDirTypeVal);
				oEntry.aoValues[n++] = new dwa.common.notesValue(oNameEntry.sType);
	
				// Show Certificates column
				// Code copied from getCertTypes() in s_ValidationDlg.nx
				if(!this.bDisableCert && (oNameEntry.sDir != "dpab")) {
					var sCerts = '';
					var certs = oNameEntry.nFlags;
					if (certs)
					{
						if ( certs & HAS_NOTESCERTS )
						{
							sCerts += dwa.type._msgs["L_AMBIGOUS_CERT_NOTES"];
							if (sDirType == 'LNAB')
								sCerts += ' ' + L_AMBIGOUS_CERT_IN_CDC;
						}
						if ( (certs & HAS_INETCERTS) || (certs & HAS_INETCERTS_BUTNOTRUST) )
						{
							if(sCerts)
								sCerts += ', ';
	
							sCerts += L_AMBIGOUS_CERT_X509;
							if (certs & HAS_INETCERTS_BUTNOTRUST)
								sCerts += ' ' + L_AMBIGOUS_CERT_UNTRUSTED;
							else if (certs & HAS_LNAB)
								sCerts += ' ' + L_AMBIGOUS_CERT_IN_CDC;
						}
					}
					if (!sCerts)
						sCerts = (oNameEntry.type == 'Group' ? dwa.type._msgs["L_AMBIGOUS_CERT_UNKNNOWN_GROUP"] : dwa.type._msgs["L_AMBIGOUS_CERT_UNKNNOWN"]);
	
					oEntry.aoValues[n++] = new dwa.common.notesValue(sCerts);
				}
	
				//save a reference of name entry
				oEntry.oNameEntry = oNameEntry;
				this.aoEntries.push(oEntry);
			}
		} else {
			// Perform sorting - Remove the first dummy item first
			this.aoEntries.splice(0, 1);
			var nSortCol = this.oCols.getSortColumn ? this.oCols.getSortColumn() : 0;
			var nSortOrder = nSortCol < 0 || !this.oCols.getSortColumn ? 2 : this.oCols[nSortCol].nCurrentSortOrder;
			if (nSortCol < 0)
				nSortCol = 0;
	
			function fnSort(vElem1, vElem2){
				var nSign = vElem1.aoValues[nSortCol].vValue.toLowerCase() < vElem2.aoValues[nSortCol].vValue.toLowerCase() ? -1 :
				 vElem1.aoValues[nSortCol].vValue.toLowerCase() > vElem2.aoValues[nSortCol].vValue.toLowerCase() ? 1 :
				 0;
			//use col 0 as secondary sort
			if (nSign == 0 && nSortCol != 0)
				nSign = vElem1.aoValues[0].vValue.toLowerCase() < vElem2.aoValues[0].vValue.toLowerCase() ? -1 :
				 vElem1.aoValues[0].vValue.toLowerCase() > vElem2.aoValues[0].vValue.toLowerCase() ? 1 :
				 0;
				return nSign * (nSortOrder == 1 ? -1 : 1);
			}
	
			if (nSortOrder in {2: void 0, 1: void 0})
				this.aoEntries.sort(fnSort);
	
			//add back the dummy item to the top of the list
			this.aoEntries.splice(0, 0, {oItem: [], aoValues: []});
		}
		//set total number to commonProperty for the scroll bar to work
		var oElem = dojo.doc.getElementById(this.sId);
		dwa.widget.commonProperty.get(oElem.getAttribute('com_ibm_dwa_misc_observes_totals')).setValue(this.oNameEntities.getLength());
	
		this.format();
	}
});
