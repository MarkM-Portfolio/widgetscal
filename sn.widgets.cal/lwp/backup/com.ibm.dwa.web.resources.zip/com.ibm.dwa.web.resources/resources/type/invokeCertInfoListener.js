/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_validation.h

dojo.provide("dwa.type.invokeCertInfoListener");


dojo.declare(
	"dwa.type.invokeCertInfoListener",
	null,
{

	constructor: function(oListener){
		// #NBJC7ZQ9C7: in case of tear off window, call back from l_GetSenderCertType via PassToMailViewByCookie could be
		// consumed by other window, if the same listner key existed. To avoid this, set unique listner key using current time.
		var oCertInfoListener = new com_ibm_dwa_io_certinfoListener((new Date()).getTime());
		oCertInfoListener.oListener = oListener;
		oCertInfoListener.load();
	}
});
