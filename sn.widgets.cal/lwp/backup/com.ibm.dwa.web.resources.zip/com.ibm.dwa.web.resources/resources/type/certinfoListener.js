/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_validation.h

dojo.provide("dwa.type.certinfoListener");

dojo.require("dwa.common.listeners");

dojo.declare(
	"dwa.type.certinfoListener",
	dwa.common.elementListener,
{

	constructor: function(sKey){
		dwa.widget.elementListener.call(this, sKey);
	},

	load: function(){
		console.debug('Get sender certificate info');
	
		// reload cert info - return from Notes ID expire dialog
		if (this.sUrl && this.oIframe) {
			this.oIframe.src = this.sUrl;
			return;
		}
	
		// Pass this.sKey in PresetFields to call back from sender cert info page (l_GetSenderCertType)
		// This can also cope with Notes ID password page (s_NotesIDPW) and Notes ID expire page (s_NotesIDPWExpired)
		var sUrl = AbsoluteiNotesURLJS("Proxy") + "?EditDocument&Form=l_GetSenderCertType&charset=UTF-8&ResListenerKey=" + this.sKey
			+ (com_ibm_dwa_globals.s_DocumentForm - 0 ? "&PTMVTop=1" : "");
		if((IWA_SECMAIL_SSL_FLAG_NONE != com_ibm_dwa_globals.oSettings.avConfig[40]) && !dwa.type.bIsOffline && !dwa.type.bUsingHttps)
			sUrl = "https://"+location.hostname + (dwa.type.SSLPort != "443" ? (":"+dwa.type.SSLPort) : "") + sUrl;
	
		this.sUrl = this.sHref = sUrl;	// sHref - for checkInFlight
	
		if (!this.checkInFlight())
			return;
	
if(dojo.isSafari){
		var sOnload = 'var oListener =  com_ibm_dwa_globals.oScript.dwa.common.responseListener.prototype.oListeners[\'' + this.sKey + '\'];'
			+ 'if (oListener) oListener.onLoad();';
}
	
		var oMainDoc = dojo.doc;
		var sIFrame = '<iframe id="e-tempiframe-' + this.sKey + '" name="e-tempiframe-' + this.sKey + '" frameborder="0" class="s-stack s-hidden"'
if(dojo.isSafari){
		 + ' src="' + this.sUrl + '" onload="' + sOnload + '"></iframe>';
}else{
		 + ' src="' + this.sUrl + '"></iframe>';
}
	
if(!dojo.isFF && !dojo.isSafari){
		oMainDoc.body.insertAdjacentHTML('beforeEnd', sIFrame);
}else{
		var oRange = oMainDoc.createRange();
		oRange.setStartBefore(oMainDoc.body);
		var oFragment = oRange.createContextualFragment(sIFrame);
		oMainDoc.body.appendChild(oFragment);
}
		this.oIframe = oMainDoc.getElementById('e-tempiframe-' + this.sKey);
	},

	onLoad: function(){
		// load code and kick it to update tab title and other information.
		var oPanelManager = com_ibm_dwa_globals.getPanelManager();
if(1){
		oPanelManager.setupPassToMailView();
}else{
		com_ibm_dwa_io_widgetListener.prototype.oClasses['com_ibm_dwa_ui_panelManager:invokeWatchCookie'] = ['LitePassToMailView'];
		new com_ibm_dwa_io_widgetListener(oPanelManager.sId, 'com_ibm_dwa_ui_panelManager:invokeWatchCookie');
}
	},

	sendPassword: function(sPassword){
		console.debug('Getting sender certificate info: Notes ID password required');
	
		var oMainDoc = dojo.doc;
	
		var sForm = '<form id="e-tempform-' + this.sKey + '" method = "POST" target = "e-tempiframe-' + this.sKey + '" class="s-hidden-iframe">'
					+ '<input type="hidden" name="%%Nonce"/><input type="hidden" name="password"/></form>';
	
if(!dojo.isFF && !dojo.isSafari){
		oMainDoc.body.insertAdjacentHTML('beforeEnd', sForm);
}else{
		var oRange = oMainDoc.createRange();
		oRange.setStartBefore(oMainDoc.body);
		var oFragment = oRange.createContextualFragment(sForm);
		oMainDoc.body.appendChild(oFragment);
}
	
		this.oForm = oMainDoc.getElementById('e-tempform-' + this.sKey);
		this.oForm.action = this.sUrl;
		this.oForm["password"].value = sPassword;
		this.oForm["%%Nonce"].value = com_ibm_dwa_globals.getNonce();
		this.oForm.submit();
	},

	onDatasetComplete: function(sSenderCertInfo){
		console.debug('done with getting sender certificate info');
	
		sSenderCertInfo = decodeURIComponent(sSenderCertInfo);
	
		var sLoadUrl = com_ibm_dwa_globals.com_ibm_dwa_io_widgetListener_getUrl(['DocumentActions']);
	
		// Notes ID password page is returned.
		if (sSenderCertInfo.indexOf("IDPW") == 0) {
			var oListener = new com_ibm_dwa_io_functionListener(void 0, 'com_ibm_dwa_ui_launchNotesIdPasswordDialog', this);
			oListener.track();
			oListener.load(sLoadUrl);
			return;
		}
	
		// Notes ID is expired.
		if (sSenderCertInfo.indexOf("IDEX") == 0) {
			var aInfo = sSenderCertInfo.split(",")[1].split(":");
			this.h_PWD = aInfo[0];
			this.h_Cert = aInfo[1];
			this.h_MustChange = aInfo[2];
	
			var oListener = new com_ibm_dwa_io_functionListener(void 0, 'com_ibm_dwa_ui_processNotesIdExpiration', this);
			oListener.track();
			oListener.load(sLoadUrl);
			return;
		}
	
		var nCertInfo = parseInt(sSenderCertInfo);
		dwa.type.nCertType = nCertInfo;
		dwa.type.bSenderCertTypeFetched = true;
	
		// Resume com_ibm_dwa_io_nameFieldListener
		if (this.oListener)
			this.oListener.load();
	
		if (this.oForm)
			this.oForm.parentNode.removeChild(this.oForm);
		if (this.oIframe)
			this.oIframe.parentNode.removeChild(this.oIframe);
	
		this.oInFlight[this.sUrl] = void 0;
		this.release();
	
	}
});
