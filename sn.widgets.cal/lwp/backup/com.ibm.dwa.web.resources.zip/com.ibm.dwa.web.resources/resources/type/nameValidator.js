/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_validation.h

dojo.provide("dwa.type.nameValidator");

dojo.require("dwa.common.dropdownManager");
dojo.require("dwa.common.utils");
dojo.require("dwa.type.typeaheadListener");
dojo.require("dwa.common.nameEntities");
dojo.require("dwa.common.fieldNameEntities");
dojo.require("dwa.type.nameLookupListener");
dojo.require("dwa.common.presets");

dojo.declare(
	"dwa.type.nameValidator",
	null,
{
	validatorStore: null,

	constructor: function(){
		this.asTypeaheadKeys = [];
		this.oNameEntities = {};
		this.oNamesIgnore = {};
		this.oDropdownManager = dwa.common.dropdownManager.get('validator');
		this.oDropdownManager.fDisableDropdownMenuKey = true;
		if(dojo.isFF){
			this.oDropdownManager.oOffset = new dwa.common.utils.pos(1, 0);
		}
	},

	invokeTypeahead: function(ev){
		var oNoTypeaheadKeys = {
			9: void 0,
			13: void 0,
			37: void 0,
			39: void 0,
			35: void 0,
			36: void 0,
			120: void 0
			,27 : void 0
			,44 : void 0
			,188 : void 0
		};
	
		var oNoKeyPress = {
			38: void 0,
			40: void 0,
			8: void 0
			// SPR# NBJC7Y4AKB:  Chinese comma has one code for "onkeydown", and another for "onkeyup" ... KEYCODE_COMMA_ALT == onkeyup
			,44 : void 0
			,188 : void 0
		};
	
		var oDropdownMenu = 0 < this.oDropdownManager.aoActiveDrops.length ?
			this.oDropdownManager.aoActiveDrops[this.oDropdownManager.aoActiveDrops.length - 1] : null;
	
		// 44 == ','.charCodeAt(0)
		// Gecko browsers gives 0 keyCode in keypress events for regular characters and gives charCode instead
		// SPR #DYHG77UB9K - asudoh 10/15/2007
		// -
		// SPR #SQZO7NJ9KD / #SQZO7NJBF4 - dgurney 2009/01/27
		//	moved keyCode checks to IE / Safari and charCode to Gecko only
		//	this fixes the "double arrow" press experienced in Gecko and Safari
		// -
		// SPR# MOBN7T4JNJ
		//	made the code below simpler due to similar issues within com_ibm_dwa_ui_dropdownMenu_handleKey (l_Menu.h)
		if(dojo.isFF){
			// SPR# NBJC7Y4AKB:  keyCode is the actual keyboard key that was pressed, while charCode gives the ASCII value of the resulting character. 
			var nCode = ev.keyCode ? ev.keyCode : ev.charCode;
		}else{
			// SPR# NBJC7Y4AKB:  IE reports "charCode" for keyCode only for "onkeypress" event
			var nCode = ev.keyCode;
		}
	
		if (oDropdownMenu && nCode in {13: void 0, 38: void 0, 40: void 0}) {
			if (ev.type == 'keydown') {
				var menu = dijit.byNode(oDropdownMenu);
				menu.handleKeyDown(ev);
				// screen reader
				var oElem = ev.target || ev.srcElement;
				var typeAhead = dijit.byNode(oElem);
				if(typeAhead.supportScreenReader){
					typeAhead.setTextForScreenReader(menu.getSelectedLabelText());
				}
			}
			return;
		}
		if ((ev.type == 'keydown' && (nCode in oNoKeyPress)) // SPR# SQZO7UC6EC: process only keydown, keypress=keydown + keyup, and keydown bubbles up to doc level, causing form submit(ENTER) and doc close (ESC)
		 || (ev.type == 'keyup' && !(nCode in oNoKeyPress))  // this stops keys from being processed twice: onkeydown + onkeyup
		 || (nCode in oNoTypeaheadKeys)
		 ) {
			switch (nCode){
			case 9:
				this.oDropdownManager.hide();
				break;
			case 27:
				// Close dropdown menu on ESC press
				this.oDropdownManager.hide();
				// fall through
			case 13:
				// Prevent enter key from being effective on address field in case drop down menu is not there (SPR #PTHN75XQYA)
				ev.stopPropagation();
				ev.preventDefault();
			}
			return;
		}
	
		// SPR# PTHN7TCKM6: do not show search results until requested
		this.fShowSearch = true;
		// Keep track the last element call to invokeTypeahead.
		this.oFocusElement = ev.target;
		// dwa.type.typeaheadListener
		var oListener = new dwa.type.typeaheadListener(null, this, ev);
		var nMaxEntries = this.oFocusElement.getAttribute('com_ibm_dwa_ui_typeaheadManager_maxEntries');
		if (nMaxEntries)
			oListener.nMaxEntries = nMaxEntries - 0;
		setTimeout(dojo.hitch(this, "typeahead", oListener), 0);
	},

	typeahead: function(oListener){
		if (oListener.oElem.oListener != oListener || this.oFocusElement != oListener.oElem) {
			var sLog = 'Outdated typeahead event ' + oListener.sKey + '... Bailing.';
			console.debug(sLog);
			return;
		}
	
		var oFieldNameEntities = dwa.common.fieldNameEntities.get(oListener.oElem);
		oFieldNameEntities.synchronize();
	
		oListener.nIndex = oFieldNameEntities.getEntityIndex(oListener.getStartPos());
		oListener.nIndex = oListener.nIndex < 0 && oFieldNameEntities.getLength() > 0 ? oFieldNameEntities.getLength() - 1 : oListener.nIndex;
		var oEntity = oFieldNameEntities.aoEntities[oListener.nIndex];
		oListener.sLookup = oEntity ? ('' + oEntity) : '';
	
		if (!oListener.sLookup || oEntity instanceof dwa.common.nameEntity || oEntity.sDir == 'dpab') {
			this.oDropdownManager.hide();
			return;
		}
	
		// Hide the drop down box if the drop down box does not represent the name resolution candidates for the name around the caret
		// Part of the fix for SPR #YCDL75T97U - asudoh 10/22/2007
		//? nakakura
//?		var oDrop = this.oDropdownManager.aoActiveDrops[this.oDropdownManager.aoActiveDrops.length - 1];
//?		var sKey = oDrop ? oDrop.id.match(/^e\-dropdown\-(.*)$/)[1] : '';
//?		var oActiveListener = dwa.common.responseListener.prototype.oListeners[sKey];
//?		if (oActiveListener && oActiveListener.nIndex != oListener.nIndex)
//?			this.oDropdownManager.hide();
	
		if (!this.oNameEntities[oListener.sLookup])
			this.oNameEntities[oListener.sLookup] = new dwa.common.nameEntities;
	
		// Development Task [JFOR-7NQRPK]: DPAB Names
		if (dwa.type.bDpabTypeaheadEnabled) {
			// SPR# PTHN7TCKM6: do not show search results until requested, go directly to type-ahead choices
			oListener.onDatasetComplete();
		} else {
			this.searchDirectories( oListener );
		}
		// breaking up the .typeahead function into two parts ensures that a network call only
		//  happens if user explicitly chooses to do so.
	},

	searchDirectories: function(oListener){
		this.fShowSearch = false;
	
		if (this.oNameEntities[oListener.sLookup].getLength() > 0 && this.oNameEntities[oListener.sLookup].fResolved) {
			oListener.onDatasetComplete();
			return;
		}
	
		for (var i = this.asTypeaheadKeys.length - 1; i >= 0; i--) {
			if (this.oNameEntities[this.asTypeaheadKeys[i]].getLength() > 0 || oListener.sLookup in this.oNamesIgnore)
				this.asTypeaheadKeys.splice(i, 1);
		}
	
		if (dwa.common.utils.indexOf(this.asTypeaheadKeys, oListener.sLookup) < 0 && !(oListener.sLookup in this.oNamesIgnore)) {
			this.asTypeaheadKeys.splice(0, Math.max(this.asTypeaheadKeys.length - this.nQueueLen + 1, 0));
			this.asTypeaheadKeys.push(oListener.sLookup);
		}
	
		// perform directory lookup
		var sActivityHandler = oListener.oElem.getAttribute('activityhandler');
		setTimeout(dojo.hitch(this, "lookup", oListener, this.asTypeaheadKeys, sActivityHandler), 0);
	},

	lookup: function(oListener, asKeys, sActivityHandler){
		if (!asKeys.length) {
			if (oListener)
				oListener.onDatasetComplete();
			return;
		}
		var fGetFlags = (oListener.fEncrypt || oListener.fSign) ? 1 : 0;
		var _this = this;
		var fetch = {
			query: {
				VAL_NameEntries: asKeys,
				VAL_ExpandGroup: !!this.fExpandGroup,
				VAL_Type: 2 - !this.fIgnoreContacts,
				VAL_Flags: fGetFlags,
				VAL_SendEncrypted: fGetFlags,
				'%%PostCharset': 'UTF-8'	// Using XMLHttpRequest, POST data will be URL encoded. So set UTF-8 to %%PostCharset.
			},
			onComplete: function(result, requestObject){
				dojo.hitch(_this, "_callbackSetData")(result, requestObject, oListener);
			},
			onError: function(errText){
				alert('nameValidator#lookup: ' + errText);
			}
		};
		this.validatorStore.fetch(fetch);
	},

	_callbackSetData: function(result, requestObject, oListener){
		this.setJsonNode(result);
		if (oListener)
			oListener.onDatasetComplete();
	},

	XXlookup: function(oListener, asKeys, sActivityHandler){
		if (!asKeys.length) {
			if (oListener)
				oListener.onDatasetComplete();
			return;
		}
	
		// oListener can be either of the following here:
		// 1) dwa.type.typeaheadListener - For type ahead
		// 2) com_ibm_dwa_io_nameFieldListener - For name validation
		//? nakakura
		if (oListener.oElem && (false/*? oListener.oElem.oListener != oListener*/ || this.oFocusElement != oListener.oElem)) {
			var sLog = 'Outdated typeahead event ' + oListener.sKey + '... Bailing.';
			console.debug(sLog);
			return;
		}
	
		var fGetFlags = (oListener.fEncrypt || oListener.fSign) ? 1 : 0;
	
		var oData = {
			VAL_NameEntries: asKeys,
			VAL_ExpandGroup: !!this.fExpandGroup,
			VAL_Type: 2 - !this.fIgnoreContacts,
			VAL_Flags: fGetFlags,
			VAL_SendEncrypted: fGetFlags,
			'%%PostCharset': 'UTF-8'	// Using XMLHttpRequest, POST data will be URL encoded. So set UTF-8 to %%PostCharset.
		};
	
		var sLog = 'Looking up name: [' + asKeys.join(';') + ']' + (oListener ? (' (Key: ' + oListener.sKey + ')') : '');
		console.debug(sLog);
	
		var oValidationDataListener = new dwa.type.nameLookupListener(null, this);
		var sUrl = com_ibm_dwa_globals.sNsfPath + '/' + "iNotes" + '/' + "Proxy" + '/' + '?EditDocument&Form=s_ValidationJson';
		{
			sUrl = "data/s_ValidationJson.json"; //@kami@
		}
	
		// Save the URL and POST data for when resuming from Notes ID password dialog
		oValidationDataListener.sUrl = sUrl; 
		oValidationDataListener.oData = oData;
	
		oValidationDataListener.oListener = oListener;
		oValidationDataListener.track(sActivityHandler);
//		oValidationDataListener.nTimeout = !oListener.oElem ? void 0 :
//		 setTimeout(dojo.hitch(oValidationDataListener, "abort"), dwa.type.nNameTypeaheadWaitTimeout);
		oValidationDataListener.load(sUrl, '' + (new dwa.common.presets(oData, true)));
	},

	setJsonNode: function(oNode){
		// BEGIN - SPR# SQZO7PTA5J
		// sometimes, duplicate UNIDs can exist in both local and server JSON data
		// moved comparison functions out of nested FOR loops for better performance
	
		//check for non-local duplicate entry by checking UNID
		//similar function as in standard DWA : VAL_getIndexOfSameUnid
		var fnUnidCompare = function(vElem1, vElem2) {
			// SPR# CBJL7P68SL: LDAP entries return empty UNID and NOTEID
			// check noteid only on offline - no unid is returned for entries in offline CDC (YHAO7JBC9E, YHAO74LF2D, DJAG6TTFXB)
			return (vElem1.sUnid.toLowerCase() == vElem2.sUnid.toLowerCase()) && (this.bIsOffline ? vElem1.sNoteId.toLowerCase() == vElem2.sNoteId.toLowerCase() : "" != vElem2.sUnid);
		};
	
		//check for duplicate entry between local and server by checking address
		//similar function as in standard DWA : VAL_getIndexOfSameAddress
		var fnAddressCompare = function(vElem1, vElem2){
			if (vElem1 instanceof dwa.common.name) 
				return vElem1.getAbbrev() == vElem2.getDisplayName().getAbbrev();
			else
				return vElem1.equals(vElem2);
		};
	
		// END - SPR# SQZO7PTA5J
		var oLocalDirs = {local: void 0, dpab: void 0};
	
		for (var aoNode = oNode.viewentry.entrydata, i = 0; i < aoNode.length; i++) {
			if (!aoNode[i].viewentries)
				continue;
	
			var sDir = aoNode[i]['@name'];
//@			if (sDir == 'local' && !(com_ibm_dwa_globals.oSettings.sAreas.charAt(4) - 0))
//@				continue;
			for (var aoDirNode = aoNode[i].viewentries.viewentry, j = 0; aoDirNode && j < aoDirNode.length; j++) {
				var oContents = {};
				for (var aoNameNode = aoDirNode[j].entrydata, k = 0; k < aoNameNode.length; k++) {
					var sName = aoNameNode[k]['@name'];
					oContents[sName] = sName != 'candidate' ?
					 (new dwa.common.notesValue).setJsonNode(aoNameNode[k]).vValue : aoNameNode[k].viewentries.viewentry;
				}
	
				var oNameEntities = this.oNameEntities[oContents['originalName']];
				oNameEntities.fResolved = true;
				// An older lookup from server has filfilled this data
				if (!dwa.type.bDpabTypeaheadEnabled && oNameEntities.getLength() && i == 0)
					continue;
	
				for (var aoCandidateNode = oContents['candidate'], k = 0; aoCandidateNode && k < aoCandidateNode.length; k++) {
					var oNameEntity = (new dwa.common.nameEntity).setJsonNode(aoCandidateNode[k]);
					oNameEntity.sDir = sDir;
					oNameEntity.sRoutingDomain = oContents['routingDomain'];
					oNameEntity.fLimited = !!oContents['limited'];
					oNameEntity.nError = oContents['errorCode'];
					//SPR# RTOA854MGD: due to fix for SPR# YHAO7Y4HS8 in s_CommonNamePicker.h
					oNameEntity.fNotYetFetched = false;
					//check for non-local duplicate entry by checking UNID
					var nIndex = dwa.common.utils.indexOf(oNameEntities.aoEntities, oNameEntity, fnUnidCompare);
					if ( nIndex >= 0) {
						//SPR VSEN7BQTZ8
						//SPR# SQZO7PTA5J
						// new oNameEntity objects will either be from 'local' contacts or a server directory
						// order of importance:  1. server, 2. local, 3. dpab
						if (oNameEntities.aoEntities[nIndex].sDir in oLocalDirs)
							oNameEntities.aoEntities[nIndex] = oNameEntity;
	
						// nFlags is only retrieved when Sign or Encrypt is checked.
						// If once validated without checking then checked next time, need to replace cached entries to set nFlags.
						if ((typeof(oNameEntities.aoEntities[nIndex].nFlags) == 'undefined' && typeof(oNameEntity.nFlags) != 'undefined')
						// Public group members are retrieved.
						|| (!oNameEntities.aoEntities[nIndex].aoMembers && oNameEntity.aoMembers))
							oNameEntities.aoEntities[nIndex] = oNameEntity;
	
						continue;
					}
					//SPR HTAA7QPCVE, 
					//if the type is group, we can't tell they are equals by looking into the addresses,
					//so just ignore the address checking.
					if (oNameEntity.sType != 'Group') {
						//check for duplicate entry between local and server by checking address
						nIndex = dwa.common.utils.indexOf(oNameEntities.aoEntities, oNameEntity, fnAddressCompare);
						if ( nIndex >= 0){
							//SPR VSEN7BQTZ8
							//use the one from server contact
							if (oNameEntities.aoEntities[nIndex].sDir in oLocalDirs)
								oNameEntities.aoEntities[nIndex] = oNameEntity;
							continue;
						}
					}
	
					oNameEntities.aoEntities[oNameEntities.getLength()] = oNameEntity;
				}
	
				if (!oNameEntities.getLength())
					this.oNamesIgnore[oContents['originalName']] = void 0;
				else {
					if ('local'==sDir && dwa.type.bDpabTypeaheadEnabled) {
						// use RFC-822 names for local Internet addresses since local contacts are not resolved in server code on sending a message
						var oDpabManager = dwa.type.dpabNamesManager.get(true);
						for (var n=0, nmax=oNameEntities.getLength(); n<nmax; n++) {
							oDpabManager.setDefaultNameProperties( oNameEntities.aoEntities[n] );
						}
					}
					
					// com_ibm_dwa_ui_nameValidator keeps whatever user puts in <input> field as its search key. It can be canonical name.
					// In such case, keeping its abbreviated version in the table avoids redundant request to the same name.
					var sAbbrevName = new dwa.common.name(oContents['originalName']).getAbbrev();
					if (sAbbrevName != oContents['originalName']) {
						this.oNameEntities[sAbbrevName] = new dwa.common.nameEntities;
						this.oNameEntities[sAbbrevName].aoEntities = oNameEntities.aoEntities;
						this.oNameEntities[sAbbrevName].fResolved = true;
					}
				}
			}
		}
	},
	nQueueLen: 1,
	nQueueLen: 3
});

dwa.type.nameValidator.get = function(){
	return dwa.type.nameValidator.oValidator ? dwa.type.nameValidator.oValidator :
	(dwa.type.nameValidator.oValidator = new dwa.type.nameValidator());
};
