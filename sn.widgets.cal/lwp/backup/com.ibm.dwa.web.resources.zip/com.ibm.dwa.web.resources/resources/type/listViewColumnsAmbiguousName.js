/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_validation.h

dojo.provide("dwa.type.listViewColumnsAmbiguousName");


dojo.declare(
	"dwa.type.listViewColumnsAmbiguousName",
	null,
{

	constructor: function(sId){
		dwa.widget.notesListViewColumns.call(this, sId);
	},
	oSwitchSortingMap: {
		0: 1,
		1: 2,
		2: 1
	},

	load: function(){
		var sDialogId = 'e-dialog-ambiguousname';
		var oDialogWidget = com_ibm_dwa_io_widgetListener.prototype.oWidgets[sDialogId + ':com_ibm_dwa_ui_dialog'];
		if (!oDialogWidget) {
			//need the element offset value, so wait for the dialog widget created.
			setTimeout(dojo.hitch(this, "load"), 200);
			return;
		}
	
		var oElem = dojo.doc.getElementById(this.sId);
		var sProperty = oElem.getAttribute('com_ibm_dwa_misc_observes_viewColumns');
		var nExtendWidthPos = 0;
	
		var asTitles = [dwa.type._msgs["L_AMBIGOUS_COL_NAME"]];
		var asWidths = [L_AMBIGOUS_COL_NAME_WIDTH];
	
		if (!this.bDisableAltName) {
			asTitles.push(dwa.type._msgs["L_AMBIGOUS_COL_ALTNAME"]);
			asWidths.push(L_AMBIGOUS_COL_ALTNAME_WIDTH);
		}
	
		if (!this.bDisableMailAddress) {
			asTitles.push(dwa.type._msgs["L_AMBIGOUS_COL_ADDRESS"]);
			asWidths.push(L_AMBIGOUS_COL_ADDRESS_WIDTH);
			nExtendWidthPos = asTitles.length -1;
		}
	
		if (!this.bDisableMailDomain) {
			asTitles.push(dwa.type._msgs["L_AMBIGOUS_COL_DOMAIN"]);
			asWidths.push(L_AMBIGOUS_COL_DOMAIN_WIDTH);
		}
	
		asTitles = asTitles.concat([dwa.type._msgs["L_AMBIGOUS_COL_DIR"], dwa.type._msgs["L_AMBIGOUS_COL_TYPE"]]);
		asWidths = asWidths.concat([L_AMBIGOUS_COL_DIR_WIDTH, L_AMBIGOUS_COL_TYPE_WIDTH]);
	
		if(!this.bDisableCert) {
			asTitles.push(dwa.type._msgs["L_AMBIGOUS_COL_CERT"]);
			asWidths.push(L_AMBIGOUS_COL_CERT_WIDTH_LITE);
		}
	
	
		var oCols = new dwa.widget.miscNotesListViewColumns;
		for (var i = 0; i < asTitles.length; i++){
			var oColumn = new dwa.widget.miscNotesListViewColumn;
			oColumn.nPixelWidth = parseInt(asWidths[i]);
			oColumn.fFixedWidth = false;
			oColumn.fIcon = false;
			oColumn.nColSort = 5;
			oColumn.nCurrentSortOrder = (i == 0 ? 2 : 0);
			oColumn.sTitle =  asTitles[i];
			oColumn.sName = '' + i;
			oColumn.nViewSort = 2; //0;
			oColumn.fBytes = false;
			oColumn.fDateOnly = false;
			oColumn.fTimeOnly = false;
			oColumn.fOmitThisYear = false;
			oColumn.fExtendWidth = (i == nExtendWidthPos ? true : false);
			oCols[i] = oColumn;
		}
		
		oCols.nLength = asTitles.length;
		oCols.distributeExtendedWidth(oElem.offsetWidth - 16);
	
		if (sProperty)
			dwa.widget.commonProperty.get(sProperty).setValue(oCols);
	}
});
