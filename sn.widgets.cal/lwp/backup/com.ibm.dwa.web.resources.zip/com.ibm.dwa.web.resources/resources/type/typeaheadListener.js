/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_validation.h

dojo.provide("dwa.type.typeaheadListener");

dojo.require("dwa.common.utils");
dojo.require("dwa.common.listeners");

dojo.declare(
	"dwa.type.typeaheadListener",
	dwa.common.responseListener,
{
	nMaxEntries: 8,

	constructor: function(sKey, oValidator, ev){
		this.oElem = ev.target;
		this.oElem.oListener = this;
		this.oValidator = oValidator;
		this.oValidator.oDropdownManager.setPos(ev);
		if(!dojo.isFF){
			this.nKeyCode = ev.keyCode;
		}else{
			// Gecko browsers gives 0 keyCode in keypress events for regular characters and gives charCode instead
			// SPR #DYHG77UB9K - asudoh 10/15/2007
			this.nKeyCode = ev.type == 'keypress' ? ev.charCode : ev.keyCode;
		}
		this.nStartPos = -1;
		this.nSeq = 0;
	},

	onDatasetComplete: function(){
		if (this.oElem.oListener != this || this.oValidator.oFocusElement != this.oElem) {
			var sLog = 'Outdated typeahead response ' + this.sKey + '... Bailing.';
			console.debug(sLog);
			return;
		}
		this.showDropDown(this.getDropDownInfo());
	},

	onError: function(e){
		this.oValidator.oNamesIgnore[this.sLookup] = IGNORE_LIST_IGNORE;
	},

	// l_validation.h#com_ibm_dwa_io_typeaheadListener_getDropDownHtml()
	getDropDownInfo: function(fPage){
		switch (fPage){
		case dwa.type.typeaheadListener.fPrev:
			this.nPageStart -= this.nMaxEntries;
			break;
		case dwa.type.typeaheadListener.fNext:
			this.nPageStart += this.nMaxEntries;
			break;
		default:
			this.nPageStart = 0;
			break;
		}
		var sHtml = this.oValidator.oDropdownManager.oHtml['e-dropdown-' + this.sKey + '-' + this.nSeq + '-' + this.nPageStart];
		if (sHtml) return sHtml;
	
		var sValue = (this.sLookup).replace(/^\s\s*/, '').replace(/\s*\s$/, '');
		// SPR# PTHN7TCKM6: Only show DPAB entries for type-ahead. Do not include them in the search-directory result.
		// save the list of nameEntities within this typeaheadListener instance as it is used in typeaheadListener_select
		var oNameEntities = this.oNameEntities = dwa.type.bDpabTypeaheadEnabled && this.oValidator.fShowSearch ? dwa.type.dpabNamesManager.get().lookup(sValue) : this.oValidator.oNameEntities[sValue];
		var nLength = oNameEntities ? oNameEntities.getLength() : 0;
	
		console.debug(nLength + ' entries for [' + sValue + '].');
	
		if (com_ibm_dwa_globals.fLogNameLookup) {
			for (var i = 0; i < nLength; i++) {
				console.debug('Candidate #' + i + '...');
				var oNameEntity = oNameEntities.aoEntities[i];
				for (var s in oNameEntity.oContents) {
					console.debug(s + '[' + oNameEntity.oContents[s] + ']');
				}
			}
		}
	
		// dg:  removed check for:  nLength > nMaxEntries ... use paging system below
		// Show an action to verify the name in all directories, if the list is from the DPAB
		if (nLength == 1 && oNameEntities.getName(0) == sValue)
			return '';
	
//		var asActions = [];
		var anActionIndexes = [];
		var asCaptionHtml = [];
		var sImageTemplate = '<center unselectable="on" style="' + '' + '">&nbsp;';
		// high-contrast mode
		if(dojo.hasClass(dojo.body(), "dijit_a11y")){
			sImageTemplate += '<div style="display:inline-block;position:relative;width:7px;height:4px;overflow:hidden;">'
			 + '<img align="center" src="'
			 + dojo.moduleUrl("dwa/common", "images/basicicons.gif")
			 + '"'
			 + ' unselectable="on" style="border-width:0px;left:-%1px;top:-20px;position:absolute;" alt="%2" />'
			 + '</div>';
		}else{
			sImageTemplate += '<img align="center" border="0" width="7" height="4" src="'
			 + dojo.moduleUrl("dojo", "resources/blank.gif")
			 + '"'
			 + ' ' + '' + 'xoffset="%1" ' + '' + 'yoffset="20"'
			 + ' unselectable="on" style="' + '' + '" alt="%2" />'
		}
		sImageTemplate += '&nbsp;</center>';
		
		// paging: add 'previous' tag
		if (this.nPageStart > 0){
			// SPR# PTHN7NYLHX: let menu code build the menu item
			asCaptionHtml.push( dwa.common.utils.formatMessage(sImageTemplate, '80', 'previous icon') );
//			asActions.push( 'com_ibm_dwa_ui_actionSelectTypeahead {sKey: \'' + this.sKey + '\', nIndex: ' + dwa.type.typeaheadListener.fPrev + '}' );
			anActionIndexes.push(dwa.type.typeaheadListener.fPrev);
		}
	
		for (var n = this.nPageStart, nMax = this.nPageStart + this.nMaxEntries; n < nMax; n++) {
			if (n >= nLength) break;
			// setting innerText preserves RFC-822 names like:  "Dan Gurney" <dangurney@allamericanracers.com>
			dwa.common.utils.elSetInnerText(dwa.type.oPseudoDiv, oNameEntities.getName(n));
			asCaptionHtml.push( ''
				+ '<span unselectable="on" style="' + '' + '">'
				+ dwa.type.oPseudoDiv.innerHTML
			 	+ '</span>'
			);
//			asActions.push( 'com_ibm_dwa_ui_actionSelectTypeahead {sKey: \'' + this.sKey + '\', nIndex: ' + n + '}' );
			anActionIndexes.push(n);
		}
		// Show an action to verify the name in all directories, if the list is from the DPAB
		if (dwa.type.bDpabTypeaheadEnabled) {
			if (oNameEntities.fResolved) {
				// SPR# PTHN7SFQL6: if no entries match a full search, show an alert
				if (0==nLength) {
					console.info((dwa.type._msgs["L_VAL_NOMATCH_PRENAME"] + ' "' + this.sLookup + '" ' + dwa.type._msgs["L_VAL_NOMATCH_POSTNAME"]));
				}
			} else if (this.oValidator.fShowSearch) {
				dwa.common.utils.elSetInnerText(dwa.type.oPseudoDiv, this.sLookup);
				asCaptionHtml.push(
					'<span unselectable="on" style="font-weight:bold;' + '' + '">'
					+ dwa.common.utils.formatMessage(dwa.type._msgs["L_DPAB_SEARCH"], dwa.type.oPseudoDiv.innerHTML)
					+ '</span>'
				);
				anActionIndexes.push(dwa.type.typeaheadListener.fSearch);
			}
		}
	
		// paging: add 'next' tag
		if (nLength > n){
			// SPR# PTHN7NYLHX: let menu code build the menu item
			asCaptionHtml.push( dwa.common.utils.formatMessage(sImageTemplate, '90', 'next icon') );
//			asActions.push( 'com_ibm_dwa_ui_actionSelectTypeahead {sKey: \'' + this.sKey + '\', nIndex: ' + dwa.type.typeaheadListener.fNext + '}' );
			anActionIndexes.push(dwa.type.typeaheadListener.fNext);
		}
	
		// sKey + nPageStart makes the HTML unique, otherwise the dropdown HTML is never refreshed for paging
//		var sHtml = (0==nLength && oNameEntities.fResolved) ? '' :
//		   '<div id="e-dropdown-' + this.sKey + '-' + this.nSeq + '-' + this.nPageStart
//		 + '" class="s-popup" ' + '' + 'com_ibm_dwa_ui_widget_class="com_ibm_dwa_ui_dropdownMenu"'
//		 + ' ' + '' + 'com_ibm_dwa_ui_dropdownMenu_actions="' + asActions.join('|') + '"'
//		 + ' ' + '' + 'com_ibm_dwa_ui_dropdownMenu_handleKeys="onclick:' + 44 + ' ' + 188 + '"'
//		 + '>'
//		 + asCaptionHtml.join('')
//		 + '</div>';
		return {asCaptions: asCaptionHtml, anActionIndexes: anActionIndexes};
	},

	showDropDown: function(menuInfoObj){
		sId = this.oElem.id + "-menu";
		var menu = dijit.byId(sId);
		if(menu){
			menu.destroy();
		}
		
		if(menuInfoObj.asCaptions.length == 0){
			this.oValidator.oDropdownManager.hide();
			return;
		}
		
		dojo["require"]("dwa.common.menu");
		var asCaptions = menuInfoObj.asCaptions;
		var anActionIndexes = menuInfoObj.anActionIndexes;
		var menuInfo = [];
		for(var i = 0; i < anActionIndexes.length; i++){
			menuInfo.push({
				label: asCaptions[i],
				action: dojo.hitch(this, function(nIndex){
					this.select(nIndex);
				}),
				args: [anActionIndexes[i]]
			});
		}
		dojo.addOnLoad(this, function(){
			var menu = new dwa.common.menu({
				dropdownManagerId: "validator",
				supportScreenReader: false,
				menuInfo: menuInfo,
				handleFocus: false
			}, dojo.create("div", {id: sId}, dojo.body()));
			menu.startup();
			this.oValidator.oDropdownManager.show(null, sId);
			// TODO: remove following 9 lines
			var box = dojo.marginBox(this.oElem);
			var top = this.oValidator.oDropdownManager.oPos.y + box.h;
			if(dojo.isFF || dojo.isWebKit){
				top = top - 1;
			}
			dojo.style(menu.domNode, {top: top + "px"});
			if(!dojo.isFF && !dojo.isWebKit && this.oValidator.oDropdownManager.oCover){
				dojo.style(this.oValidator.oDropdownManager.oCover, {top: top + "px"});
			}
			// screen reader
			var typeAhead = dijit.byNode(this.oElem);
			if(typeAhead.supportScreenReader){
				typeAhead.setTextForScreenReader(menu.getSelectedLabelText());
			}
		});
		
		// original codes
//		this.oValidator.oDropdownManager.oHtml['e-dropdown-' + this.sKey + '-' + this.nSeq + '-' + this.nPageStart] = menuInfo.sHtml;
//		this.oValidator.oDropdownManager.show(void 0, 'e-dropdown-' + this.sKey + '-' + this.nSeq + '-' + this.nPageStart);
	},

	select: function(nIndex){
		var oMainDoc = dojo.doc;
	
		switch (nIndex){
		// check for search mechanism
		case dwa.type.typeaheadListener.fSearch:
			this.nSeq++;	// nSeq ensures that the drop-down html is unique
			setTimeout(dojo.hitch(this.oValidator, "searchDirectories", this), 0);
			return;
		// check for paging tags
		case dwa.type.typeaheadListener.fPrev:
		case dwa.type.typeaheadListener.fNext:
			setTimeout( dojo.hitch(this, "showDropDown", this.getDropDownInfo(nIndex)), 0);
			return;
		}
		
		// select value 
		var sValue = (this.sLookup).replace(/^\s\s*/, '').replace(/\s*\s$/, '');
		var oNameEntities = this.oNameEntities; // might be either dpab or cached search results from this.oValidator.lookup;
	
		if (oNameEntities.getLength() > nIndex) {
			if ('true'==this.oElem.getAttribute('com_ibm_dwa_ui_typeaheadManager_singleton')) {
				this.oElem.value = oNameEntities.getName(nIndex, dwa.type.bPreferRFC822 ? 'dispaddress' : '');
			}else{
				var oFieldNameEntities = dwa.common.fieldNameEntities.get(this.oElem);
				var nPos = this.getStartPos(true);
				var nFieldIndex = oFieldNameEntities.getEntityIndex(nPos);
				var sValue = this.oElem.value;
				var nStart = oFieldNameEntities.anStart[nFieldIndex];
				var nEnd = nStart + this.sLookup.length;
	
				for (; dwa.common.fieldNameEntities.prototype.oSep.test(sValue.charAt(nEnd)); nEnd++);
				if(!dojo.isFF && !dojo.isSafari){
					var oRange = dwa.common.utils.getRangeAt(oMainDoc, 0).duplicate();
					oRange.moveToElementText(this.oElem);
					oRange.collapse();
					oRange.move('character', nStart);
					oRange.moveEnd('character', nEnd - nStart);
					oRange.text = oNameEntities.getName(nIndex) + ', ';
				}else{
					this.oElem.value = sValue.substring(0, nStart) + oNameEntities.getName(nIndex, dwa.type.bPreferRFC822 ? 'dispaddress' : '') + ', ' + sValue.substr(nEnd);
					nEnd = nStart + (oNameEntities.getName(nIndex) + ', ').length;
					this.oElem.setSelectionRange(nEnd, nEnd);
				}
				oFieldNameEntities.aoEntities[nFieldIndex] = oNameEntities.aoEntities[nIndex];
				oFieldNameEntities.synchronize();
			}
			this.oValidator.oDropdownManager.hide();
		}
	
		if(!dojo.isFF && !dojo.isSafari){
			dwa.common.utils.getRangeAt(oMainDoc, 0).scrollIntoView();
		}
	
		if (this.oElem.onTypeaheadSelected)
			this.oElem.onTypeaheadSelected();
	},

	getStartPos: function(fReset){
		//	SPR# SQZO7NJBF4
		var nStartPos = this.nStartPos;
		if (fReset)
			this.nStartPos = -1;
		if (-1 == nStartPos){
			if(!dojo.isFF && !dojo.isSafari){
				var oRange = dwa.common.utils.getRangeAt(dojo.doc, 0);
				var nCur, fError=false;
				try {
				var oRangeWhole = oRange.duplicate();
				oRangeWhole.moveToElementText(this.oElem);
				} catch(er) { 
					fError = true;
				}

				if (!fError) {
					nCur = oRangeWhole.text.length;
				for (var nLength = nCur, nLeft = 0, nRight = nLength, nSign = -1, i = 0;
				 nSign != 0 && i < nLength; nCur = oRangeWhole.text.length, i++) {
					nSign = oRange.compareEndPoints('StartToEnd', oRangeWhole);
					nLeft = nSign < 0 ? nLeft : nCur;
					nRight = nSign > 0 ? nRight : nCur;
					oRangeWhole.moveEnd('character', nSign * Math.floor((nRight - nLeft) / 2));
				}
				} else {
					nCur = this.oElem.value.length;
				}
			}else{
				var nCur = this.oElem.selectionStart;
			}
	
			for (var sValue = this.oElem.value; nCur > 0 && /[,\uff0c\s]+$/.test(sValue.substr(0, nCur)); nCur--);
			this.nStartPos = nStartPos = nCur;
		}
		return nStartPos;
	}
});
dwa.type.typeaheadListener.fSearch = -3;
dwa.type.typeaheadListener.fPrev = -2;
dwa.type.typeaheadListener.fNext = -1;
