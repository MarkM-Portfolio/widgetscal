/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_Typeahead.h

dojo.provide("dwa.type.typeAhead");

dojo.require("dojo.i18n");
dojo.require("dijit._Widget");
dojo.require("dwa.type.dpabNamesManager");

dojo.requireLocalization("dwa.type", "typeAhead");

window.com_ibm_dwa_globals = {};
dwa.type.bDpabTypeaheadEnabled = true;
if(!dwa.type.oPseudoDiv){
	dwa.type.oPseudoDiv = dojo.doc.createElement('div');
}

dojo.declare(
	"dwa.type.typeAhead",
	dijit._Widget,
{
	namesStore: null,
	validatorStore: null,

	// screen reader
	supportScreenReader: true,
	_ariaLabelNode: null,
	_keyTrapAnchorNode: null,
	_isFocusOnKeyTrapAnchor: false,

	postMixInProperties: function(){
		dwa.type._msgs = dojo.i18n.getLocalization("dwa.type", "typeAhead", this.lang);
	},

	postCreate: function(){
		var sId = this.id;
		this.sId = sId;

		this.domNode.rows = "1";
		dojo.addClass(this.domNode, "s-form-names s-panel-border");

		var oElem = this.domNode;
	
		if (dwa.type.bDpabTypeaheadEnabled){
			if(dojo.isWebKit){
				oElem.setAttribute("autocorrect", "off");  // turn off spell-check function on Safari
			}
			if(dojo.isFF || dojo.isWebKit){
				oElem.setAttribute("autocomplete", "off"); // turn off auto-complete function on Safari and Mozilla
			}
			dwa.type.nameValidator.get().validatorStore = this.validatorStore;
		}
		this.connect(oElem, 'keydown', "handleEvent")
		this.connect(oElem, 'keyup', "handleEvent")
		this.connect(oElem, 'focus', "handleEvent")
		this.connect(oElem, 'blur', "handleEvent")
		
		// find extension widgets
		var sListener = oElem.getAttribute('com_ibm_dwa_ui_TypeAhead_widgets');
		if (sListener) {
			this.aListeners = sListener.split(' ');
			// SPR# SQZO7PK5BJ: create an instance of the widget, if no instance is specified
			for (var i=0; i < this.aListeners.length; i++) {
				if (-1 == this.aListeners[i].indexOf(':')){
					new com_ibm_dwa_io_widgetListener(oElem.id, this.aListeners[i]);
					this.aListeners[i] = oElem.id + ':' + this.aListeners[i];
				}
			}
		}

		// initialize DPABNames
		if (dwa.type.bDpabTypeaheadEnabled) {
			var mgr = dwa.type.dpabNamesManager.get(true);
			mgr.namesStore = this.namesStore;
			mgr.init();
		}

		this.supportScreenReader = (dojo.isIE || dojo.isFF) && this.supportScreenReader;
		// create label/a tag for screen reader
		if(this.supportScreenReader && (8 <= dojo.isIE || 3 <= dojo.isFF)){
			this._ariaLabelNode = dojo.create("label", {
				id: (this.sId + "_arialabel"),
				tabIndex: 0
			}, dojo.body());
			dojo.style(this._ariaLabelNode, {
				display: "none",
				position: "absolute",
				top: "-9999px"
			});
			dijit.setWaiState(oElem, "labelledby", this._ariaLabelNode.id);
		}else if(this.supportScreenReader && (dojo.isIE < 8 || dojo.isFF < 3)){
			this._keyTrapAnchorNode = dojo.create("a", {
				innerHTML: "&nbsp;",
				tabIndex: -1
			}, dojo.body());
			dojo.style(this._keyTrapAnchorNode, {
				display: "none",
				position: "absolute",
				top: "-9999px"
			});
		}
	},

	handleEvent: function(ev){
		if(this._isFocusOnKeyTrapAnchor){
			return;
		}
		
		switch( ev.type ){
		case 'focus':
		case 'keydown':
		case 'keyup':
			if (dwa.type.bDpabTypeaheadEnabled)
				dwa.type.nameValidator.get().invokeTypeahead(ev);
			else {
				var oElem = this.domNode;
				// block enterkey to prevent line wrapping
				if(ev.type=='keydown' && ev.keyCode==13) {
					ev.stopPropagation();
					ev.preventDefault();
					return;
				}
			}
			break;
	
		case 'blur':
			if(dojo.isSafari){
				if(gbIsIPod)
					break;
			}
			dwa.common.dropdownManager.get('validator').hide();
			break;
		}
	
	
		if (this.aListeners)
			for (var i=0,imax=this.aListeners.length; i<imax; i++)
				// possible timing problem introduced in build 266 .. check for widget instance
				if (this.aListeners[i] && com_ibm_dwa_io_widgetListener.prototype.oWidgets[this.aListeners[i]]
					// check if typeaheadExtension method exist sinse cause error on tearoff window
					&& com_ibm_dwa_io_widgetListener.prototype.oWidgets[this.aListeners[i]].typeaheadExtension)
					com_ibm_dwa_io_widgetListener.prototype.oWidgets[this.aListeners[i]].typeaheadExtension(ev,this.sId);
	
		return false;
	},

	setTextForScreenReader: function(text){
		if(!this.supportScreenReader){
			return;
		}
		// wai-aria
		if(8 <= dojo.isIE || 3 <= dojo.isFF){
			this._ariaLabelNode.innerHTML = text;
			dijit.setWaiState(this.domNode, "labelledby", "");
			dijit.setWaiState(this.domNode, "labelledby", this._ariaLabelNode.id);
		// title attribute
		}else if(dojo.isIE < 8 || dojo.isFF < 3){
			this.domNode.setAttribute("title", text);
			this._keyTrapAnchorNode.setAttribute("tabIndex", 0);
			this._isFocusOnKeyTrapAnchor = true;
			try {
				this._keyTrapAnchorNode.focus();
				this.domNode.focus();
			}catch(e){}
			this._isFocusOnKeyTrapAnchor = false;
			this._keyTrapAnchorNode.setAttribute("tabIndex", -1);
		}
	},

	destroy: function(){
		if(this._ariaLabelNode){
			dojo.body().removeChild(this._ariaLabelNode);
		}
		if(this._keyTrapAnchorNode){
			dojo.body().removeChild(this._keyTrapAnchorNode);
		}
		this.inherited(arguments);
	}
});
