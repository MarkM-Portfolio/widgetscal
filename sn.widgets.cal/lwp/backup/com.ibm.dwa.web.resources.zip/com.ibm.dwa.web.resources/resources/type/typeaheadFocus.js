/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_validation.h

dojo.provide("dwa.type.typeaheadFocus");


dojo.declare(
	"dwa.type.typeaheadFocus",
	null,
{

	constructor: function(sId){
		var oElem = dojo.doc.getElementById(sId);
		// SPR# LSHR7U8LDP: set focus to input field after type-ahead choice
		oElem.focus();
		// SPR# JFAL7UCKAN: scroll to end of input field after type-ahead choice
		//	for some reason, the iPhone's input.offsetWidth and input.clientWidth values are larger than what is really available to the user.
		//  Use 2 * offsetLeft to get offsetRight.
		//	And make up for some unknown left-right padding on the device.
		oElem.scrollLeft = D_iPhoneInputPadding + (2 * oElem.offsetLeft) + oElem.scrollWidth - oElem.offsetWidth;
	}
});
