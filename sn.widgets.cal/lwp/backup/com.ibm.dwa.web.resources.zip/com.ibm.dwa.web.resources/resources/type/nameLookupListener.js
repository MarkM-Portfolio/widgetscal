/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_validation.h

dojo.provide("dwa.type.nameLookupListener");

dojo.require("dwa.common.listeners");

dojo.declare(
	"dwa.type.nameLookupListener",
	dwa.common.xmlListener,
{

	constructor: function(sKey, oValidator){
		this.oValidator = oValidator;
	},

	onDatasetComplete: function(){
		if(!dojo.isFF){
			if (this.oHttpRequest.readyState != 4)
				return;
		}
	
		// oNode will be set in the eval script
		var oNode;
	
		try {
//			if (!this.checkHttpStatus('application/json'))
//				return;
			var sLog = 'Data available from server... Evaluating data.' + (this.oListener ? (' (Key: ' + this.oListener.sKey + ')') : '');
			console.debug(sLog);
			oNode = eval('(' + this.oHttpRequest.responseText + ')');
		} catch (e) {
			this.onError(e);
			return;
		}
	
		this.oValidator.setJsonNode(oNode);
	
		var sLog = 'Evaluating data complete.' + (this.oListener ? (' (Key: ' + this.oListener.sKey + ')') : '');
		console.debug(sLog);
	
		if (this.oListener)
			this.oListener.onDatasetComplete();
	
		this.release();
	},

	onError: function(e){
		if(!dojo.isFF){
			var sLog = !this.fAborted ? (dwa.common.utils.formatMessage(dwa.type._msgs["L_ERR_LOAD_FAILURE_LITEUI"], e ? e.message : dwa.type._msgs["L_ERR_NO_RESPONSE"])) :
				'Name lookup request has been aborted.' + (this.oListener ? (' (Key: ' + this.oListener.sKey + ')') : '');
//			com_ibm_dwa_globals.oStatusManager.addEntry(!this.fAborted ? 0 : 3, '', sLog);
			if (this.oListener)
				this.oListener[!this.fAborted ? 'onError' : 'release'](!this.fAborted ? e : void 0);
		}else{
//			com_ibm_dwa_globals.oStatusManager.addEntry(0, '',
//				dwa.common.utils.formatMessage(dwa.type._msgs["L_ERR_LOAD_FAILURE_LITEUI"], e ? e.message : dwa.type._msgs["L_ERR_NO_RESPONSE"]));
			this.onError(e);
		}
		this.release();
	},

	abort: function(){
		if (this.oHttpRequest.readyState == 0) {
			// SPR #DYHG7A2BB8: In case session had been expired when lookup started, abort() might be called
			// during re-login screen is shown. In such case we should not invalidate this.oHttpRequest and
			// should just postpone current timeout
			this.nTimeout = setTimeout(dojo.hitch(this, "abort"), dwa.type.nNameTypeaheadWaitTimeout);
			return;
		}
		this.fAborted = true;
		this.oHttpRequest.abort();
		if(dojo.isFF){
			if (this.oListener)
				this.oListener.release();
			this.release();
		}
	},

	release: function(){
		if (typeof(this.nTimeout) != 'undefined') {
			clearTimeout(this.nTimeout);
			this.nTimeout = void 0;
		}
		this.inherited(arguments);
	}
});
dwa.type.nameLookupListener.prototype.onReadyStateChange = dwa.type.nameLookupListener.prototype.onDatasetComplete;
