/* ***************************************************************** */
/*                                                                   */
/* IBM Confidential                                                  */
/*                                                                   */
/* OCO Source Materials                                              */
/*                                                                   */
/* Copyright IBM Corp. 2009, 2011                                    */
/*                                                                   */
/* The source code for this program is not published or otherwise    */
/* divested of its trade secrets, irrespective of what has been      */
/* deposited with the U.S. Copyright Office.                         */
/*                                                                   */
/* ***************************************************************** */

// generated from l_validation.h

dojo.provide("dwa.type.dpabNamesManager");

dojo.require("dwa.common.listeners");
dojo.require("dwa.common.name");
dojo.require("dwa.common.nameEntities");
dojo.require("dwa.common.nameEntity");
dojo.require("dwa.type.nameValidator");

dojo.declare(
	"dwa.type.dpabNamesManager",
	dwa.common.nameEntities,
{
	namesStore: null,
	nTypeaheadMaxNames: 120,

	constructor: function(){
		this.oCache = {};
	},

	init: function(){
		var sJson;
		sJson = document.body.getAttribute("com_ibm_dwa_dpab");
	
		if (sJson && sJson!=this.sJson)
			this.setJsonNode( eval('(' + sJson + ')') );

		if (!this.aoEntities.length && !this.fRequested)
			this.requestData();
		return this;
	},

	lookup: function(sLookup){
		if (!this.oCache[sLookup]) {
			// SPR ASUH7SF9HY:  Lite mode: Non-inet DPAB names appear in ambig name dialog
			//  do lookup in a similar fashion to $Users view ... only search on the beginning of first and last names
			var s1 = sLookup.toLowerCase(), s2 = ' ' + s1, s3 = '"' + s1, s4 = '<' + s1;
			this.oCache[sLookup] = new dwa.common.nameEntities;
			this.oCache[sLookup].sDir		= 'dpab';
			for (var i = 0, imax = this.getLength(); i < imax; i++) {
				var sName = this.getName(i).toLowerCase();
				if (0 == sName.indexOf(s1) || sName.indexOf(s2) >= 0 || sName.indexOf(s3) >= 0 || sName.indexOf(s4) >= 0)
					this.oCache[sLookup].aoEntities.push(this.aoEntities[i]);
			}
		}
		return this.oCache[sLookup];
	},

	toJsonString: function(){
		var a=[];
		for (var i=0; i<this.aoEntities.length; i++){
			if (!this.aoEntities[i].sRawData)
				this.aoEntities[i] = this.setDefaultNameProperties( this.aoEntities[i] );
	
			// SPR# ASUH7S9JRN: escape the apostrophe in names like Mike O'Brien and remove any quotes in RFC-822 comments
			a[i]=this.aoEntities[i].sRawData.replace(/([\'\"])/g, "\\$1");
		}
		return "{'type':'dpab','items':['" + a.join("','") + "']}";
	},

	setJsonNode: function(oJson, fStore){
		if (!oJson || "dpab"!=oJson.type)
			return;
	
		// Replacable Tokens
		//  [ 'token:real_value' ]
		var asTokens = [];
		for (var aoNodes = oJson.tokens, i = 0; aoNodes && i < aoNodes.length; i++) {
			var asToken = aoNodes[i].split(':');
			if (asToken[0])
				asTokens[asToken[0]] = asToken[1];
		}
	
		// RegExp to test for presence of token within an address
		var reToken = /([^%])%(\w+)%/;
	
		// Add names to internal array
		//  [ 'address:count' ]
		var aoEntities = [];
		for (var aoNodes = oJson.items, i = 0; aoNodes && i < aoNodes.length; i++) {
			var asName = aoNodes[i].split(':');
			if (!asName[0]) continue;
	
			// if there is a token, replace with real value
			if (asTokens.length) {
				var asMatch = reToken.exec(asName[0]);
				if (asMatch)
					asName[0] = asMatch[1] + asTokens[asMatch[2]];
			}
	
			// add entry to list
			if (!asName[0]) continue;
	
			var oName;
			var oPrimName = new dwa.common.name(asName[0]);
			if (!oPrimName.fInet && asName.length > 2) {
				// SPR# NZHG7SN4SM: use alternate-name stored in dpab record
				var oAltName  = new dwa.common.name(asName[2]);
				var sNotesDomain = oPrimName.asNotesDomain && oPrimName.asNotesDomain.join("@");
				oName = new dwa.common.nameEntity(oPrimName, oAltName, null, asName[3], sNotesDomain).getDisplayName();
			} else {
				oName = oPrimName;
			}
			aoEntities.push( this.setDefaultNameProperties( oName, asName ) );
		}
	
		// update DPAB
		this.update(aoEntities, true);
	},

	update: function(aoEntities, fIsEntity){
		var oValidator = dwa.type.nameValidator.get();
		function com_ibm_dwa_io_dpabNamesManager_update_compare(vElem1, sAddress){
			var v1 = vElem1 instanceof dwa.common.nameEntity ? vElem1.getDisplayName() : vElem1;
			return v1.sAddress == sAddress;
		}
	
		for (var nEntry=0; nEntry<aoEntities.length; nEntry++) {
			var sAddress  = (aoEntities[nEntry] instanceof dwa.common.nameEntity ? aoEntities[nEntry].getDisplayName() : aoEntities[nEntry]).sAddress;
			if (-1 == dwa.common.utils.indexOf(this.aoEntities, sAddress, com_ibm_dwa_io_dpabNamesManager_update_compare)) {
	
				// add new entry to locally cached DPAB list
				this.aoEntities.push( this.setDefaultNameProperties(aoEntities[nEntry]) );
	
				// There are two pieces of code doing similar update of type-ahead lookup cache entry:
				// (1) In com_ibm_dwa_ui_nameValidator_setJsonNode(), which is called whenever we get result of directory lookups
				// (2) In com_ibm_dwa_io_dpabNamesManager_update() (the code here), which is called only when user sends a memo
				//
				// (1) adds a type-ahead lookup cache entry associated with the search key for the directory lookup result.
				// For example, when user runs directory lookup against "Firstname Lastname",
				// (1) adds type-ahead lookup cache entry for "Firstname Lastname".
				//
				// (2) looks for the history of search key user has typed and adds type-ahead lookup cache entries
				// whenever the such history partially matches with the search key for the directory lookup result.
				// For example, when user runs directory lookup against "Firstname Lastname",
				// (2) adds type-ahead lookup cache entry for "F", "Fi", "Fir"...
				//
				// When sending a memo ends up with directory lookups, both (1) and (2) are called,
				// which ends up with duplicate entries for the same name, which is "Firstname Lastname" in above example.
				//
				// The right fix will be not running (2) and making sure the in-memory DPAB data
				// (mainly in com_ibm_dwa_dpab attribute of the <body> in s_JSFrame) is updated whenever directory lookup result comes.
				//
				// For the last minute of 8.5.1, we just disable (2). It appears that Classic/ultra-light has disabled (2) already.
				// SPR #NYWU7VBCM4 - asudoh 9/1/2009
			}
		}
		this.store();
	},

	store: function(){
		this.sJson = this.toJsonString();
		// store entities where we sparkle hybrid and lite forms might be able to share data
		document.body.setAttribute("com_ibm_dwa_dpab", this.sJson);
	},

	setDefaultNameProperties: function(oEntity, asRawData){
		var oDispName = (oEntity instanceof dwa.common.nameEntity ? oEntity.getDisplayName() : oEntity);
		// SPR# DGUY7SMJPZ: add phrase if no phrase is present in RFC-822 & RFC-821 addresses
		//  local contacts might have an Internet address, yet not be reported as Internet
		var oAddr = new dwa.common.name(oDispName.sAddress);
		if (oDispName.fInet || oAddr.fInet ) {
			if (!oDispName.sPhrase && !oDispName.f822 && (oDispName.sOriginal != oDispName.sAddress)) {
				oDispName.sPhrase = oDispName.sOriginal;
			}
			// rebuild the rfc822 address
			//  commas will cause problems in e-mail fields
			// also, rebuilding the RFC-822 name shows how search found the name.
			//	example local contact entry:
			//	 FullName:		['Frank Hoodlem', '"rocko" <francis.p.hoodlem@yahoo.com>']
			//   MailAddress:	'"rocko" <francis.p.hoodlem@yahoo.com>'
			//  type "rocko", no contact entry matches
			//  type "Frank", the above contact is returned.  
			//  old code would show "rocko" <francis.p.hoodlem@yahoo.com> in the type-ahead menu and in name-resolution. there appears to be no correlation to the search request for "Frank".
			//  new code below changes this to show:  "Frank Hoodlem" <francis.p.hoodlem@yahoo.com>, thus satisfying the search request.
			if (oDispName.sPhrase) {
				oDispName.fInet = oDispName.f822 = true;
	
				// SPR #MOSI84VP6V: Adding phrase part breaks encryption. Save the original address.
				if (!oDispName.sEncAddress)
					oDispName.sEncAddress = oDispName.sAddress;
	
				oDispName.sDispName = oDispName.sOriginal = oDispName.sAddress = '"' + oDispName.sPhrase.replace(/,/g, "") + '" <' + oAddr.sAddress + '>';
			}
		}
	
		// Set sDir to avoid lookup in com_ibm_dwa_ui_nameValidator_typeahead
		oEntity.sDir = oEntity.sDir || 'dpab';
		// Set sUnid to avoid breaking fnUnidCompare and to allow selection in AmbiguousNames dialog
		oEntity.sUnid = oEntity.sUnid || 'dpab' + (dwa.type.dpabNamesManager.nCount++);
		// Save original DPAB data; if not present, use display name
		oEntity.sRawData = oEntity.sRawData || (asRawData ? asRawData.join(':') : oEntity.toDpabString());
	
		return oEntity;
	},

	requestData: function(fnCB){
		this.fRequested = true;
		this.aoEntities = [];
		this.fnCB = fnCB;
		var _this = this;
		var fetch = {
			query: {maxNames: this.nTypeaheadMaxNames+2},
			onComplete: function(result, requestObject){
				dojo.hitch(_this, "_callbackSetData")(result, requestObject);
			},
			onError: function(errText){
				alert('dpabNamesManager#requestData: ' + errText);
			}
		};
		this.namesStore.fetch(fetch);
	},

	_callbackSetData: function(result, requestObject){
		this.setJsonNode(result, true);
		if (this.fnCB) {
			this.fnCB();
			this.fnCB = null;
		}
	},

	XXrequestData: function(fnCB){
		this.fRequested = true;
		this.aoEntities = [];
		this.fnCB = fnCB;
		var oXml = new dwa.common.xmlListener();
	
		// DPAB Names Manager : data listener
		oXml.onDatasetComplete = oXml.onReadyStateChange
		 = function com_ibm_dwa_io_dpabNamesManager_onDatasetComplete(){
		if(!dojo.isFF){
			if (this.oHttpRequest.readyState != 4)
				return;
		}
	
			// oNode will be set in the eval script
			var oJson;
			try {
//@				if (!this.checkHttpStatus('application/json'))
//@					return;
				var sLog = 'DPAB Names: Begin evaluating data';
				console.debug(sLog);
				oJson = eval('(' + this.oHttpRequest.responseText + ')');
			} catch (e) {
				var sLog = dwa.common.utils.formatMessage(dwa.type._msgs["L_ERR_LOAD_FAILURE_LITEUI"], e ? e.message : dwa.type._msgs["L_ERR_NO_RESPONSE"]);
				console.error(sLog);
				return;
			}
		
			var oDpabNames = dwa.type.dpabNamesManager.get(true);
			oDpabNames.setJsonNode(oJson, true);
			if (oDpabNames.fnCB) {
				oDpabNames.fnCB();
				oDpabNames.fnCB = null;
			}
			
			var sLog = 'DPAB Names: End evaluating data';
			console.debug(sLog);
		
			this.release();
		};  // end of com_ibm_dwa_io_dpabNamesManager_onDatasetComplete

		{
			//TODO: how can we get the value to pass?
			com_ibm_dwa_globals = {sNsfPath: "http://hale.yamato.ibm.com/mail/kami.nsf/"};
//			setTimeout(dojo.hitch(oXml, "load", "data/s_DPABNames.json"), 1000);
//			return;
		}
		setTimeout(dojo.hitch(oXml, "load", com_ibm_dwa_globals.sNsfPath + '/' + "iNotes" + '/' + "Proxy" + '/' + '?EditDocument&Form=s_DPABNames&PresetFields=nMax;' + this.nTypeaheadMaxNames),
		 1000);
	}
});

dwa.type.dpabNamesManager.get = function(fNoInit){
	if (!dwa.type.dpabNamesManager.oDpabNames)
		dwa.type.dpabNamesManager.oDpabNames = new dwa.type.dpabNamesManager();
	// calling init everytime lets hybrid forms update sparkle-lite dpab list
	return fNoInit ? dwa.type.dpabNamesManager.oDpabNames : dwa.type.dpabNamesManager.oDpabNames.init();
};
